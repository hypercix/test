<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\UskoHesapController;
use App\Http\Controllers\PurchaseController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\SmsRequestController;
use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Admin\UserController;
use App\Http\Controllers\Admin\StockController;
use App\Http\Controllers\Admin\ProductController;
use App\Http\Controllers\Admin\OrderController;
use App\Http\Controllers\Admin\SmsMonitoringController;
use App\Http\Controllers\PaymentController;
use App\Http\Controllers\Admin\PaymentController as AdminPaymentController;
use App\Http\Controllers\Admin\StripeWebhookController;
use App\Http\Controllers\Admin\GmailController as GmailController;




/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Auth::routes();
//Language Translation
Route::get('index/{locale}', [App\Http\Controllers\HomeController::class, 'lang']);

Route::get('/', [App\Http\Controllers\HomeController::class, 'root'])->name('root');

//Update User Details
Route::post('/update-profile/{id}', [App\Http\Controllers\HomeController::class, 'updateProfile'])->name('updateProfile');
Route::post('/update-password/{id}', [App\Http\Controllers\HomeController::class, 'updatePassword'])->name('updatePassword');

Route::middleware('auth')->group(function () {
    Route::get('/sys/usko-hesap', [UskoHesapController::class, 'index'])->name('uskohesap.index');

});

Route::get('/satinal/usko', [SatinalController::class, 'index'])->name('satinal.usko');

Route::post('/purchase', [PurchaseController::class, 'store'])
    ->middleware('auth')
    ->name('purchase');
Route::middleware(['auth'])->group(function () {
    Route::get('/panel/siparislerim', [\App\Http\Controllers\PanelController::class, 'orders'])->name('panel.orders');
});
Route::get('/panel/siparis/{id}', [\App\Http\Controllers\PanelController::class, 'orderDetail'])
    ->name('panel.order.detail')
    ->middleware('auth');
Route::get('/panel/siparis/{order}/indir', [\App\Http\Controllers\PanelController::class, 'downloadOrder'])->name('panel.order.download');


Route::middleware(['auth'])->group(function () {
    Route::get('/profil', [ProfileController::class, 'index'])->name('profile.index');
    Route::post('/profil/sifre-degistir', [ProfileController::class, 'changePassword'])->name('profile.changePassword');
});
Route::middleware(['auth'])->group(function () {
    Route::get('/sms', [SmsRequestController::class, 'index'])->name('sms.index');
});

Route::get('/sms/check/{id}', [SmsRequestController::class, 'checkSms'])->name('sms.check');
Route::get('/sms/retry/{id}', [SmsRequestController::class, 'getAnotherSms'])->name('sms.retry');
Route::get('/sms/cancel/{id}', [SmsRequestController::class, 'cancelSms'])->name('sms.cancel');



Route::post('/sms/request', [SmsRequestController::class, 'create'])->name('sms.request.create');



// SMS Aktivasyon Routes
Route::middleware(['auth'])->prefix('sms-activation')->name('sms-activation.')->group(function () {
    Route::get('/', [App\Http\Controllers\SmsActivationController::class, 'index'])->name('index');
    Route::post('/get-number', [App\Http\Controllers\SmsActivationController::class, 'getNumber'])->name('get-number');
    Route::get('/check-status/{id}', [App\Http\Controllers\SmsActivationController::class, 'checkStatus'])->name('check-status');
    Route::get('/get-messages/{id}', [App\Http\Controllers\SmsActivationController::class, 'getMessages'])->name('get-messages');
    Route::post('/cancel/{id}', [App\Http\Controllers\SmsActivationController::class, 'cancelActivation'])->name('cancel');
    Route::post('/request-new-sms/{id}', [App\Http\Controllers\SmsActivationController::class, 'requestNewSms'])->name('request-new-sms');
});
// Admin Routes
Route::prefix('admin')->middleware(['auth', 'admin'])->group(function () {
    Route::get('/', [App\Http\Controllers\Admin\DashboardController::class, 'index'])->name('admin.dashboard');
});
// Admin Routes
Route::prefix('admin')->middleware(['auth', 'admin'])->name('admin.')->group(function () {
    Route::get('/', [DashboardController::class, 'index'])->name('dashboard');

    // Kullanıcı Yönetimi
    Route::resource('users', UserController::class)->except(['create', 'store']);
    Route::post('users/{user}/add-balance', [UserController::class, 'addBalance'])->name('users.add-balance');

    // Ürün Yönetimi
    Route::resource('products', ProductController::class);
    Route::post('products/{product}/import-stocks', [ProductController::class, 'importStocks'])->name('products.import-stocks');

    // Stok Yönetimi
    Route::resource('stocks', StockController::class)->except(['create', 'store']);
    // Sipariş Yönetimi
    Route::resource('orders', OrderController::class)->only(['index', 'show']);
    Route::patch('orders/{order}/update-status', [OrderController::class, 'updateStatus'])->name('orders.update-status');

    Route::get('sms-monitoring', [App\Http\Controllers\Admin\SmsMonitoringController::class, 'index'])->name('sms-monitoring.index');
    Route::get('sms-monitoring/{activation}', [App\Http\Controllers\Admin\SmsMonitoringController::class, 'show'])->name('sms-monitoring.show');
    Route::get('sms-monitoring/export', [App\Http\Controllers\Admin\SmsMonitoringController::class, 'export'])->name('sms-monitoring.export');

    // Ödeme Yönetimi
    Route::get('payments', [App\Http\Controllers\Admin\PaymentController::class, 'index'])->name('payments.index');
    Route::get('payments/report', [App\Http\Controllers\Admin\PaymentController::class, 'report'])->name('payments.report'); // Özel route öne alındı
    Route::get('payments/add-balance/form', [App\Http\Controllers\Admin\PaymentController::class, 'addBalanceForm'])->name('payments.add-balance-form'); // Özel route öne alındı
    Route::post('payments/add-balance', [App\Http\Controllers\Admin\PaymentController::class, 'addBalance'])->name('payments.add-balance');
    Route::get('payments/{payment}', [App\Http\Controllers\Admin\PaymentController::class, 'show'])->name('payments.show'); // Genel route en sona alındı
});
Route::middleware(['auth'])->group(function () {
    Route::get('/bakiye-yukle', [App\Http\Controllers\PaymentController::class, 'index'])->name('payments.index');
    Route::post('/bakiye-yukle/checkout', [App\Http\Controllers\PaymentController::class, 'checkout'])->name('payments.checkout');
    Route::get('/bakiye-yukle/result', [App\Http\Controllers\PaymentController::class, 'result'])->name('payments.result');
    Route::get('/odeme-gecmisi', [App\Http\Controllers\PaymentController::class, 'history'])->name('payments.history');
});
Route::post('/stripe/webhook', [App\Http\Controllers\StripeWebhookController::class, 'handleWebhook'])->name('stripe.webhook');

// Admin Routes
Route::prefix('admin')->middleware(['auth', 'admin'])->name('admin.')->group(function () {
    Route::resource('gmail', App\Http\Controllers\Admin\GmailController::class);
    Route::post('gmail/{product}/import-stocks', [App\Http\Controllers\Admin\GmailController::class, 'importStocks'])->name('gmail.import-stocks');
    Route::get('gmail/{product}/stocks', [App\Http\Controllers\Admin\GmailController::class, 'stocks'])->name('gmail.stocks');
    Route::get('gmail-reports', [App\Http\Controllers\Admin\GmailController::class, 'reports'])->name('gmail.reports');
    Route::delete('stocks/bulk-delete', [App\Http\Controllers\Admin\ProductController::class, 'bulkDeleteStocks'])->name('stocks.bulk-delete');
});

// web.php dosyasına eklenecek route tanımları

// web.php dosyasına eklenecek route tanımları



// Admin Routes - Yönetim tarafı
Route::prefix('admin')->middleware(['auth', 'admin'])->name('admin.')->group(function () {
    // Proxy Yönetimi
    Route::get('/proxy', [App\Http\Controllers\Admin\ProxyController::class, 'index'])->name('proxy.index');
    Route::get('/proxy/create', [App\Http\Controllers\Admin\ProxyController::class, 'create'])->name('proxy.create');
    Route::post('/proxy', [App\Http\Controllers\Admin\ProxyController::class, 'store'])->name('proxy.store');
    Route::get('/proxy/{proxy}/edit', [App\Http\Controllers\Admin\ProxyController::class, 'edit'])->name('proxy.edit');
    Route::put('/proxy/{proxy}', [App\Http\Controllers\Admin\ProxyController::class, 'update'])->name('proxy.update');
    Route::delete('/proxy/{proxy}', [App\Http\Controllers\Admin\ProxyController::class, 'destroy'])->name('proxy.destroy');

    // Proxy Siparişleri
    Route::get('/proxy/orders', [App\Http\Controllers\Admin\ProxyController::class, 'orders'])->name('proxy.orders');
    Route::get('/proxy/order/{id}', [App\Http\Controllers\Admin\ProxyController::class, 'orderDetail'])->name('proxy.order-detail');
    Route::post('/proxy/order/{id}/complete', [App\Http\Controllers\Admin\ProxyController::class, 'completeOrder'])->name('proxy.complete-order');
    Route::post('/proxy/order/{id}/cancel', [App\Http\Controllers\Admin\ProxyController::class, 'cancelOrder'])->name('proxy.cancel-order');

    // Raporlar
    Route::get('/proxy-reports', [App\Http\Controllers\Admin\ProxyController::class, 'reports'])->name('proxy.reports');
});
Route::get('{any}', [App\Http\Controllers\HomeController::class, 'index'])->name('index');
