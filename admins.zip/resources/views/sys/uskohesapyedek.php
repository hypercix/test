@extends('layouts.master')
@section('title', 'USKO Hesap Satın Al')

@section('content')
@component('components.breadcrumb')
@slot('li_1') Satın Al @endslot
@slot('title') USKO Hesaplar @endslot
@endcomponent

<style>
    .modal-content::before {
        content: '';
        position: absolute;
        top: -4px;
        left: -4px;
        right: -4px;
        bottom: -4px;
        background: conic-gradient(#00c6ff, #0072ff, #00c6ff);
        z-index: -2;
        animation: rotateBorder 4s linear infinite;
        border-radius: 20px;
    }

    /* Dönen çerçeveli modal */
    .modal-content {
        position: relative;
        border-radius: 16px;
        overflow: hidden;
        padding: 0;
        z-index: 1;
    }

    .modal-content::before {
        content: '';
        position: absolute;
        top: -4px;
        left: -4px;
        right: -4px;
        bottom: -4px;
        background: conic-gradient(#00c6ff, #0072ff, #00c6ff);
        z-index: -2;
        animation: rotateBorder 4s linear infinite;
        border-radius: 20px;
    }

    .modal-content::after {
        content: '';
        position: absolute;
        top: 4px;
        left: 4px;
        right: 4px;
        bottom: 4px;
        background-color: #1a1a1a;
        border-radius: 12px;
        z-index: -1;
    }

    /* Başlık rengi beyaz */
    .modal-title {
        color: #fff !important;
    }

    /* Dönen animasyon */
    @keyframes rotateBorder {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
    }
    .modal-body strong {
        color: #00c6ff;
    }

    .modal-body p#modal-desc {
        font-size: 15px;
        line-height: 1.8;
        color: #e0e0e0;
    }

    .modal-body .highlight {
        color: #ff4b4b;
        font-weight: bold;
    }

    .modal-footer .btn-primary {
        background: linear-gradient(135deg, #00c6ff, #0072ff);
        border: none;
        font-weight: bold;
    }

    .tab-btn {
        background: linear-gradient(135deg, #00c6ff, #0072ff);
        color: white;
        border: none;
        border-radius: 10px;
        padding: 8px 20px;
        margin: 6px 4px;
        font-weight: bold;
        transition: 0.3s ease;
        position: relative;
        z-index: 1;
        overflow: hidden;
    }

    .tab-btn.active::before {
        content: '';
        position: absolute;
        top: -2px;
        left: -2px;
        right: -2px;
        bottom: -2px;
        background: conic-gradient(red, transparent, red);
        animation: rotateRed 2s linear infinite;
        border-radius: 12px;
        z-index: -1;
    }

    @keyframes rotateRed {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
    }


    .account-card {
        background: #1a263a;
        border-radius: 16px;
        padding: 24px;
        color: white;
        border: 2px solid #00c6ff;
        box-shadow: 0 0 8px rgba(0,198,255,0.4);
        display: flex;
        flex-direction: column;
        height: 100%;
    }

    .info-table {
        width: 100%;
        margin-bottom: 16px;
        font-size: 14px;
        background: rgba(255,255,255,0.05);
        border-radius: 8px;
        overflow: hidden;
    }

    .info-table th, .info-table td {
        padding: 6px 10px;
    }

    .info-table th {
        text-align: left;
        font-weight: 600;
        white-space: nowrap;
        width: 90px;
        background: rgba(0,0,0,0.1);
    }

    .info-table td {
        color: #d3d3d3;
    }

    .price-section {
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .quantity-control {
        display: flex;
        align-items: center;
    }

    .quantity-control button {
        background: #008cff;
        color: white;
        border: none;
        width: 32px;
        height: 32px;
        font-size: 18px;
        font-weight: bold;
    }

    .quantity-control input {
        width: 48px;
        text-align: center;
        border: 1px solid #ccc;
        margin: 0 6px;
        border-radius: 4px;
    }

    .buy-button {
        background: linear-gradient(to right, #00c6ff, #0072ff);
        color: white;
        border: none;
        border-radius: 8px;
        width: 100%;
        padding: 10px;
        font-weight: bold;
        margin-top: 10px;
    }

    .tab-pane {
        display: none;
    }

    .tab-pane.active {
        display: block;
    }

    @media (max-width: 768px) {
        .tab-buttons {
            flex-wrap: wrap;
            justify-content: center;
        }

        .account-card {
            margin-bottom: 20px;
        }
    }

    .badge-stock {
        background: #00c6ff;
        color: #000;
        font-weight: 600;
        border-radius: 8px;
        padding: 6px 12px;
        font-size: 13px;
        display: inline-flex;
        align-items: center;
        box-shadow: 0 0 8px #00c6ff;
    }

    .badge-stock i {
        margin-right: 6px;
    }
</style>

@php
$servers = ['ZERO', 'PANDORA', 'AGARTHA', 'FELIS', 'ESKI SERVERLAR'];
$baseAccounts = [
[
'suffix' => 'Auth ID-PASS',
'type' => 'auth',
'stock' => 14,
'kayit' => 'En az 2 gün',
'garanti' => 'İlk girişte her türlü problemde iade/değişim, abuse durumlarında koşulsuz iade/değişim hakkı.',
'teslim' => 'gmail, gmailşifre, gmailkurtarmamaili, nttid, nttşifresi, otpauthkodu',
'price' => 180
],
[
'suffix' => 'COPY OTP',
'type' => 'copy',
'stock' => 8,
'kayit' => 'En az 3 gün',
'garanti' => 'İlk girişte her türlü problemde iade/değişim, abuse durumlarında koşulsuz iade/değişim hakkı.',
'teslim' => 'gmail, gmailşifre, gmailkurtarmamaili, nttid, nttşifresi, copyotp.rar',
'kullanim' => "- OtpInfo.reg dosyasını çalıştırın.\n- Dosyaları AnyOTP klasörüne kopyalayın.\n- StartOTP.exe'yi yönetici olarak başlatın.",
'price' => 180
]
];
$accounts = [];
foreach ($servers as $server) {
$accounts[$server] = array_map(function ($acc) use ($server) {
return array_merge(['title' => $server . ' (' . $acc['suffix'] . ')'], $acc);
}, $baseAccounts);
}
@endphp

<div class="tab-buttons d-flex justify-content-center mb-4">
    @foreach ($servers as $index => $server)
    <button class="tab-btn @if($index==0) active @endif" data-target="tab-{{ $index }}">{{ $server }}</button>
    @endforeach
</div>

@foreach ($servers as $index => $server)
<div class="tab-pane @if($index==0) active @endif" id="tab-{{ $index }}">
    <div class="row">
        @foreach ($accounts[$server] as $account)
        <div class="col-md-6 mb-4 d-flex">
            <div class="account-card flex-fill"
                 data-product-id="{{ $products[$account['title']]->id ?? '' }}"
                 data-stock="{{ $products[$account['title']]->stocks()->where('status', 0)->count() ?? 0 }}">

                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h5 class="fw-bold text-white">{{ $account['title'] }}</h5>
                    <span class="badge-stock">
    <i class="ri-box-3-fill"></i>{{ $products[$account['title']]->stocks()->where('status', 0)->count() ?? 0 }} stok
</span>                            </div>

                <table class="info-table">
                    <tr><th>⏱ Kayıt</th><td>{{ $account['kayit'] }}</td></tr>
                    <tr><th>🛡 Garanti</th><td>{{ $account['garanti'] }}</td></tr>
                    <tr><th>📦 Teslim</th><td>{{ $account['teslim'] }}</td></tr>
                </table>

                @if(isset($account['kullanim']))
                <div class="mb-2 p-2 bg-light text-dark rounded small">
                    <strong>📘 Kullanım Talimatı:</strong><br>
                    <pre style="white-space: pre-wrap;">{{ $account['kullanim'] }}</pre>
                </div>
                @endif

                <div class="mt-auto">
                    <div class="price-section mb-2">
                        <div class="quantity-control">
                            <button onclick="decrease(this)">−</button>
                            <input type="text" class="quantity-input" value="1" data-price="{{ $account['price'] }}" readonly>
                            <button onclick="increase(this)">+</button>
                        </div>
                        <div class="text-danger fw-bold fs-6">Toplam: <span class="total-price">{{ number_format($account['price'], 2) }}</span>₺</div>
                    </div>
                    <button class="buy-button" onclick="confirmPurchase('{{ $account['title'] }}', {{ $account['price'] }})">
                        🛒 Satın Al
                    </button>
                </div>
            </div>
        </div>
        @endforeach
    </div>
</div>
@endforeach

<!-- Satın alma onay modali -->
<div class="modal fade" id="purchaseModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content bg-dark text-white">
            <div class="modal-header border-secondary">
                <h5 class="modal-title">Satın Almayı Onayla</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p id="modal-desc"></p>
            </div>
            <div class="modal-footer border-secondary">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                <button type="button" class="btn btn-primary">Evet, Satın Al</button>
            </div>
        </div>
    </div>
</div>

<!-- Hata modalı -->
<div class="modal fade" id="errorModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content bg-dark text-white">
            <div class="modal-header border-secondary">
                <h5 class="modal-title">⚠️ Hata Oluştu</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p id="error-modal-message" class="text-danger"></p>
            </div>
            <div class="modal-footer border-secondary">
                <button type="button" class="btn btn-primary" data-bs-dismiss="modal">Tamam</button>
            </div>
        </div>
    </div>
</div>
<!-- Başarılı işlem modalı -->
<div class="modal fade" id="successModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content bg-dark text-white">
            <div class="modal-header border-secondary">
                <h5 class="modal-title text-success">✅ Başarılı</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p id="success-modal-message" class="text-white"></p>
            </div>
        </div>
    </div>
</div>

@endsection

@section('script')
<script>
    const isLoggedIn = {{ auth()->check() ? 'true' : 'false' }};

    function updateTotal(input) {
        const price = parseFloat(input.dataset.price);
        const qty = parseInt(input.value) || 1;
        const totalEl = input.closest('.account-card').querySelector('.total-price');
        totalEl.textContent = (price * qty).toFixed(2).replace('.', ',');
    }

    function increase(btn) {
        const input = btn.parentElement.querySelector('input');
        const card = btn.closest('.account-card');
        const maxStock = parseInt(card.dataset.stock); // data-stock'la gelecek

        let current = parseInt(input.value);
        if (current < maxStock) {
            input.value = current + 1;
            updateTotal(input);
        }
    }

    function decrease(btn) {
        const input = btn.parentElement.querySelector('input');
        if (parseInt(input.value) > 1) {
            input.value = parseInt(input.value) - 1;
            updateTotal(input);
        }
    }
    function showSuccess(message) {
        const modal = new bootstrap.Modal(document.getElementById('successModal'));
        const messageContainer = document.getElementById('success-modal-message');

        let seconds = 5;
        const redirectUrl = `/panel/siparis/${window.latestOrderId}`;

        messageContainer.innerHTML = `
        ${message}
        <div class="progress mt-3" style="height: 20px;">
            <div class="progress-bar progress-bar-striped progress-bar-animated bg-success"
                 role="progressbar"
                 style="width: 100%;"
                 id="redirectProgress">
                <span id="countdown-text"></span>
            </div>
        </div>
    `;

        modal.show();

        const interval = setInterval(() => {
            seconds--;
            document.getElementById('countdown-text').textContent = `${seconds}`;
            document.getElementById('redirectProgress').style.width = `${seconds * 20}%`;

            if (seconds === 0) {
                clearInterval(interval);
                window.location.href = redirectUrl;
            }
        }, 1000);
    }



    function confirmPurchase(title, price) {
        if (!isLoggedIn) {
            showError('Lütfen giriş yapın.');
            return;
        }

        const modal = new bootstrap.Modal(document.getElementById('purchaseModal'));
        const card = event.target.closest('.account-card');
        const quantityInput = card.querySelector('.quantity-input');
        const quantity = parseInt(quantityInput.value);
        const total = price * quantity;
        const balance = {{ auth()->user()->balance ?? 0 }};
        const productId = card.dataset.productId;

        document.getElementById('modal-desc').innerHTML = `
            <p>
                <strong>Ürün:</strong> ${title}<br>
                <strong>Adet:</strong> <span class="highlight">${quantity}</span><br>
                <strong>Toplam Tutar:</strong> <span class="highlight">${total.toFixed(2).replace('.', ',')}₺</span><br>
                <strong>Mevcut Bakiyeniz:</strong> ${balance.toFixed(2).replace('.', ',')}₺<br><br>
                Bu işlemle bakiyenizden <span class="highlight">${total.toFixed(2).replace('.', ',')}₺</span> düşülecektir.
            </p>`;

        modal.show();

        const confirmBtn = document.querySelector('#purchaseModal .btn-primary');
        confirmBtn.onclick = null;

        confirmBtn.onclick = function () {
            fetch(@json(route('purchase')), {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                },
                body: JSON.stringify({
                    product_id: productId,
                    quantity: quantity
                })
            })
                .then(async response => {
                    const data = await response.json();
                    if (!response.ok) {
                        throw new Error(data.error || 'Bilinmeyen bir hata oluştu.');
                    }
                    return data;
                })
                .then(data => {
                    bootstrap.Modal.getInstance(document.getElementById('purchaseModal')).hide();

                    if (data.success) {
                        const redirectUrl = `/panel/siparis/${data.order_id}`; // yönlenecek URL

                        const successMessage = `
            <p>
                🎉 <strong>Satın alma başarılı!</strong><br>
                Sipariş detaylarına <strong>5</strong> saniye içinde yönlendirileceksiniz...
            </p>`;
                        showSuccess(successMessage);

                        setTimeout(() => {
                            window.location.href = redirectUrl;
                        }, 3000);
                    } else {
                        showError("Bilinmeyen bir hata oluştu.");
                    }
                })



                .catch(error => {
                    // Onay modalını kapat
                    bootstrap.Modal.getInstance(document.getElementById('purchaseModal')).hide();

                    // Hata mesajını göster
                    showError(error.message);
                });
        };
    }

    function showError(message) {
        const errorModal = new bootstrap.Modal(document.getElementById('errorModal'));
        document.getElementById('error-modal-message').textContent = message;
        errorModal.show();
    }

    document.querySelectorAll('.quantity-input').forEach(input => {
        input.addEventListener('input', () => updateTotal(input));
    });

    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
            document.querySelectorAll('.tab-pane').forEach(p => p.classList.remove('active'));
            btn.classList.add('active');
            document.getElementById(btn.dataset.target).classList.add('active');
        });
    });
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            // Sekme durumunu kaydet
            localStorage.setItem('activeUskoTab', btn.dataset.target);

            // Normal sekme değiştirme işlemleri
            document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
            document.querySelectorAll('.tab-pane').forEach(p => p.classList.remove('active'));
            btn.classList.add('active');
            document.getElementById(btn.dataset.target).classList.add('active');
        });
    });

    document.addEventListener('DOMContentLoaded', () => {
        const savedTab = localStorage.getItem('activeUskoTab');
        if (savedTab && document.getElementById(savedTab)) {
            // Tüm sekmeleri pasifleştir
            document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
            document.querySelectorAll('.tab-pane').forEach(p => p.classList.remove('active'));

            // Kaydedilen sekmeyi aktif yap
            document.querySelector(`.tab-btn[data-target="${savedTab}"]`)?.classList.add('active');
            document.getElementById(savedTab)?.classList.add('active');
        }
    });

</script>
<script src="{{ URL::asset('build/js/app.js') }}"></script>
@endsection