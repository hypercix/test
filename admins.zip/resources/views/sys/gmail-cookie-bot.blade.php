@extends('layouts.master')

@section('title') Gmail Cookie Bot @endsection

@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <h4 class="mb-4">Gmail Cookie Bot Yönetimi</h4>

                <!-- Tab Menüleri -->
                <ul class="nav nav-pills nav-justified mb-3 border-bottom" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link" data-bs-toggle="tab" href="#bot-ayarlar" role="tab">
                            <i class="mdi mdi-cog-outline"></i> Bot Ayarları
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" data-bs-toggle="tab" href="#proxyler" role="tab">
                            <i class="mdi mdi-server-network"></i> Proxyler
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" data-bs-toggle="tab" href="#gmailler" role="tab">
                            <i class="mdi mdi-email-multiple-outline"></i> Gmailler
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" data-bs-toggle="tab" href="#loglar" role="tab">
                            <i class="mdi mdi-format-list-bulleted"></i> Loglar
                        </a>
                    </li>
                </ul>

                <!-- Tab İçerikleri -->
                <div class="tab-content p-4 bg-light border rounded">
                    <!-- Bot Ayarları -->
                    <div class="tab-pane" id="bot-ayarlar" role="tabpanel">
                        <h5 class="mb-3">Bot Ayarları</h5>

                        <!-- BOT AYARLARI FORMU -->
                        <form method="POST" action="{{ route('cookiebot.ayarlarKaydet') }}" enctype="multipart/form-data">
                            @csrf
                            @php
                                $aktifIslemVarMi = $havuz->contains(function($item) {
                                    return $item->status == 0;
                                });
                            @endphp

                            <div class="mb-3">
                                <label class="form-label">Fingerprint API</label>
                                <input type="text" name="fingerprint_api" class="form-control" required>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Çerezlendirilecek Gmail Listesi (.txt)</label>
                                <input type="file" name="gmail_dosyasi" class="form-control" accept=".txt" required>
                                <small class="text-muted">Her satır şu formatta olmalı: <code>gmail;şifre;kurtarma</code> (kurtarma opsiyonel). Max 100 satır.<br>Eğer hesabınızda daha önce yüklenip, çerezlendirilememiş gmailler varsa, onlar da tekrar çerezlendirilir.</small>
                            </div>

                            <div class="text-end">
                                <button type="submit" class="btn btn-primary" {{ $aktifIslemVarMi ? 'disabled' : '' }}>
                                    <i class="mdi mdi-content-save"></i> Botu Başlat
                                </button>
                            </div>
                        </form>

                        <!-- İŞLEM GEÇMİŞİ TABLOSU -->
                        <div class="card mt-5">
                            <div class="card-header">
                                <h5 class="mb-0">İşlem Geçmişi</h5>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-hover table-striped table-bordered rounded shadow-sm bg-white">
                                        <thead class="table-dark text-light text-center">
                                        <tr>
                                            <th>#ID</th>
                                            <th>Gmail Sayısı</th>
                                            <th>Fingerprint API</th>
                                            <th>Eklenme</th>
                                            <th>Durum</th>
                                            <th>İşlem</th>
                                        </tr>
                                        </thead>
                                        <tbody class="text-center">
                                        @foreach ($havuz as $veri)
                                            <tr>
                                                <td>{{ $veri->id }}</td>
                                                <td>{{ $veri->gmail_sayisi }}</td>
                                                <td>{{ Str::limit($veri->fingerprint_api, 25, '...') }}</td>
                                                <td>{{ \Carbon\Carbon::parse($veri->created_at)->format('d-m-Y H:i') }}</td>
                                                <td>
                                                    @if($veri->status == 0)
                                                        <span class="badge bg-warning text-dark">
                                    <i class="mdi mdi-loading mdi-spin"></i> Hazırlanıyor
                                </span>
                                                    @elseif($veri->status == 1)
                                                        <span class="badge bg-success">Çerezlendi</span>
                                                    @elseif($veri->status == 3)
                                                        <span class="badge bg-secondary">Durduruldu</span>
                                                    @endif
                                                </td>
                                                <td>
                                                    @if($veri->status == 0)
                                                        <form method="POST" action="{{ route('cookiebot.durdur', $veri->id) }}">
                                                            @csrf
                                                            <button class="btn btn-sm btn-outline-danger" onclick="return confirm('Bu işlemi durdurmak istediğinize emin misiniz?')">
                                                                <i class="mdi mdi-stop-circle-outline"></i> Durdur
                                                            </button>
                                                        </form>
                                                    @else
                                                        <span class="text-muted">-</span>
                                                    @endif
                                                </td>
                                            </tr>
                                        @endforeach
                                        </tbody>
                                    </table>

                                    <div class="mt-3 d-flex justify-content-end">
                                        {{ $havuz->links('pagination::bootstrap-5') }}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="tab-pane" id="proxyler" role="tabpanel">
                        <h5 class="mb-3">Proxyler</h5>
                        <div class="tab-pane" id="cookiebot-proxyler">
                            <div class="row mt-4 g-4">
                                <!-- Kullanılabilir Proxy -->
                                <div class="col-md-6">
                                    <div class="card shadow-sm border-0" style="background: linear-gradient(to right, #28a745, #3bc36b); color: white;">
                                        <div class="card-body d-flex align-items-center">
                                            <div class="me-3">
                                                <i class="mdi mdi-check-network-outline mdi-48px"></i>
                                            </div>
                                            <div>
                                                <h6 class="mb-1 text-uppercase fw-bold">Kullanılabilir Proxy</h6>
                                                <h3 class="mb-0 fw-bold">{{ $proxySayilari['kullanilabilir'] }}</h3>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- Kullanılmış Proxy -->
                                <div class="col-md-6">
                                    <div class="card shadow-sm border-0" style="background: linear-gradient(to right, #6c757d, #adb5bd); color: white;">
                                        <div class="card-body d-flex align-items-center">
                                            <div class="me-3">
                                                <i class="mdi mdi-network-off-outline mdi-48px"></i>
                                            </div>
                                            <div>
                                                <h6 class="mb-1 text-uppercase fw-bold">Kullanılmış Proxy</h6>
                                                <h3 class="mb-0 fw-bold">{{ $proxySayilari['kullanilmis'] }}</h3>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Proxy Ekleme Formu -->
                            <form method="POST" action="{{ route('cookiebot.proxyEkle') }}" enctype="multipart/form-data">
                                @csrf

                                <div class="mb-3 mt-4">
                                    <label class="form-label">Proxy Ekleme Yöntemi</label><br>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="ekleme_tipi" id="cookie_tip_textarea" value="textarea" checked>
                                        <label class="form-check-label" for="cookie_tip_textarea">Manuel Giriş</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="ekleme_tipi" id="cookie_tip_dosya" value="dosya">
                                        <label class="form-check-label" for="cookie_tip_dosya">.txt Dosya</label>
                                    </div>
                                </div>
                                <!-- Sağ Alt Progress Container (Cookiebot Proxy) -->
                                <div id="cookiebotProxyProgressContainer" style="position: fixed; bottom: 20px; right: 20px; width: 300px; display: none; z-index: 9999;">
                                    <div class="card shadow-sm" style="padding: 12px; border-radius: 10px; background-color: #fff;">
                                        <strong class="text-dark">Proxyler yükleniyor...</strong>
                                        <div class="progress mt-2" style="height: 22px;">
                                            <div id="cookiebotUploadProgress" class="progress-bar progress-bar-striped progress-bar-animated bg-success"
                                                 role="progressbar" style="width: 0%;" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
                                                %0
                                            </div>
                                        </div>
                                        <div id="cookiebotProgressAlert" class="text-success mt-2 text-center" style="display: none;">
                                            ✅ Proxy yükleme tamamlandı.
                                        </div>
                                    </div>
                                </div>

                                <!-- Textarea -->
                                <div id="cookie_textarea_input" class="mb-3">
                                    <label for="proxy_textarea" class="form-label">Proxy Listesi (max 250)</label>
                                    <textarea class="form-control" name="proxy_textarea" rows="10" placeholder="IP:PORT:USERNAME:PASSWORD"></textarea>
                                </div>

                                <!-- Dosya -->
                                <div id="cookie_dosya_input" class="mb-3" style="display:none;">
                                    <label for="proxy_file" class="form-label">Proxy Dosyası (.txt) max 3000 satır</label>
                                    <input type="file" class="form-control" name="proxy_file" accept=".txt">
                                </div>

                                <div class="text-end">
                                    <button type="submit" class="btn btn-primary">
                                        <i class="mdi mdi-upload"></i> Proxyleri Yükle
                                    </button>
                                </div>
                            </form>

                            <!-- Proxy Tablosu -->
                            <div class="card mt-4">
                                <div class="card-header d-flex justify-content-between align-items-center">
                                    <h5 class="mb-0">Proxy Listesi</h5>
                                    <form method="POST" action="{{ route('cookiebot.proxyTemizle') }}" onsubmit="return confirm('Tüm proxyleri silmek istediğinize emin misiniz?');">
                                        @csrf
                                        @method('DELETE')
                                        <button class="btn btn-danger btn-sm" type="submit">
                                            <i class="mdi mdi-delete"></i> Tümünü Sil
                                        </button>
                                    </form>
                                </div>

                                <div class="table-responsive">
                                    <table class="table table-bordered table-hover align-middle text-center">
                                        <thead class="table-dark text-light">
                                        <tr>
                                            <th>#ID</th>
                                            <th>Eklenme Tarihi</th>
                                            <th>Proxy</th>
                                            <th>Durum</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        @forelse($proxyler as $proxy)
                                            <tr>
                                                <td>{{ $proxy->id }}</td>
                                                <td>{{ \Carbon\Carbon::parse($proxy->created_at)->format('d-m-Y H:i') }}</td>
                                                <td>{{ $proxy->proxy }}</td>
                                                <td>
                                                    @if($proxy->status == 0)
                                                        <span class="badge bg-success">Kullanılmadı</span>
                                                    @else
                                                        <span class="badge bg-secondary">Kullanıldı</span>
                                                    @endif
                                                </td>
                                            </tr>
                                        @empty
                                            <tr>
                                                <td colspan="4" class="text-muted">Proxy bulunamadı.</td>
                                            </tr>
                                        @endforelse
                                        </tbody>
                                    </table>
                                    <div class="d-flex justify-content-end mt-3">
                                        {{ $proxyler->links('pagination::bootstrap-5') }}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="tab-pane" id="gmailler" role="tabpanel">
                        <h5 class="mb-3">Gmailler</h5>

                        <!-- Kartlar -->
                        <div class="row mb-3">
                            <!-- Çerezlenmiş Gmail Sayısı -->
                            <div class="col-md-4">
                                <div class="card border border-info shadow">
                                    <div class="card-body">
                                        <h5 class="card-title text-info">Çerezlenmiş Gmail Sayısı</h5>
                                        <p class="card-text fs-4 fw-bold">{{ $cerezlenmisSayisi }}</p>
                                    </div>
                                </div>
                            </div>

                            <!-- Hazır Bekleyen Gmail Sayısı -->
                            <div class="col-md-4">
                                <div class="card border border-warning shadow">
                                    <div class="card-body">
                                        <h5 class="card-title text-warning">Hazır Bekleyen Gmail Sayısı</h5>
                                        <p class="card-text fs-4 fw-bold">{{ $hazirBekleyenSayisi }}</p>
                                    </div>
                                </div>
                            </div>

                            <!-- Butonlar -->
                            <div class="col-md-4 d-flex align-items-end justify-content-end gap-2">
                                <form method="POST" action="{{ route('cookiebot.cerezTopluSil') }}" onsubmit="return confirm('Tüm çerezli gmailleri silmek istiyor musunuz?');">
                                    @csrf
                                    @method('DELETE')
                                    <button class="btn btn-danger btn-sm">
                                        <i class="mdi mdi-delete"></i> Tümünü Sil
                                    </button>
                                </form>

                                <form method="POST" action="{{ route('cookiebot.cerezTopluIndir') }}">
                                    @csrf
                                    <button class="btn btn-success btn-sm">
                                        <i class="mdi mdi-download"></i> Tümünü İndir
                                    </button>
                                </form>
                            </div>
                        </div>

                        <!-- Tablo -->
                        <div class="card">
                            <div class="card-header">
                                <h5 class="mb-0">Çerezli Gmail Listesi</h5>
                            </div>
                            <div class="table-responsive">
                                <table class="table table-bordered table-hover align-middle">
                                    <thead class="table-dark text-light text-center">
                                    <tr>
                                        <th>#ID</th>
                                        <th>Eklenme</th>
                                        <th>Gmail</th>
                                        <th>Şifre</th>
                                        <th>Kurtarma</th>
                                        <th>Durum</th>
                                        <th>Cookie</th>
                                        <th>İşlem</th>
                                    </tr>
                                    </thead>
                                    <tbody class="text-center">
                                    @forelse($cerezliGmailler as $item)
                                        <tr>
                                            <td>{{ $item->id }}</td>
                                            <td>{{ \Carbon\Carbon::parse($item->created_at)->format('d-m-Y H:i') }}</td>
                                            <td>{{ $item->gmail }}</td>
                                            <td>{{ $item->sifre }}</td>
                                            <td>{{ $item->kurtarma ?? '-' }}</td>
                                            <td>
                                                @if($item->status == 1)
                                                    <span class="badge bg-success">Çerezlendi</span>
                                                @else
                                                    <span class="badge bg-secondary">Hazırlanıyor</span>
                                                @endif
                                            </td>
                                            <td>
                                                @if($item->status == 1)
                                                    <form method="POST" action="{{ route('cookiebot.cerezIndir', $item->id) }}">
                                                        @csrf
                                                        <button class="btn btn-outline-primary btn-sm">
                                                            <i class="mdi mdi-download"></i> İndir
                                                        </button>
                                                    </form>
                                                @else
                                                    <span class="text-muted">-</span>
                                                @endif
                                            </td>
                                            <td>
                                                <form method="POST" action="{{ route('cookiebot.cerezSil', $item->id) }}" onsubmit="return confirm('Bu çerezi silmek istediğinizden emin misiniz?');">
                                                    @csrf
                                                    @method('DELETE')
                                                    <button class="btn btn-outline-danger btn-sm">
                                                        <i class="mdi mdi-delete"></i> Sil
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                    @empty
                                        <tr>
                                            <td colspan="8" class="text-muted">Henüz çerezli gmail yok.</td>
                                        </tr>
                                    @endforelse
                                    </tbody>
                                </table>

                                <div class="d-flex justify-content-end mt-3">
                                    {{ $cerezliGmailler->links('pagination::bootstrap-5') }}
                                </div>
                            </div>
                        </div>
                    </div>




                    <div class="tab-pane" id="loglar" role="tabpanel">
                        <h5 class="mb-3">Loglar</h5>
                        <p>Log içeriği buraya gelecek.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
@section('script')
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        @if(session('success'))
        Swal.fire({
            title: 'Başarılı!',
            text: @json(session('success')),
            icon: 'success',
            confirmButtonText: 'Tamam',
            customClass: { confirmButton: 'btn btn-primary' },
            buttonsStyling: false
        }).then(() => {
            window.location.reload(); // ✅ sayfa yenileme
        });
        @endif

        @if(session('error'))
        Swal.fire({
            title: 'Uyarı!',
            text: @json(session('error')),
            icon: 'warning',
            confirmButtonText: 'Tamam',
            customClass: { confirmButton: 'btn btn-warning' },
            buttonsStyling: false
        });
        @endif
    });

    document.addEventListener('DOMContentLoaded', function () {
        const currentPage = window.location.pathname;
        const storageKey = 'activeTab_' + currentPage;

        let activeTab = localStorage.getItem(storageKey);
        if (activeTab) {
            let tabElement = document.querySelector(`a[href="${activeTab}"]`);
            if (tabElement) new bootstrap.Tab(tabElement).show();
        } else {
            // Eğer hiç localStorage kaydı yoksa, ilk tabı aç
            let firstTab = document.querySelector('a[data-bs-toggle="tab"]');
            if (firstTab) new bootstrap.Tab(firstTab).show();
        }

        document.querySelectorAll('a[data-bs-toggle="tab"]').forEach(tab => {
            tab.addEventListener('shown.bs.tab', function (e) {
                localStorage.setItem(storageKey, e.target.getAttribute('href'));
            });
        });
    });
</script>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        let progressCompleted = false;

        const progressContainer = document.getElementById('cookiebotProxyProgressContainer');
        const progressBar = document.getElementById('cookiebotUploadProgress');
        const submitBtn = document.querySelector('#proxyler form button[type="submit"]');
        const alertBox = document.getElementById('cookiebotProgressAlert');
        const form = document.querySelector('#proxyler form');

        form.addEventListener('submit', function (e) {
            if (progressContainer.style.display === 'block') {
                e.preventDefault(); // Yükleme devam ediyorsa engelle
                return false;
            }

            progressCompleted = false;
            progressContainer.style.display = 'block';
            alertBox.style.display = 'none';
            progressBar.style.width = '0%';
            progressBar.innerText = '%0';
            submitBtn.disabled = true;
        });

        function updateProgress() {
            $.ajax({
                url: '{{ route("cookiebot.proxyProgress") }}',
                method: 'GET',
                success: function (response) {
                    let progress = parseInt(response.progress);

                    if (progress > 1 && progress < 100) {
                        progressContainer.style.display = 'block';
                        progressBar.style.width = progress + '%';
                        progressBar.setAttribute('aria-valuenow', progress);
                        progressBar.innerText = '%' + progress;
                        submitBtn.disabled = true;
                    }

                    if (progress >= 100 && !progressCompleted) {
                        progressBar.style.width = '100%';
                        progressBar.innerText = '%100';
                        alertBox.style.display = 'block';
                        progressCompleted = true;

                        setTimeout(() => {
                            progressContainer.style.display = 'none';
                            alertBox.style.display = 'none';
                            submitBtn.disabled = false;
                        }, 3000);
                    }
                }
            });
        }

        setInterval(updateProgress, 2000);
    });
</script>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        const textareaRadio = document.getElementById('cookie_tip_textarea');
        const dosyaRadio = document.getElementById('cookie_tip_dosya');
        const textareaInput = document.getElementById('cookie_textarea_input');
        const dosyaInput = document.getElementById('cookie_dosya_input');

        function toggleInputs() {
            if (textareaRadio.checked) {
                textareaInput.style.display = 'block';
                dosyaInput.style.display = 'none';
            } else {
                textareaInput.style.display = 'none';
                dosyaInput.style.display = 'block';
            }
        }

        toggleInputs(); // İlk açılışta tetikle
        textareaRadio.addEventListener('change', toggleInputs);
        dosyaRadio.addEventListener('change', toggleInputs);
    });

</script>
@if(session('success'))
    <script>
        Swal.fire({
            title: 'Başarılı!',
            text: @json(session('success')),
            icon: 'success',
            confirmButtonText: 'Tamam',
            customClass: { confirmButton: 'btn btn-primary' },
            buttonsStyling: false
        }).then(() => {
            setTimeout(() => {
                window.location.reload();
            }, 300);
        });
    </script>
@endif

@if(session('error'))
    <script>
        Swal.fire({
            title: 'Uyarı!',
            text: @json(session('error')),
            icon: 'warning',
            confirmButtonText: 'Tamam',
            customClass: { confirmButton: 'btn btn-warning' },
            buttonsStyling: false
        });
    </script>
@endif
@endsection