@extends('layouts.master')

@section('title') Gmail Bot @endsection

@section('content')

    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <h4 class="mb-4">Gmail Bot Yönetimi</h4>

                <!-- Tab Menüleri -->
                <ul class="nav nav-pills nav-justified mb-3 border-bottom" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link" data-bs-toggle="tab" href="#bot-ayarlar" role="tab">
                            <i class="mdi mdi-cog-outline"></i> Bot Ayarları
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" data-bs-toggle="tab" href="#loglar" role="tab">
                            <i class="mdi mdi-format-list-bulleted"></i> Loglar
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" data-bs-toggle="tab" href="#proxyler" role="tab">
                            <i class="mdi mdi-server-network"></i> Proxyler
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" data-bs-toggle="tab" href="#gmailler" role="tab">
                            <i class="mdi mdi-email-multiple-outline"></i> Gmailler
                        </a>
                    </li>
                </ul>

                <!-- Tab İçerikleri -->
                <div class="tab-content p-4 bg-light border rounded">
                    <div class="tab-pane" id="bot-ayarlar" role="tabpanel">
                        <h5 class="mb-3">Bot Ayarları</h5>
                        <p>Bot ayarları buraya gelecek.</p>
                    </div>

                    <div class="tab-pane" id="loglar" role="tabpanel">
                        <h5 class="mb-3">Loglar</h5>
                        <p>Log içeriği buraya gelecek.</p>
                    </div>

                    <div class="tab-pane" id="proxyler" role="tabpanel">
                        <h5 class="mb-3">Proxyler</h5>
                        <p>Proxy bilgileri buraya gelecek.</p>
                    </div>

                    <div class="tab-pane" id="gmailler" role="tabpanel">
                        <h5 class="mb-3">Gmailler</h5>
                        <p>Gmail listesi buraya gelecek.</p>
                    </div>
                </div>

            </div>
        </div>
    </div>
    @section('script')
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
        <script>
            // Alert varsa göster
            @if(session('success'))
            Swal.fire({
                title: 'Başarılı!',
                text: @json(session('success')),
                icon: 'success',
                confirmButtonText: 'Tamam',
                customClass: { confirmButton: 'btn btn-primary' },
                buttonsStyling: false
            }).then(() => {
                window.location.reload(); // ✅ sayfa yenileme
            });
            @endif

            document.getElementById('botuBaslatBtn').addEventListener('click', function () {
                const form = document.getElementById('hitbotForm');
                if (!form.checkValidity()) {
                    Swal.fire({
                        title: 'Eksik Bilgi!',
                        text: 'Lütfen tüm alanları doldurunuz.',
                        icon: 'error',
                        confirmButtonText: 'Tamam',
                        customClass: { confirmButton: 'btn btn-danger' },
                        buttonsStyling: false
                    });
                    return;
                }

                Swal.fire({
                    title: 'Emin misiniz?',
                    text: 'Bot işlemini başlatmak üzeresiniz.',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonText: 'Evet, başlat!',
                    cancelButtonText: 'İptal',
                    customClass: {
                        confirmButton: 'btn btn-danger me-2',
                        cancelButton: 'btn btn-secondary'
                    },
                    buttonsStyling: false
                }).then((result) => {
                    if (result.isConfirmed) {
                        form.submit();
                    }
                });
            });

    document.addEventListener('DOMContentLoaded', function () {
        const currentPage = window.location.pathname;
        const storageKey = 'activeTab_' + currentPage;

        let activeTab = localStorage.getItem(storageKey);
        if (activeTab) {
            let tabElement = document.querySelector(`a[href="${activeTab}"]`);
            if (tabElement) new bootstrap.Tab(tabElement).show();
        } else {
            // Eğer hiç localStorage kaydı yoksa, ilk tabı aç
            let firstTab = document.querySelector('a[data-bs-toggle="tab"]');
            if (firstTab) new bootstrap.Tab(firstTab).show();
        }

        document.querySelectorAll('a[data-bs-toggle="tab"]').forEach(tab => {
            tab.addEventListener('shown.bs.tab', function (e) {
                localStorage.setItem(storageKey, e.target.getAttribute('href'));
            });
        });
    });
</script>

@endsection
