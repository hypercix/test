@extends('layouts.master')
@section('title', 'Gmail Hesap Satın Al')

@section('content')
    @component('components.breadcrumb')
        @slot('li_1') Satın Al @endslot
        @slot('title') Gmail Hesaplar @endslot
    @endcomponent

    <style>
        /* İyileştirilmiş Gmail Hesap Satış Sayfası CSS */
        :root {
            --gmail-primary: #DB4437;
            --gmail-primary-light: #ea4f42;
            --gmail-primary-dark: #c23c32;
            --gmail-gradient: linear-gradient(135deg, #ea4f42, #c23c32);
            --gmail-accent: #4285F4;
            --background: #f8fafc;
            --card-bg: #ffffff;
            --card-border: #e5e7eb;
            --card-hover-shadow: rgba(0, 0, 0, 0.1);
            --text-primary: #1f2937;
            --text-secondary: #4b5563;
            --text-muted: #6b7280;
            --badge-bg: #fef0f0;
            --badge-text: #DB4437;
            --box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            --info-bg: #fcefee;
            --info-border: #fad4d2;
        }

        body {
            background: var(--background);
            color: var(--text-primary);
            font-family: 'Inter', 'SF Pro Display', -apple-system, BlinkMacSystemFont, sans-serif;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }

        /* Başlık Alanı */
        .page-header {
            text-align: center;
            margin-bottom: 2.5rem;
            padding-top: 1.5rem;
        }

        .page-title {
            font-size: 2.25rem;
            font-weight: 800;
            margin-bottom: 0.5rem;
            background: var(--gmail-gradient);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
            display: inline-block;
        }

        .page-subtitle {
            color: var(--text-secondary);
            font-size: 1rem;
            max-width: 768px;
            margin: 0 auto;
        }

        /* Kart Tasarımı - USKO Stilinde Gmail Kartı */
        .account-card {
            position: relative;
            display: flex;
            flex-direction: column;
            height: 100%;
            background: var(--card-bg);
            border-radius: 0.75rem;
            border: 1px solid #ddd; /* Daha belirgin kenarlık */
            box-shadow: var(--box-shadow); /* Daha belirgin gölge */
            transition: all 0.3s ease;
            overflow: hidden;
        }

        .account-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: var(--gmail-primary);
        }

        .account-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
            border-color: #fbc2bf; /* Hover durumunda daha belirgin kenarlık */
        }

        .card-body {
            padding: 1.5rem;
            display: flex;
            flex-direction: column;
            height: 100%;
        }

        /* Kart Başlık Kısmı - Başlık ve çizgi arasındaki mesafeyi artırma */
        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start; /* Üst hizalama */
            margin-bottom: 1.5rem; /* Aşağıdaki içerikle arasına daha fazla boşluk */
            padding-bottom: 1rem; /* Çizgi ile arasındaki boşluğu artırma */
            border-bottom: 1px solid #e5e7eb; /* Belirgin bir çizgi */
        }

        .card-title {
            font-weight: 700;
            font-size: 1.25rem;
            color: var(--text-primary);
            margin: 0;
        }

        .badge-stock {
            display: inline-flex;
            align-items: center;
            padding: 0.3rem 0.75rem;
            background-color: var(--badge-bg);
            color: var(--badge-text);
            border-radius: 1rem;
            font-size: 0.8rem;
            font-weight: 600;
            box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05);
        }

        .badge-stock i {
            margin-right: 0.4rem;
            font-size: 0.9rem;
        }

        /* Bilgi Tablosu */
        .info-table {
            background-color: #f9fafb;
            border-radius: 0.5rem;
            overflow: hidden;
            margin-bottom: 1.25rem;
            border: 1px solid #f3f4f6;
        }

        .info-row {
            display: flex;
            border-bottom: 1px solid #f3f4f6;
        }

        .info-row:last-child {
            border-bottom: none;
        }

        .info-label {
            width: 40px;
            padding: 0.75rem;
            color: var(--gmail-primary);
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .info-value {
            flex: 1;
            padding: 0.75rem;
            color: var(--text-secondary);
        }

        .info-value strong {
            color: var(--text-primary);
            font-weight: 600;
            margin-right: 0.25rem;
        }

        /* Kullanım Talimatları */
        .usage-instructions {
            background-color: var(--info-bg);
            border: 1px solid var(--info-border);
            border-radius: 0.5rem;
            padding: 1rem;
            margin-bottom: 1.25rem;
            font-size: 0.875rem;
        }

        .usage-title {
            display: flex;
            align-items: center;
            color: var(--gmail-primary);
            font-weight: 600;
            margin-bottom: 0.5rem;
        }

        .usage-title i {
            margin-right: 0.5rem;
        }

        .usage-content {
            color: var(--text-secondary);
            white-space: pre-line;
        }

        /* Fiyat ve Satın Alma Alanı - Hizalama Düzeltmesi */
        .price-actions {
            margin-top: auto; /* Önemli: Kartın altına yapıştırmak için */
            padding-top: 1.25rem;
            border-top: 1px solid #f3f4f6;
        }

        .price-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1rem;
        }

        /* Miktar Kontrolü */
        .quantity-control {
            display: flex;
            align-items: center;
            background-color: var(--card-bg);
            border-radius: 0.4rem;
            overflow: hidden;
            border: 1px solid var(--card-border);
            box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05);
        }

        .quantity-btn {
            width: 2.5rem;
            height: 2.5rem;
            display: flex;
            align-items: center;
            justify-content: center;
            background: none;
            border: none;
            color: var(--text-muted);
            font-size: 1.25rem;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.2s;
        }

        .quantity-btn:hover {
            color: var(--text-primary);
            background-color: #f9fafb;
        }

        .quantity-input {
            width: 3rem;
            text-align: center;
            border: none;
            background: none;
            color: var(--text-primary);
            font-weight: 600;
            padding: 0.5rem 0;
        }

        .total-price {
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--gmail-primary);
        }

        /* Satın Al Butonu */
        .buy-button {
            width: 100%;
            padding: 0.85rem;
            border-radius: 0.5rem;
            border: none;
            background: var(--gmail-primary);
            color: white;
            font-weight: 600;
            font-size: 1rem;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }

        .buy-button:hover {
            background: var(--gmail-primary-dark);
            transform: translateY(-2px);
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
        }

        .buy-button i {
            margin-right: 0.5rem;
        }

        /* Popup/Modal Tasarımı */
        .modal-content {
            background-color: var(--card-bg);
            border-radius: 0.75rem;
            border: 1px solid var(--card-border);
            box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }

        .modal-header {
            padding: 1.25rem 1.5rem;
            border-bottom: 1px solid #f3f4f6;
        }

        .modal-title {
            font-weight: 700;
            color: var(--text-primary) !important;
        }

        .modal-body {
            padding: 1.5rem;
        }

        .modal-footer {
            padding: 1.25rem 1.5rem;
            border-top: 1px solid #f3f4f6;
        }

        .btn-close {
            opacity: 0.7;
            transition: opacity 0.2s;
        }

        .btn-close:hover {
            opacity: 1;
        }

        /* Kartlar için giriş animasyonu */
        .account-card {
            animation: fadeInUp 0.4s ease-out forwards;
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* Kartların grid yapısında tek kartlı görünüm için düzenleme */
        .accounts-container {
            display: flex;
            justify-content: center;
            max-width: 600px;
            margin: 0 auto;
        }

        /* Duyarlı Tasarım */
        @media (max-width: 768px) {
            .card-header {
                flex-direction: column;
                align-items: flex-start;
            }

            .badge-stock {
                margin-top: 0.5rem;
            }
        }
    </style>

    @php
        // Tek ürün için basitleştirilmiş yapı
        $gmailTitle = "Gmail Hesapları (TR)";

        $gmailAccount = [
            'title' => $gmailTitle,
            'type' => 'gmail',
            'kayit' => 'Hesaplar, siz satın aldıktan sonra en az 12 saat ortalama 12-48 saat yaşarlar, bunu bilerek satın alınız.',
            'garanti' => 'İlk giriş esnasında herhangi bir problem yaşanması durumunda değişim yapılır.',
            'teslim' => 'Mail adresi, şifre, kurtarma e-postası, telefon numarası',
            'price' => 35, // Varsayılan fiyat
            'stock' => 0    // Varsayılan stok
        ];

        // Veritabanından ürün bilgilerini kontrol et
        foreach ($allProducts as $product) {
            if ($product->title === $gmailTitle) {
                $gmailAccount['price'] = $product->price;
                if (method_exists($product, 'stocks')) {
                    $gmailAccount['stock'] = $product->stocks()->where('status', 0)->count();
                }
                break;
            }
        }
    @endphp

    <div class="container">
        <!-- Sayfa Başlığı -->
        <div class="page-header">
            <h1 class="page-title">Gmail Hesap Market</h1>
            <p class="page-subtitle">Güvenilir Gmail hesaplarını anında teslim ve tam destek garantisiyle hemen satın alın.</p>
        </div>

        <!-- Tek Gmail Kart Görünümü -->
        <div class="accounts-container">
            <div class="account-card"
                 data-product-id="{{ isset($products[$gmailAccount['title']]) ? $products[$gmailAccount['title']]->id : '' }}"
                 data-stock="{{ $gmailAccount['stock'] }}">

                <div class="card-body">
                    <!-- Kart Başlığı -->
                    <div class="card-header">
                        <h3 class="card-title">{{ $gmailAccount['title'] }}</h3>
                        <span class="badge-stock">
                            <i class="ri-box-3-fill"></i>
                            {{ $gmailAccount['stock'] }} stok
                        </span>
                    </div>

                    <!-- Bilgi Tablosu -->
                    <div class="info-table">
                        <div class="info-row">
                            <div class="info-label"><i class="ri-time-line"></i></div>
                            <div class="info-value"><strong>Kayıt:</strong> {{ $gmailAccount['kayit'] }}</div>
                        </div>
                        <div class="info-row">
                            <div class="info-label"><i class="ri-shield-check-line"></i></div>
                            <div class="info-value"><strong>Garanti:</strong> {{ $gmailAccount['garanti'] }}</div>
                        </div>
                        <div class="info-row">
                            <div class="info-label"><i class="ri-inbox-line"></i></div>
                            <div class="info-value"><strong>Teslim:</strong> {{ $gmailAccount['teslim'] }}</div>
                        </div>
                    </div>

                    <!-- Fiyat ve Satın Alma Alanı -->
                    <div class="price-actions">
                        <div class="price-row">
                            <div class="quantity-control">
                                <button class="quantity-btn" onclick="decrease(this)">−</button>
                                <input type="text" class="quantity-input" value="1" data-price="{{ $gmailAccount['price'] }}" readonly>
                                <button class="quantity-btn" onclick="increase(this)">+</button>
                            </div>
                            <div class="total-price">{{ number_format($gmailAccount['price'], 2) }}₺</div>
                        </div>
                        <button class="buy-button" onclick="confirmPurchase('{{ $gmailAccount['title'] }}', {{ $gmailAccount['price'] }})">
                            <i class="ri-shopping-cart-line"></i> Satın Al
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Satın alma onay modali -->
    <div class="modal fade" id="purchaseModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Satın Almayı Onayla</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p id="modal-desc"></p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                    <button type="button" class="btn btn-primary" style="background-color: var(--gmail-primary); border-color: var(--gmail-primary-dark);">Evet, Satın Al</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Hata modalı -->
    <div class="modal fade" id="errorModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">⚠️ Hata Oluştu</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p id="error-modal-message" class="text-danger"></p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" data-bs-dismiss="modal">Tamam</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Başarılı işlem modalı -->
    <div class="modal fade" id="successModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title text-success">✅ Başarılı</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p id="success-modal-message"></p>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('script')
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const savedTab = localStorage.getItem('activeGmailTab');

            if (savedTab && document.getElementById(savedTab)) {
                // Tüm tabları pasifleştir
                document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
                document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));

                // Kaydedilmiş tabı aktif hale getir
                document.querySelector(`[data-target="${savedTab}"]`)?.classList.add('active');
                document.getElementById(savedTab)?.classList.add('active');
            } else {
                // Eğer localStorage boşsa, ilk sekmeyi aktif yap
                const firstBtn = document.querySelector('.tab-btn');
                const firstTabId = firstBtn?.dataset.target;
                firstBtn?.classList.add('active');
                document.getElementById(firstTabId)?.classList.add('active');
            }
        });

        const isLoggedIn = {{ auth()->check() ? 'true' : 'false' }};

        function updateTotal(input) {
            const price = parseFloat(input.dataset.price);
            const qty = parseInt(input.value) || 1;
            const totalEl = input.closest('.account-card').querySelector('.total-price');
            totalEl.textContent = (price * qty).toFixed(2).replace('.', ',') + '₺';
        }

        function increase(btn) {
            const input = btn.parentElement.querySelector('input');
            const card = btn.closest('.account-card');
            const maxStock = parseInt(card.dataset.stock);

            let current = parseInt(input.value);
            if (current < maxStock) {
                input.value = current + 1;
                updateTotal(input);
            }
        }

        function decrease(btn) {
            const input = btn.parentElement.querySelector('input');
            if (parseInt(input.value) > 1) {
                input.value = parseInt(input.value) - 1;
                updateTotal(input);
            }
        }

        function showSuccess(message) {
            const modal = new bootstrap.Modal(document.getElementById('successModal'));
            const messageContainer = document.getElementById('success-modal-message');

            let seconds = 5;
            const redirectUrl = `/panel/siparis/${window.latestOrderId}`;

            messageContainer.innerHTML = `
                ${message}
                <div class="progress mt-3" style="height: 20px;">
                    <div class="progress-bar progress-bar-animated bg-success"
                         role="progressbar"
                         style="width: 100%;"
                         id="redirectProgress">
                        <span id="countdown-text">${seconds}</span>
                    </div>
                </div>
            `;

            modal.show();

            const interval = setInterval(() => {
                seconds--;
                document.getElementById('countdown-text').textContent = `${seconds}`;
                document.getElementById('redirectProgress').style.width = `${seconds * 20}%`;

                if (seconds === 0) {
                    clearInterval(interval);
                    window.location.href = redirectUrl;
                }
            }, 1000);
        }

        function showError(message) {
            const errorModal = new bootstrap.Modal(document.getElementById('errorModal'));
            document.getElementById('error-modal-message').textContent = message;
            errorModal.show();
        }

        function confirmPurchase(title, price) {
            if (!isLoggedIn) {
                showError('Lütfen giriş yapın.');
                return;
            }

            const modal = new bootstrap.Modal(document.getElementById('purchaseModal'));
            const card = event.target.closest('.account-card');
            const quantityInput = card.querySelector('.quantity-input');
            const quantity = parseInt(quantityInput.value);
            const total = price * quantity;
            const balance = {{ auth()->user()->balance ?? 0 }};
            const productId = card.dataset.productId;

            document.getElementById('modal-desc').innerHTML = `
                <p>
                    <strong>Ürün:</strong> ${title}<br>
                    <strong>Adet:</strong> <span class="highlight">${quantity}</span><br>
                    <strong>Toplam Tutar:</strong> <span class="highlight">${total.toFixed(2).replace('.', ',')}₺</span><br>
                    <strong>Mevcut Bakiyeniz:</strong> ${balance.toFixed(2).replace('.', ',')}₺<br><br>
                    Bu işlemle bakiyenizden <span class="highlight">${total.toFixed(2).replace('.', ',')}₺</span> düşülecektir.
                </p>`;

            modal.show();

            const confirmBtn = document.querySelector('#purchaseModal .btn-primary');
            confirmBtn.onclick = null;

            confirmBtn.onclick = function () {
                fetch(@json(route('purchase')), {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    },
                    body: JSON.stringify({
                        product_id: productId,
                        quantity: quantity
                    })
                })
                    .then(async response => {
                        const data = await response.json();
                        if (!response.ok) {
                            throw new Error(data.error || 'Bilinmeyen bir hata oluştu.');
                        }
                        return data;
                    })
                    .then(data => {
                        bootstrap.Modal.getInstance(document.getElementById('purchaseModal')).hide();

                        if (data.success) {
                            window.latestOrderId = data.order_id;

                            const successMessage = `
                            <p>
                                🎉 <strong>Satın alma başarılı!</strong><br>
                                Sipariş detaylarına <strong>5</strong> saniye içinde yönlendirileceksiniz...
                            </p>`;
                            showSuccess(successMessage);
                        } else {
                            showError("Bilinmeyen bir hata oluştu.");
                        }
                    })
                    .catch(error => {
                        bootstrap.Modal.getInstance(document.getElementById('purchaseModal')).hide();
                        showError(error.message);
                    });
            };
        }

        // Sekme Geçişlerinde Titreme Sorununu Çözme
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                // Aktif sekmeyi kaydet
                localStorage.setItem('activeGmailTab', this.dataset.target);

                // Tüm sekme düğmelerini pasif yap
                document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
                // Bu sekme düğmesini aktif yap
                this.classList.add('active');

                // Önce tüm sekme içeriklerini gizle
                document.querySelectorAll('.tab-content').forEach(pane => {
                    pane.classList.remove('active');
                });

                // Ardından aktif sekmeyi göster
                document.getElementById(this.dataset.target).classList.add('active');
            });
        });
    </script>
    <script src="{{ URL::asset('build/js/app.js') }}"></script>
@endsection