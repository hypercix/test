@extends('layouts.master')
@section('title', 'SMS Onay Sistemi')

@section('content')
    <div class="container mt-4">
        <div class="card">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0">📱 SMS Onay Sistemi</h5>
            </div>
            <div class="card-body">
                <form id="smsRequestForm">
                    @csrf
                    <div class="row">
                        <div class="col-md-5">
                            <input type="text" class="form-control" name="service" placeholder="Servis (örnek: nttgame)" required>
                        </div>
                        <div class="col-md-3">
                            <input type="text" class="form-control" name="country" value="6" placeholder="Ülke" required>
                        </div>
                        <div class="col-md-4">
                            <button type="submit" class="btn btn-success w-100">📞 Numara Al</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <div id="smsTableWrapper" class="mt-4">
            <table class="table table-bordered table-striped text-center align-middle">
                <thead class="table-dark">
                <tr>
                    <th>⏳ Kalan</th>
                    <th>🛠️ Servis</th>
                    <th>💰 Ücret</th>
                    <th>📱 Numara</th>
                    <th>📨 Mesaj</th>
                    <th>📜 Geçmiş</th>
                    <th>⚙️ İşlem</th>
                </tr>
                </thead>
                <tbody id="smsTableBody">
                @foreach($requests as $request)
                    @php
                        $created = \Carbon\Carbon::parse($request->created_at);
                        $remaining = max(0, 1200 - now()->diffInSeconds($created));
                        $expired = $remaining === 0;
                        $hasSms = $request->status === 'received' || $request->messages->count() > 0;
                    @endphp
                    <tr data-id="{{ $request->id }}" data-created="{{ $request->created_at }}">
                        <td class="remaining-time text-nowrap">{{ $expired ? 'SÜRE BİTTİ' : gmdate("i:s", $remaining) }}</td>
                        <td>{{ $request->service }}</td>
                        <td>{{ number_format($request->cost, 2) }} ₺</td>
                        <td>
                            <span>{{ $request->number }}</span>
                            <button class="btn btn-sm btn-outline-primary copy-btn" data-copy="{{ $request->number }}">
                                <i class="fas fa-copy"></i>
                            </button>
                        </td>
                        <td class="sms-cell">
                            @if($request->status === 'received')
                                <span>{{ $request->received_sms }}</span>
                                <button class="btn btn-sm btn-outline-primary copy-btn" data-copy="{{ $request->received_sms }}">
                                    <i class="fas fa-copy"></i>
                                </button>
                            @else
                                <span class="text-muted">Bekleniyor...</span>
                            @endif
                        </td>
                        <td>
                            @if($request->messages->count())
                                <button class="btn btn-info btn-sm" onclick="showHistory({{ $request->id }})">Göster</button>
                            @else
                                <span class="text-muted">-</span>
                            @endif
                        </td>
                        <td class="actions-cell">
                            @if($expired)
                                <span class="text-danger">SÜRE BİTTİ</span>
                            @elseif($hasSms)
                                <button class="btn btn-sm btn-warning retry-btn" data-id="{{ $request->id }}">Tekrar SMS</button>
                            @else
                                <button class="btn btn-sm btn-warning retry-btn" data-id="{{ $request->id }}">Tekrar SMS</button>
                                <button class="btn btn-sm btn-danger cancel-btn" data-id="{{ $request->id }}">İptal Et</button>
                            @endif
                        </td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
    </div>

    <!-- Geçmiş SMS Modal -->
    <div class="modal fade" id="historyModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-sm">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">📜 Mesaj Geçmişi</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body" id="historyContent">
                    <p>Yükleniyor...</p>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('script')
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <script>
        async function showAlert(title, text, type = 'info') {
            await Swal.fire({ title, text, icon: type, confirmButtonText: 'Tamam' });
        }

        document.querySelector('#smsRequestForm').addEventListener('submit', async function(e) {
            e.preventDefault();
            const form = e.target;
            const service = form.service.value;
            const country = form.country.value;

            const res = await fetch("{{ route('sms.request.create') }}", {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': '{{ csrf_token() }}' },
                body: JSON.stringify({ service, country })
            });

            const data = await res.json();
            if (data.success) location.reload();
            else showAlert('Hata', data.message, 'error');
        });

        document.addEventListener('click', function(e) {
            if (e.target.closest('.copy-btn')) {
                const btn = e.target.closest('.copy-btn');
                const text = btn.dataset.copy;
                navigator.clipboard.writeText(text);
                btn.innerHTML = '<i class="fas fa-check"></i>';
                setTimeout(() => btn.innerHTML = '<i class="fas fa-copy"></i>', 1500);
            }
        });

        async function autoCheckSms() {
            const rows = document.querySelectorAll('tr[data-id]');
            for (const row of rows) {
                const id = row.dataset.id;
                const smsCell = row.querySelector('.sms-cell');
                const actionsCell = row.querySelector('.actions-cell');
                const created = new Date(row.dataset.created);
                const now = new Date();
                const diff = Math.floor((now - created) / 1000);
                const remaining = Math.max(0, 1200 - diff);

                // Süre bittiyse butonları kaldır
                if (remaining <= 0) {
                    actionsCell.innerHTML = `<span class="text-danger">SÜRE BİTTİ</span>`;
                    continue; // süre bittiyse artık mesaj kontrolüne gerek yok
                }

                // Mesaj varsa otomatik ekrana yaz
                if (smsCell.innerText.includes("Bekleniyor")) {
                    const res = await fetch(`/sms/check/${id}`);
                    const data = await res.json();
                    if (data.success) {
                        smsCell.innerHTML = `${data.sms} <button class="btn btn-sm btn-outline-primary copy-btn" data-copy="${data.sms}"><i class="fas fa-copy"></i></button>`;
                        actionsCell.innerHTML = `<button class="btn btn-sm btn-warning retry-btn" data-id="${id}">Tekrar SMS</button>`;
                    }
                }
            }
        }

        setInterval(autoCheckSms, 10000);

        function updateRemainingTime() {
            const rows = document.querySelectorAll('tr[data-id]');
            rows.forEach(row => {
                const created = new Date(row.dataset.created);
                const now = new Date();
                const diff = Math.floor((now - created) / 1000);
                const remaining = Math.max(0, 1200 - diff);
                const cell = row.querySelector('.remaining-time');
                cell.innerText = remaining > 0 ? `${String(Math.floor(remaining / 60)).padStart(2, '0')}:${String(remaining % 60).padStart(2, '0')}` : 'SÜRE BİTTİ';
                if (remaining <= 0) {
                    cell.classList.add('text-danger');
                }
            });
        }
        setInterval(updateRemainingTime, 1000);
        updateRemainingTime();

        async function showHistory(id) {
            const res = await fetch(`/api/sms/history/${id}`);
            const data = await res.json();
            const container = document.getElementById('historyContent');
            container.innerHTML = '';

            if (data.length === 0) {
                container.innerHTML = '<p>Henüz mesaj yok.</p>';
            } else {
                data.forEach(item => {
                    container.innerHTML += `<div class="alert alert-secondary mb-1">${item.message}</div>`;
                });
            }

            new bootstrap.Modal(document.getElementById('historyModal')).show();
        }

        document.addEventListener('click', function(e) {
            if (e.target.closest('.retry-btn')) {
                const id = e.target.closest('.retry-btn').dataset.id;
                fetch(`/sms/retry/${id}`)
                    .then(res => res.json())
                    .then(data => {
                        showAlert('Bilgi', data.message, data.success ? 'success' : 'error');
                        if (data.success) location.reload();
                    });
            }

            if (e.target.closest('.cancel-btn')) {
                const id = e.target.closest('.cancel-btn').dataset.id;
                fetch(`/sms/cancel/${id}`)
                    .then(res => res.json())
                    .then(data => {
                        showAlert('Bilgi', data.message, data.success ? 'success' : 'error');
                        if (data.success) location.reload();
                    });
            }
        });
    </script>
@endsection
