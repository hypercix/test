@extends('layouts.master')
@section('title', 'Proxy Siparişlerim')

@section('content')
    @component('components.breadcrumb')
        @slot('li_1') Panel @endslot
        @slot('title') Proxy Siparişlerim @endslot
    @endcomponent

    <div class="container">
        <!-- İstatistik Kartları -->
        <div class="row">
            <div class="col-md-4">
                <div class="card bg-primary bg-gradient text-white">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <div class="flex-shrink-0">
                                <i class="ri-shopping-cart-line fs-3"></i>
                            </div>
                            <div class="flex-grow-1 ms-3">
                                <h5 class="card-title text-white">Toplam Siparişler</h5>
                                <h3 class="mb-0">{{ $orders->total() }}</h3>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card bg-success bg-gradient text-white">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <div class="flex-shrink-0">
                                <i class="ri-check-double-line fs-3"></i>
                            </div>
                            <div class="flex-grow-1 ms-3">
                                <h5 class="card-title text-white">Tamamlanan</h5>
                                <h3 class="mb-0">{{ $orders->where('status', \App\Models\Order::STATUS_COMPLETED)->count() }}</h3>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card bg-warning bg-gradient text-white">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <div class="flex-shrink-0">
                                <i class="ri-time-line fs-3"></i>
                            </div>
                            <div class="flex-grow-1 ms-3">
                                <h5 class="card-title text-white">Bekleyen</h5>
                                <h3 class="mb-0">{{ $orders->where('status', \App\Models\Order::STATUS_PENDING)->count() }}</h3>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Sipariş Tablosu -->
        <div class="card mt-4">
            <div class="card-header d-flex align-items-center">
                <h5 class="card-title mb-0">Proxy Sipariş Geçmişim</h5>
                <div class="ms-auto">
                    <a href="{{ route('proxy.index') }}" class="btn btn-primary">
                        <i class="ri-add-circle-line me-1"></i> Yeni Proxy Satın Al
                    </a>
                </div>
            </div>
            <div class="card-body">
                @if($orders->count() > 0)
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped align-middle">
                            <thead class="table-light">
                            <tr>
                                <th>Sipariş No</th>
                                <th>Ürün</th>
                                <th>Miktar</th>
                                <th>Toplam</th>
                                <th>Durum</th>
                                <th>Tarih</th>
                                <th class="text-center">İşlem</th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($orders as $order)
                                <tr>
                                    <td>
                                        <span class="fw-medium">#{{ $order->id }}</span>
                                    </td>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <div class="flex-shrink-0 me-2">
                                                <div class="avatar-xs">
                                                    <div class="avatar-title bg-soft-primary text-primary rounded">
                                                        <i class="ri-shield-line"></i>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="flex-grow-1">
                                                {{ $order->product->title }}
                                            </div>
                                        </div>
                                    </td>
                                    <td>{{ $order->quantity }}</td>
                                    <td class="fw-medium text-primary">{{ number_format($order->price, 2) }} ₺</td>
                                    <td>
                                        @if($order->status === \App\Models\Order::STATUS_PENDING)
                                            <span class="badge bg-warning">Beklemede</span>
                                        @elseif($order->status === \App\Models\Order::STATUS_COMPLETED)
                                            <span class="badge bg-success">Tamamlandı</span>
                                        @elseif($order->status === \App\Models\Order::STATUS_CANCELLED)
                                            <span class="badge bg-danger">İptal Edildi</span>
                                        @endif
                                    </td>
                                    <td>
                                        <div class="d-flex flex-column">
                                            <span>{{ $order->created_at->format('d.m.Y') }}</span>
                                            <small class="text-muted">{{ $order->created_at->format('H:i') }}</small>
                                        </div>
                                    </td>
                                    <td class="text-center">
                                        <a href="{{ route('proxy.order-detail', $order->id) }}" class="btn btn-sm btn-primary">
                                            <i class="ri-eye-line"></i> Detay
                                        </a>
                                    </td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                    </div>

                    <div class="mt-3 d-flex justify-content-end">
                        {{ $orders->links() }}
                    </div>
                @else
                    <div class="text-center py-5">
                        <i class="ri-inbox-line display-4 text-muted"></i>
                        <h5 class="mt-3">Henüz Proxy Siparişiniz Bulunmuyor</h5>
                        <p class="text-muted">Hemen yeni bir proxy satın alabilir ve Knight Online oyun deneyiminizi yükseltebilirsiniz.</p>
                        <a href="{{ route('proxy.index') }}" class="btn btn-primary mt-2">
                            <i class="ri-shopping-cart-line me-1"></i> Proxy Satın Al
                        </a>
                    </div>
                @endif
            </div>
        </div>

        <!-- Bilgi Kartı -->
        <div class="card mt-4">
            <div class="card-body">
                <div class="d-flex">
                    <div class="flex-shrink-0">
                        <i class="ri-information-line fs-2 text-primary"></i>
                    </div>
                    <div class="flex-grow-1 ms-3">
                        <h5>Knight Online Proxy Hakkında</h5>
                        <p class="mb-0">
                            Proxy hizmetimiz, Knight Online oyununuzu daha düşük ping değerleriyle oynamanıza olanak tanır.
                            Siparişleriniz manuel olarak hazırlanmakta ve en kısa sürede teslim edilmektedir.
                            Sorularınız için destek ekibimizle iletişime geçebilirsiniz.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection