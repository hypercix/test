@extends('layouts.master')
@section('title', 'Proxy Sipariş Detayı')

@section('content')
    @component('components.breadcrumb')
        @slot('li_1') Panel @endslot
        @slot('li_2') Siparişlerim @endslot
        @slot('title') Proxy Sipariş Detayı @endslot
    @endcomponent

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-xl-8">
                <div class="card order-detail-card">
                    <!-- Sipariş Başlığı -->
                    <div class="card-header bg-primary text-white">
                        <div class="d-flex align-items-center">
                            <h5 class="mb-0">
                                <i class="ri-shield-line me-2"></i> Proxy Sipariş Detayı
                                <span class="badge bg-light text-primary ms-2">#{{ $order->id }}</span>
                            </h5>
                            <div class="ms-auto">
                                @if($order->status === \App\Models\Order::STATUS_PENDING)
                                    <span class="badge bg-warning">Beklemede</span>
                                @elseif($order->status === \App\Models\Order::STATUS_COMPLETED)
                                    <span class="badge bg-success">Tamamlandı</span>
                                @elseif($order->status === \App\Models\Order::STATUS_CANCELLED)
                                    <span class="badge bg-danger">İptal Edildi</span>
                                @endif
                            </div>
                        </div>
                    </div>

                    <!-- Sipariş Bilgileri -->
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6 mb-4">
                                <div class="d-flex">
                                    <div class="flex-shrink-0">
                                        <div class="avatar-sm bg-light rounded d-flex align-items-center justify-content-center">
                                            <i class="ri-shopping-bag-line text-primary fs-20"></i>
                                        </div>
                                    </div>
                                    <div class="flex-grow-1 ms-3">
                                        <h6 class="text-muted mb-1">Ürün</h6>
                                        <h5 class="mb-0">{{ $order->product->title }}</h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 mb-4">
                                <div class="d-flex">
                                    <div class="flex-shrink-0">
                                        <div class="avatar-sm bg-light rounded d-flex align-items-center justify-content-center">
                                            <i class="ri-money-dollar-circle-line text-primary fs-20"></i>
                                        </div>
                                    </div>
                                    <div class="flex-grow-1 ms-3">
                                        <h6 class="text-muted mb-1">Toplam Tutar</h6>
                                        <h5 class="text-primary mb-0">{{ number_format($order->price, 2) }} ₺</h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 mb-4">
                                <div class="d-flex">
                                    <div class="flex-shrink-0">
                                        <div class="avatar-sm bg-light rounded d-flex align-items-center justify-content-center">
                                            <i class="ri-calendar-line text-primary fs-20"></i>
                                        </div>
                                    </div>
                                    <div class="flex-grow-1 ms-3">
                                        <h6 class="text-muted mb-1">Sipariş Tarihi</h6>
                                        <h5 class="mb-0">{{ $order->created_at->format('d.m.Y H:i') }}</h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 mb-4">
                                <div class="d-flex">
                                    <div class="flex-shrink-0">
                                        <div class="avatar-sm bg-light rounded d-flex align-items-center justify-content-center">
                                            <i class="ri-stack-line text-primary fs-20"></i>
                                        </div>
                                    </div>
                                    <div class="flex-grow-1 ms-3">
                                        <h6 class="text-muted mb-1">Miktar</h6>
                                        <h5 class="mb-0">{{ $order->quantity }} adet</h5>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Teslimat Durumu -->
                        <div class="border rounded p-3 mt-4">
                            @if($order->status === \App\Models\Order::STATUS_PENDING)
                                <div class="d-flex align-items-center">
                                    <div class="flex-shrink-0">
                                        <i class="ri-time-line fs-24 text-warning"></i>
                                    </div>
                                    <div class="flex-grow-1 ms-3">
                                        <h5 class="text-warning mb-1">Siparişiniz Hazırlanıyor</h5>
                                        <p class="mb-0">Proxy bilgileriniz en kısa sürede hazırlanacak ve size teslim edilecektir. Lütfen bekleyiniz.</p>
                                    </div>
                                </div>
                                <div class="mt-3">
                                    <div class="progress" style="height: 6px;">
                                        <div class="progress-bar progress-bar-striped progress-bar-animated bg-warning" role="progressbar" style="width: 50%" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                </div>
                            @elseif($order->status === \App\Models\Order::STATUS_COMPLETED)
                                <div class="d-flex align-items-center">
                                    <div class="flex-shrink-0">
                                        <i class="ri-check-double-line fs-24 text-success"></i>
                                    </div>
                                    <div class="flex-grow-1 ms-3">
                                        <h5 class="text-success mb-1">Siparişiniz Tamamlandı</h5>
                                        <p class="mb-0">Proxy bilgileriniz aşağıda hazır. Sorun yaşamanız durumunda lütfen destek ekibimizle iletişime geçin.</p>
                                    </div>
                                </div>
                                <div class="mt-3">
                                    <div class="progress" style="height: 6px;">
                                        <div class="progress-bar bg-success" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                </div>
                            @elseif($order->status === \App\Models\Order::STATUS_CANCELLED)
                                <div class="d-flex align-items-center">
                                    <div class="flex-shrink-0">
                                        <i class="ri-close-circle-line fs-24 text-danger"></i>
                                    </div>
                                    <div class="flex-grow-1 ms-3">
                                        <h5 class="text-danger mb-1">Siparişiniz İptal Edildi</h5>
                                        <p class="mb-0">Bu sipariş iptal edilmiş ve ödeme tutarı hesabınıza iade edilmiştir.</p>
                                    </div>
                                </div>
                                <div class="mt-3">
                                    <div class="progress" style="height: 6px;">
                                        <div class="progress-bar bg-danger" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                </div>
                            @endif
                        </div>

                        <!-- Teslim Edilen Proxy Bilgileri -->
                        @if($order->status === \App\Models\Order::STATUS_COMPLETED && $order->delivery_content)
                            <div class="mt-4">
                                <h5 class="mb-3">Proxy Bilgileriniz</h5>
                                <div class="proxy-content position-relative">
                                    <div class="border rounded bg-light p-3">
                                        <button class="btn btn-sm btn-primary position-absolute top-0 end-0 m-2" id="copyButton">
                                            <i class="ri-file-copy-line"></i> Kopyala
                                        </button>
                                        <pre class="mb-0" style="white-space: pre-wrap; word-break: break-all;">{{ $order->delivery_content }}</pre>
                                    </div>
                                </div>

                                <div class="alert alert-info mt-3">
                                    <div class="d-flex">
                                        <div class="flex-shrink-0">
                                            <i class="ri-information-line me-2"></i>
                                        </div>
                                        <div>
                                            <h6>Nasıl Kullanılır?</h6>
                                            <p class="mb-0">
                                                Proxy bilgilerinizi Knight Online oyununuzda veya 3. parti programlarda kullanabilirsiniz.
                                                Format: IP:PORT:KULLANICI:ŞİFRE şeklindedir.
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        @endif
                    </div>

                    <!-- Sipariş Footer -->
                    <div class="card-footer bg-light d-flex justify-content-between align-items-center">
                        <a href="{{ route('proxy.orders') }}" class="btn btn-secondary">
                            <i class="ri-arrow-left-line me-1"></i> Tüm Siparişlere Dön
                        </a>

                        @if($order->status === \App\Models\Order::STATUS_COMPLETED)
                            <a href="{{ route('proxy.index') }}" class="btn btn-primary">
                                <i class="ri-shopping-cart-line me-1"></i> Yeni Sipariş Ver
                            </a>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('script')
    <script>
        // Kopyalama fonksiyonu
        document.addEventListener('DOMContentLoaded', function() {
            const copyButton = document.getElementById('copyButton');
            if (copyButton) {
                copyButton.addEventListener('click', function() {
                    const content = document.querySelector('pre').textContent;
                    navigator.clipboard.writeText(content)
                        .then(() => {
                            copyButton.innerHTML = '<i class="ri-check-line"></i> Kopyalandı';
                            setTimeout(() => {
                                copyButton.innerHTML = '<i class="ri-file-copy-line"></i> Kopyala';
                            }, 2000);
                        })
                        .catch(err => {
                            console.error('Kopyalama hatası:', err);
                        });
                });
            }
        });
    </script>
@endsection