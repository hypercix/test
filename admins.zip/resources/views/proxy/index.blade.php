@extends('layouts.master')
@section('title', 'Knight Online Proxy Satın Al')

@section('content')
    @component('components.breadcrumb')
        @slot('li_1') Satın Al @endslot
        @slot('title') Knight Online Proxy @endslot
    @endcomponent

    <div class="container">
        <div class="proxy-header text-center mb-5">
            <h1 class="proxy-title mb-2">Knight Online <span class="highlight">Proxy</span> Satış</h1>
            <p class="proxy-subtitle">Özel, yüksek hızlı ve güvenli proxy servislerimizle oyun deneyiminizi zirveye taşıyın. Stabil bağlantı ve düşük ping garantisi.</p>
        </div>

        <!-- Öne Çıkan Paketler -->
        <div class="proxy-packages">
            <div class="row">
                <!-- 1 Adet Proxy -->
                <div class="col-lg-3 col-md-6 mb-4">
                    <div class="proxy-card h-100">
                        <div class="proxy-card-header">
                            <div class="proxy-icon">
                                <i class="ri-shield-star-line"></i>
                            </div>
                            <h3 class="proxy-name">1 Adet Knight Online Proxy</h3>
                            <div class="proxy-price">60₺</div>
                        </div>
                        <div class="proxy-card-body">
                            <ul class="proxy-features">
                                <li><i class="ri-check-line"></i> 30 Günlük Kullanım</li>
                                <li><i class="ri-check-line"></i> Vodafone-Turkcell-Türk Telekom</li>
                                <li><i class="ri-check-line"></i> En Düşük Ping Değerleri</li>
                                <li><i class="ri-check-line"></i> Socks5 Proxy</li>
                                <li><i class="ri-check-line"></i> Kişiye Özel Kullanıcı Adı & Şifre</li>
                                <li><i class="ri-check-line"></i> 1000 Mbit Download & Upload</li>
                            </ul>
                            <button class="btn-buy" onclick="buyProxy('1 Adet Knight Online Proxy', 60, 1)">Satın Al</button>
                        </div>
                    </div>
                </div>

                <!-- 4 Adet Proxy -->
                <div class="col-lg-3 col-md-6 mb-4">
                    <div class="proxy-card h-100">
                        <div class="proxy-card-header">
                            <div class="proxy-icon">
                                <i class="ri-shield-star-line"></i>
                            </div>
                            <h3 class="proxy-name">4 Adet Knight Online Proxy</h3>
                            <div class="proxy-price">200₺</div>
                        </div>
                        <div class="proxy-card-body">
                            <ul class="proxy-features">
                                <li><i class="ri-check-line"></i> 30 Günlük Kullanım</li>
                                <li><i class="ri-check-line"></i> Vodafone-Turkcell-Türk Telekom</li>
                                <li><i class="ri-check-line"></i> En Düşük Ping Değerleri</li>
                                <li><i class="ri-check-line"></i> Socks5 Proxy</li>
                                <li><i class="ri-check-line"></i> Kişiye Özel Kullanıcı Adı & Şifre</li>
                                <li><i class="ri-check-line"></i> 1000 Mbit Download & Upload</li>
                            </ul>
                            <button class="btn-buy" onclick="buyProxy('4 Adet Knight Online Proxy', 200, 4)">Satın Al</button>
                        </div>
                    </div>
                </div>

                <!-- 8 Adet Proxy -->
                <div class="col-lg-3 col-md-6 mb-4">
                    <div class="proxy-card h-100 popular">
                        <div class="popular-tag">En Çok Satan</div>
                        <div class="proxy-card-header">
                            <div class="proxy-icon">
                                <i class="ri-shield-star-line"></i>
                            </div>
                            <h3 class="proxy-name">8 Adet Knight Online Proxy</h3>
                            <div class="proxy-price">350₺</div>
                        </div>
                        <div class="proxy-card-body">
                            <ul class="proxy-features">
                                <li><i class="ri-check-line"></i> 30 Günlük Kullanım</li>
                                <li><i class="ri-check-line"></i> Vodafone-Turkcell-Türk Telekom</li>
                                <li><i class="ri-check-line"></i> En Düşük Ping Değerleri</li>
                                <li><i class="ri-check-line"></i> Socks5 Proxy</li>
                                <li><i class="ri-check-line"></i> Kişiye Özel Kullanıcı Adı & Şifre</li>
                                <li><i class="ri-check-line"></i> 1000 Mbit Download & Upload</li>
                            </ul>
                            <button class="btn-buy" onclick="buyProxy('8 Adet Knight Online Proxy', 350, 8)">Satın Al</button>
                        </div>
                    </div>
                </div>

                <!-- 24 Adet Proxy -->
                <div class="col-lg-3 col-md-6 mb-4">
                    <div class="proxy-card h-100">
                        <div class="proxy-card-header">
                            <div class="proxy-icon">
                                <i class="ri-shield-star-line"></i>
                            </div>
                            <h3 class="proxy-name">24 Adet Knight Online Proxy</h3>
                            <div class="proxy-price">700₺</div>
                        </div>
                        <div class="proxy-card-body">
                            <ul class="proxy-features">
                                <li><i class="ri-check-line"></i> 30 Günlük Kullanım</li>
                                <li><i class="ri-check-line"></i> Vodafone-Turkcell-Türk Telekom</li>
                                <li><i class="ri-check-line"></i> En Düşük Ping Değerleri</li>
                                <li><i class="ri-check-line"></i> Socks5 Proxy</li>
                                <li><i class="ri-check-line"></i> Kişiye Özel Kullanıcı Adı & Şifre</li>
                                <li><i class="ri-check-line"></i> 1000 Mbit Download & Upload</li>
                            </ul>
                            <button class="btn-buy" onclick="buyProxy('24 Adet Knight Online Proxy', 700, 24)">Satın Al</button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row mt-4">
                <!-- 48 Adet Proxy -->
                <div class="col-lg-3 col-md-6 mb-4">
                    <div class="proxy-card h-100">
                        <div class="proxy-card-header">
                            <div class="proxy-icon">
                                <i class="ri-shield-star-line"></i>
                            </div>
                            <h3 class="proxy-name">48 Adet Knight Online Proxy</h3>
                            <div class="proxy-price">1350₺</div>
                        </div>
                        <div class="proxy-card-body">
                            <ul class="proxy-features">
                                <li><i class="ri-check-line"></i> 30 Günlük Kullanım</li>
                                <li><i class="ri-check-line"></i> Vodafone-Turkcell-Türk Telekom</li>
                                <li><i class="ri-check-line"></i> En Düşük Ping Değerleri</li>
                                <li><i class="ri-check-line"></i> Socks5 Proxy</li>
                                <li><i class="ri-check-line"></i> Kişiye Özel Kullanıcı Adı & Şifre</li>
                                <li><i class="ri-check-line"></i> 1000 Mbit Download & Upload</li>
                            </ul>
                            <button class="btn-buy" onclick="buyProxy('48 Adet Knight Online Proxy', 1350, 48)">Satın Al</button>
                        </div>
                    </div>
                </div>

                <!-- 96 Adet Proxy -->
                <div class="col-lg-3 col-md-6 mb-4">
                    <div class="proxy-card h-100 premium">
                        <div class="premium-tag">Önerilen</div>
                        <div class="proxy-card-header">
                            <div class="proxy-icon">
                                <i class="ri-shield-star-line"></i>
                            </div>
                            <h3 class="proxy-name">96 Adet Knight Online Proxy</h3>
                            <div class="proxy-price">2500₺</div>
                        </div>
                        <div class="proxy-card-body">
                            <ul class="proxy-features">
                                <li><i class="ri-check-line"></i> 30 Günlük Kullanım</li>
                                <li><i class="ri-check-line"></i> Vodafone-Turkcell-Türk Telekom</li>
                                <li><i class="ri-check-line"></i> En Düşük Ping Değerleri</li>
                                <li><i class="ri-check-line"></i> Socks5 Proxy</li>
                                <li><i class="ri-check-line"></i> Kişiye Özel Kullanıcı Adı & Şifre</li>
                                <li><i class="ri-check-line"></i> 1000 Mbit Download & Upload</li>
                            </ul>
                            <button class="btn-buy" onclick="buyProxy('96 Adet Knight Online Proxy', 2500, 96)">Satın Al</button>
                        </div>
                    </div>
                </div>

                <!-- 150 Adet Proxy -->
                <div class="col-lg-3 col-md-6 mb-4">
                    <div class="proxy-card h-100">
                        <div class="proxy-card-header">
                            <div class="proxy-icon">
                                <i class="ri-shield-star-line"></i>
                            </div>
                            <h3 class="proxy-name">150 Adet Knight Online Proxy</h3>
                            <div class="proxy-price">3500₺</div>
                        </div>
                        <div class="proxy-card-body">
                            <ul class="proxy-features">
                                <li><i class="ri-check-line"></i> 30 Günlük Kullanım</li>
                                <li><i class="ri-check-line"></i> Vodafone-Turkcell-Türk Telekom</li>
                                <li><i class="ri-check-line"></i> En Düşük Ping Değerleri</li>
                                <li><i class="ri-check-line"></i> Socks5 Proxy</li>
                                <li><i class="ri-check-line"></i> Kişiye Özel Kullanıcı Adı & Şifre</li>
                                <li><i class="ri-check-line"></i> 1000 Mbit Download & Upload</li>
                            </ul>
                            <button class="btn-buy" onclick="buyProxy('150 Adet Knight Online Proxy', 3500, 150)">Satın Al</button>
                        </div>
                    </div>
                </div>

                <!-- 250 Adet Proxy -->
                <div class="col-lg-3 col-md-6 mb-4">
                    <div class="proxy-card h-100">
                        <div class="proxy-card-header">
                            <div class="proxy-icon">
                                <i class="ri-shield-star-line"></i>
                            </div>
                            <h3 class="proxy-name">250 Adet Knight Online Proxy</h3>
                            <div class="proxy-price">5500₺</div>
                        </div>
                        <div class="proxy-card-body">
                            <ul class="proxy-features">
                                <li><i class="ri-check-line"></i> 30 Günlük Kullanım</li>
                                <li><i class="ri-check-line"></i> Vodafone-Turkcell-Türk Telekom</li>
                                <li><i class="ri-check-line"></i> En Düşük Ping Değerleri</li>
                                <li><i class="ri-check-line"></i> Socks5 Proxy</li>
                                <li><i class="ri-check-line"></i> Kişiye Özel Kullanıcı Adı & Şifre</li>
                                <li><i class="ri-check-line"></i> 1000 Mbit Download & Upload</li>
                            </ul>
                            <button class="btn-buy" onclick="buyProxy('250 Adet Knight Online Proxy', 5500, 250)">Satın Al</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Bilgi Alanı -->
        <div class="info-section mt-5">
            <h2 class="section-title">Knight Online Proxy Nedir?</h2>
            <p>Knight Online proxy, oyun sırasında yaşanabilecek gecikme (lag) ve bağlantı sorunlarını en aza indirmeyi amaçlayan özel bir hizmettir. Proxy sunucularımız, internet trafiğinizi optimize ederek oyuna daha hızlı ve kararlı bir bağlantı sağlar.</p>

            <p>Özellikle PK (Player Kill) sırasında milisaniyelerin bile önemli olduğu Knight Online'da, düşük ping değeri başarınızın anahtarıdır. Proxy servisimiz, size rakiplerinize karşı avantaj sağlayarak oyun deneyiminizi iyileştirir.</p>

            <h3 class="mt-4">Neden Bizi Tercih Etmelisiniz?</h3>
            <div class="row mt-3">
                <div class="col-md-6">
                    <div class="benefit-item">
                        <i class="ri-wifi-line"></i>
                        <div>
                            <h4>Hızlı ve Stabil Bağlantı</h4>
                            <p>Vodafone, Turkcell ve Türk Telekom operatörleri için optimize edilmiş özel hatlar sayesinde en düşük ping değerlerini elde edin.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="benefit-item">
                        <i class="ri-shield-check-line"></i>
                        <div>
                            <h4>Güvenlik ve Gizlilik</h4>
                            <p>Kişiye özel kullanıcı adı ve şifre ile güvenli bağlantı, IP adresinizi gizleyerek oyun sırasında korunmanızı sağlar.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="benefit-item">
                        <i class="ri-customer-service-2-line"></i>
                        <div>
                            <h4>7/24 Teknik Destek</h4>
                            <p>Herhangi bir sorun yaşadığınızda teknik ekibimiz her zaman yardıma hazır. Kesintisiz bir oyun deneyimi için yanınızdayız.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="benefit-item">
                        <i class="ri-rocket-line"></i>
                        <div>
                            <h4>Yüksek Bandgenişliği</h4>
                            <p>1000 Mbit Download & Upload hızı ile gecikmesiz, akıcı ve kesintisiz bir oyun deneyimi yaşayın.</p>
                        </div>
                    </div>
                </div>
            </div>

            <h3 class="mt-4">Sıkça Sorulan Sorular</h3>
            <div class="accordion mt-3" id="faqAccordion">
                <div class="accordion-item">
                    <h2 class="accordion-header" id="faqOne">
                        <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                            Proxy'i nasıl kuracağım?
                        </button>
                    </h2>
                    <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="faqOne" data-bs-parent="#faqAccordion">
                        <div class="accordion-body">
                            Satın alma işleminiz tamamlandıktan sonra, proxy bilgileriniz (IP, port, kullanıcı adı ve şifre) size otomatik olarak iletilecektir. Ayrıca kurulum için detaylı PDF kılavuzu da teslimat ile birlikte verilmektedir.
                        </div>
                    </div>
                </div>
                <div class="accordion-item">
                    <h2 class="accordion-header" id="faqTwo">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                            Proxy'in süresi ne kadar?
                        </button>
                    </h2>
                    <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="faqTwo" data-bs-parent="#faqAccordion">
                        <div class="accordion-body">
                            Tüm proxy paketlerimiz 30 günlük kullanım içindir. Bu süre sonunda yenileme yapabilirsiniz.
                        </div>
                    </div>
                </div>
                <div class="accordion-item">
                    <h2 class="accordion-header" id="faqThree">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                            Ping değerleri ne kadar düşük olacak?
                        </button>
                    </h2>
                    <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="faqThree" data-bs-parent="#faqAccordion">
                        <div class="accordion-body">
                            Knight Online için optimize edilmiş proxy servisimiz sayesinde, bağlantınıza ve konumunuza bağlı olarak ping değerlerinizde 20-50ms arasında düşüş görebilirsiniz.
                        </div>
                    </div>
                </div>
                <div class="accordion-item">
                    <h2 class="accordion-header" id="faqFour">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                            Birden fazla bilgisayarda kullanabilir miyim?
                        </button>
                    </h2>
                    <div id="collapseFour" class="accordion-collapse collapse" aria-labelledby="faqFour" data-bs-parent="#faqAccordion">
                        <div class="accordion-body">
                            Her proxy sadece bir bağlantı için geçerlidir. Birden fazla bilgisayarda kullanmak istiyorsanız, ihtiyacınıza göre paket seçimi yapabilirsiniz.
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Satın Alma Modal -->
    <div class="modal fade" id="purchaseModal" tabindex="-1" aria-labelledby="purchaseModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="purchaseModalLabel">Satın Alma Onayı</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div id="modal-content"></div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                    <button type="button" class="btn btn-primary" id="confirmPurchase">Satın Al</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Hata Modal -->
    <div class="modal fade" id="errorModal" tabindex="-1" aria-labelledby="errorModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title text-danger" id="errorModalLabel">Hata</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div id="error-content"></div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" data-bs-dismiss="modal">Tamam</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Başarılı İşlem Modal -->
    <div class="modal fade" id="successModal" tabindex="-1" aria-labelledby="successModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title text-success" id="successModalLabel">İşlem Başarılı</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div id="success-content"></div>
                    <div class="progress mt-3">
                        <div class="progress-bar progress-bar-striped progress-bar-animated bg-success" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100" id="redirectProgress"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('css')
    <style>
        /* Proxy Sayfası Stil Tanımlamaları */
        :root {
            --primary-color: #4284F5;
            --primary-dark: #2e70e0;
            --primary-light: #5b95f6;
            --primary-gradient: linear-gradient(135deg, #5b95f6, #2e70e0);
            --accent-color: #FF6B6B;
            --text-color: #333;
            --text-secondary: #777;
            --bg-color: #f8f9fa;
            --card-bg: #fff;
            --border-color: #e0e0e0;
            --shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            --hover-shadow: 0 10px 15px rgba(0, 0, 0, 0.15);
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 40px 15px;
        }

        /* Header Stil */
        .proxy-title {
            font-size: 2.5rem;
            font-weight: 800;
            color: var(--text-color);
        }

        .proxy-title .highlight {
            color: var(--primary-color);
        }

        .proxy-subtitle {
            font-size: 1.1rem;
            color: var(--text-secondary);
            max-width: 800px;
            margin: 0 auto;
        }

        /* Proxy Kart Stilleri */
        .proxy-card {
            background: var(--card-bg);
            border-radius: 12px;
            overflow: hidden;
            box-shadow: var(--shadow);
            transition: all 0.3s ease;
            border: 1px solid var(--border-color);
            height: 100%;
            display: flex;
            flex-direction: column;
            position: relative;
        }

        .proxy-card:hover {
            transform: translateY(-5px);
            box-shadow: var(--hover-shadow);
            border-color: var(--primary-light);
        }

        .proxy-card.popular {
            border: 2px solid var(--accent-color);
        }

        .proxy-card.premium {
            border: 2px solid var(--primary-color);
        }

        .popular-tag, .premium-tag {
            position: absolute;
            top: 10px;
            right: 10px;
            background: var(--accent-color);
            color: white;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: 600;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
        }

        .premium-tag {
            background: var(--primary-color);
        }

        .proxy-card-header {
            padding: 1.5rem;
            text-align: center;
            border-bottom: 1px solid var(--border-color);
        }

        .proxy-icon {
            width: 60px;
            height: 60px;
            margin: 0 auto 15px;
            background: var(--primary-light);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .proxy-icon i {
            font-size: 28px;
            color: white;
        }

        .proxy-name {
            font-size: 1.1rem;
            font-weight: 600;
            margin-bottom: 10px;
            color: var(--text-color);
            min-height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .proxy-price {
            font-size: 1.8rem;
            font-weight: 700;
            color: var(--primary-color);
        }

        .proxy-card-body {
            padding: 1.5rem;
            flex-grow: 1;
            display: flex;
            flex-direction: column;
        }

        .proxy-features {
            list-style: none;
            padding: 0;
            margin: 0 0 1.5rem;
            flex-grow: 1;
        }

        .proxy-features li {
            display: flex;
            align-items: flex-start;
            margin-bottom: 10px;
            color: var(--text-secondary);
        }

        .proxy-features li i {
            color: var(--primary-color);
            margin-right: 8px;
            font-size: 18px;
            flex-shrink: 0;
        }

        .btn-buy {
            background: var(--primary-gradient);
            color: white;
            border: none;
            padding: 12px 24px;
            border-radius: 50px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: block;
            width: 100%;
            text-align: center;
            box-shadow: 0 4px 6px rgba(46, 112, 224, 0.3);
        }

        .btn-buy:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 8px rgba(46, 112, 224, 0.4);
        }

        /* Bilgi Alanı Stilleri */
        .info-section {
            background: var(--card-bg);
            border-radius: 12px;
            padding: 2rem;
            box-shadow: var(--shadow);
            margin-top: 3rem;
        }

        .section-title {
            font-size: 1.8rem;
            font-weight: 700;
            color: var(--text-color);
            margin-bottom: 1.5rem;
            position: relative;
            padding-bottom: 0.5rem;
        }

        .section-title:after {
            content: '';
            position: absolute;
            left: 0;
            bottom: 0;
            width: 60px;
            height: 3px;
            background: var(--primary-color);
        }

        .benefit-item {
            display: flex;
            margin-bottom: 1.5rem;
        }

        .benefit-item i {
            font-size: 2rem;
            color: var(--primary-color);
            margin-right: 1rem;
        }

        .benefit-item h4 {
            font-size: 1.2rem;
            font-weight: 600;
            color: var(--text-color);
            margin-bottom: 0.5rem;
        }

        .benefit-item p {
            color: var(--text-secondary);
            margin: 0;
        }

        /* Accordion Stil */
        .accordion {
            border-radius: 8px;
            overflow: hidden;
        }

        .accordion-item {
            border: 1px solid var(--border-color);
        }

        .accordion-header {
            margin: 0;
        }

        .accordion-button {
            font-weight: 600;
            color: var(--text-color);
            background-color: var(--card-bg);
            padding: 1rem 1.25rem;
        }

        .accordion-button:not(.collapsed) {
            background-color: rgba(66, 132, 245, 0.1);
            color: var(--primary-color);
        }

        .accordion-button:focus {
            box-shadow: none;
            border-color: var(--primary-light);
        }

        .accordion-body {
            padding: 1rem 1.25rem;
            color: var(--text-secondary);
        }

        /* Modal Stil */
        .modal-content {
            border-radius: 12px;
            border: none;
        }

        .modal-header {
            border-bottom: 1px solid var(--border-color);
            padding: 1.25rem;
        }

        .modal-body {
            padding: 1.5rem;
        }

        .modal-footer {
            border-top: 1px solid var(--border-color);
            padding: 1.25rem;
        }

        #confirmPurchase {
            background: var(--primary-color);
            border-color: var(--primary-dark);
        }

        /* Duyarlı Tasarım */
        @media (max-width: 992px) {
            .proxy-title {
                font-size: 2rem;
            }
        }

        @media (max-width: 768px) {
            .container {
                padding: 20px 15px;
            }

            .proxy-title {
                font-size: 1.8rem;
            }

            .proxy-subtitle {
                font-size: 1rem;
            }

            .section-title {
                font-size: 1.5rem;
            }
        }
    </style>
@endsection

@section('script')
    <script>
        let selectedProduct = null;
        let selectedPrice = 0;
        let selectedQuantity = 0;

        function buyProxy(product, price, quantity) {
            if (!{{ auth()->check() ? 'true' : 'false' }}) {
                showError('Satın alma işlemi yapabilmek için giriş yapmalısınız.');
                return;
            }

            selectedProduct = product;
            selectedPrice = price;
            selectedQuantity = quantity;

            const balance = {{ auth()->check() ? auth()->user()->balance : 0 }};

            // Modal içeriğini hazırla
            document.getElementById('modal-content').innerHTML = `
            <div class="purchase-details">
                <div class="mb-3">
                    <strong>Ürün:</strong> ${product}
                </div>
                <div class="mb-3">
                    <strong>Adet:</strong> ${quantity}
                </div>
                <div class="mb-3">
                    <strong>Fiyat:</strong> ${price.toFixed(2)}₺
                </div>
                <div class="mb-3">
                    <strong>Bakiyeniz:</strong> ${balance.toFixed(2)}₺
                </div>
                <hr>
                <div class="alert ${balance >= price ? 'alert-info' : 'alert-warning'}">
                    ${balance >= price ?
                'Bu işlemi onayladığınızda, belirtilen tutarda bakiyeniz düşülecek ve satın aldığınız proxy bilgileri size iletilecektir.' :
                '<strong>Uyarı:</strong> Bakiyeniz yetersiz. Lütfen bakiye yükleyip tekrar deneyiniz.'}
                </div>
            </div>
        `;

            // Onay butonunu aktif/pasif yap
            const confirmButton = document.getElementById('confirmPurchase');
            if (balance >= price) {
                confirmButton.disabled = false;
            } else {
                confirmButton.disabled = true;
            }

            // Modal'ı göster
            const purchaseModal = new bootstrap.Modal(document.getElementById('purchaseModal'));
            purchaseModal.show();
        }

        // Satın alma işlemini tamamla
        document.getElementById('confirmPurchase').addEventListener('click', function() {
            // Proxy ID'sini bul
            let productId = null;

            // Burada normalde veritabanından ürün ID'si alınacak, ancak örnek olarak bu şekilde yapıyoruz
            @foreach($products as $product)
            if ('{{ $product->title }}' === selectedProduct) {
                productId = {{ $product->id }};
            }
            @endforeach

            if (!productId) {
                showError('Ürün bulunamadı. Lütfen tekrar deneyin.');
                return;
            }

            // AJAX ile satın alma işlemi
            fetch('{{ route("proxy.purchase") }}', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                },
                body: JSON.stringify({
                    product_id: productId,
                    quantity: selectedQuantity
                })
            })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Purchase Modal'ı kapat
                        bootstrap.Modal.getInstance(document.getElementById('purchaseModal')).hide();

                        // Başarılı mesajını göster
                        showSuccess(data.order_id);
                    } else {
                        showError(data.error || 'Satın alma işlemi sırasında bir hata oluştu.');
                    }
                })
                .catch(error => {
                    showError('Bağlantı hatası oluştu. Lütfen daha sonra tekrar deneyin.');
                    console.error('Error:', error);
                });
        });

        function showError(message) {
            document.getElementById('error-content').innerHTML = `<p class="text-danger">${message}</p>`;
            const errorModal = new bootstrap.Modal(document.getElementById('errorModal'));
            errorModal.show();
        }

        function showSuccess(orderId) {
            document.getElementById('success-content').innerHTML = `
            <div class="text-center mb-3">
                <i class="ri-check-double-line text-success" style="font-size: 3rem;"></i>
                <h4 class="mt-2">Satın alma işlemi başarıyla tamamlandı!</h4>
                <p>Sipariş numaranız: <strong>#${orderId}</strong></p>
                <p>Proxy bilgileriniz hazırlanıyor, sipariş detaylarına yönlendiriliyorsunuz...</p>
            </div>
        `;

            const successModal = new bootstrap.Modal(document.getElementById('successModal'));
            successModal.show();

            // 5 saniye sonra sipariş detayına yönlendir
            setTimeout(() => {
                window.location.href = `/panel/siparis/${orderId}`;
            }, 5000);

            // Progress bar animasyonu
            const progressBar = document.getElementById('redirectProgress');
            let width = 100;
            const interval = setInterval(() => {
                width -= 2; // Her 100ms'de %2 azalt
                progressBar.style.width = width + '%';

                if (width <= 0) {
                    clearInterval(interval);
                }
            }, 100);
        }
    </script>
@endsection