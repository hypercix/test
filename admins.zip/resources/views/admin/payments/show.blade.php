@extends('admin.layouts.app')

@section('title', 'Ödeme Detayı #' . $payment->id)

@section('content')
    <div class="mb-3">
        <a href="{{ route('admin.payments.index') }}" class="btn btn-secondary">
            <i class="fas fa-arrow-left me-1"></i> Listeye Dön
        </a>
    </div>

    <div class="row">
        <!-- Ödeme Bilgileri -->
        <div class="col-lg-8">
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="card-title">Ödeme Bilgileri</h5>
                </div>
                <div class="card-body">
                    <table class="table table-bordered">
                        <tr>
                            <th style="width: 30%">ID</th>
                            <td>{{ $payment->id }}</td>
                        </tr>
                        <tr>
                            <th>İşlem No</th>
                            <td>{{ $payment->payment_id }}</td>
                        </tr>
                        <tr>
                            <th>Kullanıcı</th>
                            <td>
                                @if($payment->user)
                                    <a href="{{ route('admin.users.edit', $payment->user) }}">
                                        {{ $payment->user->name }} ({{ $payment->user->email }})
                                    </a>
                                @else
                                    <span class="text-muted">Kullanıcı Silinmiş</span>
                                @endif
                            </td>
                        </tr>
                        <tr>
                            <th>Tutar</th>
                            <td>{{ number_format($payment->amount, 2) }} TL</td>
                        </tr>
                        <tr>
                            <th>İşlem Ücreti</th>
                            <td>
                                @if($payment->fee > 0)
                                    {{ number_format($payment->fee, 2) }} TL
                                @else
                                    <span class="text-muted">Yok</span>
                                @endif
                            </td>
                        </tr>
                        <tr>
                            <th>Net Tutar</th>
                            <td>{{ number_format($payment->net_amount, 2) }} TL</td>
                        </tr>
                        <tr>
                            <th>Para Birimi</th>
                            <td>{{ $payment->currency }}</td>
                        </tr>
                        <tr>
                            <th>Ödeme Yöntemi</th>
                            <td>
                                @if($payment->payment_method === 'stripe')
                                    <span class="badge bg-info">Stripe</span>
                                @elseif($payment->payment_method === 'manual')
                                    <span class="badge bg-secondary">Manuel</span>
                                @else
                                    <span class="badge bg-secondary">{{ $payment->payment_method }}</span>
                                @endif
                            </td>
                        </tr>
                        <tr>
                            <th>Durum</th>
                            <td>
                                @if($payment->status === 'succeeded')
                                    <span class="badge bg-success">Başarılı</span>
                                @elseif($payment->status === 'pending')
                                    <span class="badge bg-warning">Beklemede</span>
                                @elseif($payment->status === 'failed')
                                    <span class="badge bg-danger">Başarısız</span>
                                @elseif($payment->status === 'refunded')
                                    <span class="badge bg-secondary">İade</span>
                                @endif
                            </td>
                        </tr>
                        <tr>
                            <th>Açıklama</th>
                            <td>{{ $payment->description ?: 'Açıklama Yok' }}</td>
                        </tr>
                        <tr>
                            <th>Ödeme Tarihi</th>
                            <td>
                                @if($payment->paid_at)
                                    {{ $payment->paid_at->format('d.m.Y H:i:s') }}
                                @else
                                    <span class="text-muted">Henüz ödenmemiş</span>
                                @endif
                            </td>
                        </tr>
                        <tr>
                            <th>Oluşturulma Tarihi</th>
                            <td>{{ $payment->created_at->format('d.m.Y H:i:s') }}</td>
                        </tr>
                        <tr>
                            <th>Güncellenme Tarihi</th>
                            <td>{{ $payment->updated_at->format('d.m.Y H:i:s') }}</td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>

        <!-- Ek Bilgiler -->
        <div class="col-lg-4">
            <!-- Kullanıcı Bilgileri -->
            @if($payment->user)
                <div class="card mb-4">
                    <div class="card-header">
                        <h5 class="card-title">Kullanıcı Bilgileri</h5>
                    </div>
                    <div class="card-body">
                        <div class="mb-3">
                            <strong>Ad Soyad:</strong> {{ $payment->user->name }}
                        </div>
                        <div class="mb-3">
                            <strong>E-posta:</strong> {{ $payment->user->email }}
                        </div>
                        <div class="mb-3">
                            <strong>Bakiye:</strong> {{ number_format($payment->user->balance, 2) }} TL
                        </div>
                        <div class="mb-3">
                            <strong>Kayıt Tarihi:</strong> {{ $payment->user->created_at->format('d.m.Y') }}
                        </div>

                        <a href="{{ route('admin.users.edit', $payment->user) }}" class="btn btn-primary w-100">
                            <i class="fas fa-user"></i> Kullanıcı Profilini Görüntüle
                        </a>
                    </div>
                </div>
            @endif

            <!-- Metadata Bilgileri -->
            @if($payment->metadata)
                <div class="card mb-4">
                    <div class="card-header">
                        <h5 class="card-title">Ek Bilgiler</h5>
                    </div>
                    <div class="card-body">
                        <div class="mb-3">
                            <pre class="bg-light p-3 rounded" style="max-height: 300px; overflow-y: auto;">{{ json_encode($payment->metadata, JSON_PRETTY_PRINT) }}</pre>
                        </div>
                    </div>
                </div>
            @endif

            <!-- Hızlı İşlemler -->
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title">Hızlı İşlemler</h5>
                </div>
                <div class="card-body">
                    <a href="{{ route('admin.payments.add-balance-form') }}" class="btn btn-success w-100 mb-3">
                        <i class="fas fa-plus"></i> Yeni Manuel Bakiye Ekle
                    </a>

                    @if($payment->status === 'pending')
                        <button class="btn btn-warning w-100 mb-3" disabled>
                            <i class="fas fa-sync"></i> Ödeme Durumunu Kontrol Et
                        </button>
                    @endif

                    @if($payment->status === 'succeeded' && $payment->user)
                        <a href="{{ route('admin.users.edit', $payment->user) }}" class="btn btn-info w-100">
                            <i class="fas fa-user-edit"></i> Kullanıcı Bakiyesini Düzenle
                        </a>
                    @endif
                </div>
            </div>
        </div>
    </div>
@endsection