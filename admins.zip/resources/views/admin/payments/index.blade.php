@extends('admin.layouts.app')

@section('title', 'Ödeme Yönetimi')

@section('content')
    <div class="row">
        <!-- İstatistik Kartları -->
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-primary shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                Toplam İşlem</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">{{ $stats['total_count'] }}</div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-credit-card fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-success shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                Başarılı İşlem</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">{{ $stats['total_succeeded'] }}</div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-check-circle fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-info shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                Toplam Yüklenen</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">{{ number_format($stats['total_amount'], 2) }} TL</div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-money-bill-wave fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-warning shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                Bugün Yüklenen</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">{{ number_format($stats['today_amount'], 2) }} TL</div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-calendar-day fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- İşlem Butonları -->
    <div class="mb-4">
        <a href="{{ route('admin.payments.add-balance-form') }}" class="btn btn-primary mr-2">
            <i class="fas fa-plus-circle"></i> Manuel Bakiye Ekle
        </a>
        <a href="{{ route('admin.payments.report') }}" class="btn btn-info mr-2">
            <i class="fas fa-chart-bar"></i> Ödeme Raporu
        </a>
    </div>

    <!-- Filtre Kartı -->
    <div class="card mb-4">
        <div class="card-header">
            <h5 class="card-title mb-0">Filtreleme</h5>
        </div>
        <div class="card-body">
            <form action="{{ route('admin.payments.index') }}" method="GET">
                <div class="row">
                    <div class="col-md-3">
                        <div class="mb-3">
                            <label for="search" class="form-label">Arama</label>
                            <input type="text" class="form-control" id="search" name="search" value="{{ request('search') }}" placeholder="İşlem no, açıklama">
                        </div>
                    </div>

                    <div class="col-md-3">
                        <div class="mb-3">
                            <label for="status" class="form-label">Durum</label>
                            <select class="form-select" id="status" name="status">
                                <option value="">Tüm Durumlar</option>
                                @foreach($statuses as $value => $label)
                                    <option value="{{ $value }}" {{ request('status') == $value ? 'selected' : '' }}>{{ $label }}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>

                    <div class="col-md-3">
                        <div class="mb-3">
                            <label for="method" class="form-label">Ödeme Yöntemi</label>
                            <select class="form-select" id="method" name="method">
                                <option value="">Tüm Yöntemler</option>
                                @foreach($methods as $value => $label)
                                    <option value="{{ $value }}" {{ request('method') == $value ? 'selected' : '' }}>{{ $label }}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>

                    <div class="col-md-3">
                        <div class="mb-3">
                            <label for="user_id" class="form-label">Kullanıcı</label>
                            <select class="form-select" id="user_id" name="user_id">
                                <option value="">Tüm Kullanıcılar</option>
                                @foreach($users as $user)
                                    <option value="{{ $user->id }}" {{ request('user_id') == $user->id ? 'selected' : '' }}>{{ $user->name }} ({{ $user->email }})</option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-3">
                        <div class="mb-3">
                            <label for="date_from" class="form-label">Başlangıç Tarihi</label>
                            <input type="date" class="form-control" id="date_from" name="date_from" value="{{ request('date_from') }}">
                        </div>
                    </div>

                    <div class="col-md-3">
                        <div class="mb-3">
                            <label for="date_to" class="form-label">Bitiş Tarihi</label>
                            <input type="date" class="form-control" id="date_to" name="date_to" value="{{ request('date_to') }}">
                        </div>
                    </div>

                    <div class="col-md-6 d-flex align-items-end">
                        <div class="mb-3 d-flex gap-2 w-100">
                            <button type="submit" class="btn btn-primary flex-grow-1">
                                <i class="fas fa-filter me-1"></i> Filtrele
                            </button>
                            <a href="{{ route('admin.payments.index') }}" class="btn btn-secondary">
                                <i class="fas fa-redo me-1"></i> Sıfırla
                            </a>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Tablo Kartı -->
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h5 class="card-title mb-0">Ödemeler</h5>
            <span class="badge bg-primary">Toplam: {{ $payments->total() }}</span>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped table-hover">
                    <thead>
                    <tr>
                        <th>ID</th>
                        <th>İşlem No</th>
                        <th>Kullanıcı</th>
                        <th>Tutar</th>
                        <th>Yöntem</th>
                        <th>Durum</th>
                        <th>Tarih</th>
                        <th>İşlemler</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($payments as $payment)
                        <tr>
                            <td>{{ $payment->id }}</td>
                            <td>
                                <span class="text-monospace">{{ substr($payment->payment_id, 0, 8) }}...</span>
                            </td>
                            <td>
                                @if($payment->user)
                                    <a href="{{ route('admin.users.edit', $payment->user) }}">{{ $payment->user->email }}</a>
                                @else
                                    <span class="text-muted">Kullanıcı Silinmiş</span>
                                @endif
                            </td>
                            <td>{{ number_format($payment->amount, 2) }} TL</td>
                            <td>
                                @if($payment->payment_method === 'stripe')
                                    <span class="badge bg-info">Stripe</span>
                                @elseif($payment->payment_method === 'manual')
                                    <span class="badge bg-secondary">Manuel</span>
                                @else
                                    <span class="badge bg-secondary">{{ $payment->payment_method }}</span>
                                @endif
                            </td>
                            <td>
                                @if($payment->status === 'succeeded')
                                    <span class="badge bg-success">Başarılı</span>
                                @elseif($payment->status === 'pending')
                                    <span class="badge bg-warning">Beklemede</span>
                                @elseif($payment->status === 'failed')
                                    <span class="badge bg-danger">Başarısız</span>
                                @elseif($payment->status === 'refunded')
                                    <span class="badge bg-secondary">İade</span>
                                @endif
                            </td>
                            <td>{{ $payment->created_at->format('d.m.Y H:i') }}</td>
                            <td>
                                <a href="{{ route('admin.payments.show', $payment) }}" class="btn btn-sm btn-info">
                                    <i class="fas fa-eye"></i> Detay
                                </a>
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>

            @if($payments->isEmpty())
                <div class="text-center py-4">
                    <p class="text-muted">Sonuç bulunamadı.</p>
                </div>
    @endif
            @if($payments->isEmpty())
                <div class="text-center py-4">
                    <p class="text-muted">Sonuç bulunamadı.</p>
                </div>
            @endif

            <div class="d-flex justify-content-center mt-4">
                {{ $payments->appends(request()->query())->links() }}
            </div>
        </div>
    </div>
@endsection