@extends('admin.layouts.app')

@section('title', 'Ödeme Raporu')

@section('content')
    <div class="mb-4">
        <a href="{{ route('admin.payments.index') }}" class="btn btn-secondary">
            <i class="fas fa-arrow-left me-1"></i> Ödeme Listesine Dön
        </a>
    </div>

    <!-- Rapor Filtresi -->
    <div class="card mb-4">
        <div class="card-header">
            <h5 class="card-title mb-0">Rapor Filtresi</h5>
        </div>
        <div class="card-body">
            <form action="{{ route('admin.payments.report') }}" method="GET">
                <div class="row">
                    <div class="col-md-3">
                        <div class="mb-3">
                            <label for="period" class="form-label">Dönem</label>
                            <select class="form-select" id="period" name="period">
                                <option value="week" {{ $period == 'week' ? 'selected' : '' }}>Bu Hafta</option>
                                <option value="month" {{ $period == 'month' ? 'selected' : '' }}>Bu Ay</option>
                                <option value="year" {{ $period == 'year' ? 'selected' : '' }}>Bu Yıl</option>
                                <option value="custom" {{ $period == 'custom' ? 'selected' : '' }}>Özel Aralık</option>
                            </select>
                        </div>
                    </div>

                    <div class="col-md-3 custom-date-range" style="{{ $period == 'custom' ? '' : 'display: none;' }}">
                        <div class="mb-3">
                            <label for="start_date" class="form-label">Başlangıç Tarihi</label>
                            <input type="date" class="form-control" id="start_date" name="start_date" value="{{ request('start_date') }}">
                        </div>
                    </div>

                    <div class="col-md-3 custom-date-range" style="{{ $period == 'custom' ? '' : 'display: none;' }}">
                        <div class="mb-3">
                            <label for="end_date" class="form-label">Bitiş Tarihi</label>
                            <input type="date" class="form-control" id="end_date" name="end_date" value="{{ request('end_date') }}">
                        </div>
                    </div>

                    <div class="col-md-3 d-flex align-items-end">
                        <div class="mb-3 w-100">
                            <button type="submit" class="btn btn-primary w-100">
                                <i class="fas fa-filter me-1"></i> Filtrele
                            </button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Özet -->
    <div class="row mb-4">
        <div class="col-md-3">
            <div class="card border-left-info shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                Raporlama Dönemi</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                {{ $startDate->format('d.m.Y') }} - {{ $endDate->format('d.m.Y') }}
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-calendar fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card border-left-primary shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                Toplam İşlem</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">{{ $successPaymentCount }}</div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-credit-card fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card border-left-success shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                Toplam Tutar</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">{{ number_format($totalAmount, 2) }} TL</div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-money-bill-wave fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card border-left-warning shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                Net Kazanç</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">{{ number_format($netAmount, 2) }} TL</div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-hand-holding-usd fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <!-- Ödeme Yöntemi Dağılımı -->
        <div class="col-md-6 mb-4">
            <div class="card h-100">
                <div class="card-header">
                    <h5 class="card-title mb-0">Ödeme Yöntemi Dağılımı</h5>
                </div>
                <div class="card-body">
                    @if($methodStats->isEmpty())
                        <div class="text-center py-5">
                            <p class="text-muted">Bu dönemde ödeme verisi bulunmuyor.</p>
                        </div>
                    @else
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                <tr>
                                    <th>Ödeme Yöntemi</th>
                                    <th>İşlem Sayısı</th>
                                    <th>Toplam Tutar</th>
                                </tr>
                                </thead>
                                <tbody>
                                @foreach($methodStats as $method => $stats)
                                    <tr>
                                        <td>
                                            @if($method === 'stripe')
                                                <span class="badge bg-info">Stripe</span>
                                            @elseif($method === 'manual')
                                                <span class="badge bg-secondary">Manuel</span>
                                            @else
                                                <span class="badge bg-secondary">{{ $method }}</span>
                                            @endif
                                        </td>
                                        <td>{{ $stats['count'] }}</td>
                                        <td>{{ number_format($stats['amount'], 2) }} TL</td>
                                    </tr>
                                @endforeach
                                </tbody>
                            </table>
                        </div>
                    @endif
                </div>
            </div>
        </div>

        <!-- En Çok Bakiye Yükleyen Kullanıcılar -->
        <div class="col-md-6 mb-4">
            <div class="card h-100">
                <div class="card-header">
                    <h5 class="card-title mb-0">En Çok Bakiye Yükleyen Kullanıcılar</h5>
                </div>
                <div class="card-body">
                    @if($userStats->isEmpty())
                        <div class="text-center py-5">
                            <p class="text-muted">Bu dönemde ödeme verisi bulunmuyor.</p>
                        </div>
                    @else
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                <tr>
                                    <th>Kullanıcı</th>
                                    <th>İşlem Sayısı</th>
                                    <th>Toplam Tutar</th>
                                </tr>
                                </thead>
                                <tbody>
                                @foreach($userStats as $stat)
                                    <tr>
                                        <td>{{ $stat['user'] }}</td>
                                        <td>{{ $stat['count'] }}</td>
                                        <td>{{ number_format($stat['amount'], 2) }} TL</td>
                                    </tr>
                                @endforeach
                                </tbody>
                            </table>
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>

    <!-- Tarih Bazlı Veriler -->
    <div class="card mb-4">
        <div class="card-header">
            <h5 class="card-title mb-0">Tarih Bazlı Ödeme Verileri</h5>
        </div>
        <div class="card-body">
            @if($dateStats->isEmpty())
                <div class="text-center py-5">
                    <p class="text-muted">Bu dönemde ödeme verisi bulunmuyor.</p>
                </div>
            @else
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                        <tr>
                            <th>Tarih</th>
                            <th>İşlem Sayısı</th>
                            <th>Toplam Tutar</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($dateStats as $date => $stats)
                            <tr>
                                <td>{{ $date }}</td>
                                <td>{{ $stats['count'] }}</td>
                                <td>{{ number_format($stats['amount'], 2) }} TL</td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>
            @endif
        </div>
    </div>
@endsection

@section('scripts')
    <script>
        document.getElementById('period').addEventListener('change', function() {
            const customDateFields = document.querySelectorAll('.custom-date-range');

            if (this.value === 'custom') {
                customDateFields.forEach(field => {
                    field.style.display = 'block';
                });
            } else {
                customDateFields.forEach(field => {
                    field.style.display = 'none';
                });
            }
        });
    </script>
@endsection