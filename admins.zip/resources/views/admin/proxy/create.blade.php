@extends('admin.layouts.app')
@section('title', 'Yeni Proxy Ürünü Ekle')

@section('content')
    <div class="container-fluid">
        <!-- Başlık -->
        <div class="row">
            <div class="col-12">
                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                    <h4 class="mb-sm-0">Yeni Proxy Ürünü Ekle</h4>
                    <div class="page-title-right">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="{{ route('admin.proxy.index') }}">Proxy Yönetimi</a></li>
                            <li class="breadcrumb-item active">Yeni Ekle</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

        <!-- Form Kartı -->
        <div class="row justify-content-center">
            <div class="col-xl-8">
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title mb-0">Proxy Ürün Bilgileri</h5>
                    </div>
                    <div class="card-body">
                        <form action="{{ route('admin.proxy.store') }}" method="POST">
                            @csrf

                            <div class="row mb-3">
                                <div class="col-lg-12">
                                    <label for="title" class="form-label">Ürün Adı <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control @error('title') is-invalid @enderror" id="title"
                                           name="title" value="{{ old('title') }}" required>
                                    @error('title')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                    <div class="form-text">
                                        Örnek: "8 Adet Knight Online Proxy"
                                    </div>
                                </div>
                            </div>

                            <div class="row mb-3">
                                <div class="col-lg-6">
                                    <label for="price" class="form-label">Fiyat (₺) <span class="text-danger">*</span></label>
                                    <input type="number" step="0.01" class="form-control @error('price') is-invalid @enderror"
                                           id="price" name="price" value="{{ old('price') }}" required>
                                    @error('price')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                                <div class="col-lg-6">
                                    <label for="proxy_count" class="form-label">Proxy Sayısı</label>
                                    <input type="number" class="form-control" id="proxy_count" placeholder="Ör: 8">
                                    <div class="form-text">
                                        İsimlendirme için yardımcı alan (kaydedilmez)
                                    </div>
                                </div>
                            </div>

                            <div class="row mb-3">
                                <div class="col-lg-12">
                                    <label for="description" class="form-label">Açıklama</label>
                                    <textarea class="form-control @error('description') is-invalid @enderror" id="description"
                                              name="description" rows="4">{{ old('description') }}</textarea>
                                    @error('description')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>

                            <div class="alert alert-info">
                                <div class="d-flex">
                                    <div class="flex-shrink-0">
                                        <i class="ri-information-line me-2 align-middle fs-16"></i>
                                    </div>
                                    <div class="flex-grow-1">
                                        <h5 class="alert-heading">Bilgi!</h5>
                                        <p class="mb-0">
                                            Ürünü oluşturduktan sonra stok eklemeyi unutmayın. Toplu stok eklemek için
                                            "Toplu Stok" butonunu kullanabilirsiniz.
                                        </p>
                                    </div>
                                </div>
                            </div>

                            <div class="row mt-4">
                                <div class="col-lg-12 text-end">
                                    <a href="{{ route('admin.proxy.index') }}" class="btn btn-light">İptal</a>
                                    <button type="submit" class="btn btn-primary">Kaydet</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('script')
    <script>
        // Proxy sayısından otomatik başlık oluşturma
        document.addEventListener('DOMContentLoaded', function() {
            const proxyCountField = document.getElementById('proxy_count');
            const titleField = document.getElementById('title');

            proxyCountField.addEventListener('input', function() {
                const count = this.value;
                if (count && !isNaN(count)) {
                    titleField.value = `${count} Adet Knight Online Proxy`;
                }
            });
        });
    </script>
@endsection