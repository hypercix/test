@extends('admin.layouts.app')
@section('title', 'Toplu Proxy Stok Ekleme')

@section('content')
    <div class="container-fluid">
        <!-- Başlık -->
        <div class="row">
            <div class="col-12">
                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                    <h4 class="mb-sm-0">Toplu Proxy Stok Ekleme</h4>
                    <div class="page-title-right">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="{{ route('admin.proxy.index') }}">Proxy Yönetimi</a></li>
                            <li class="breadcrumb-item active">Toplu Stok</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

        <div class="row justify-content-center">
            <div class="col-xl-8">
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title mb-0">Toplu Proxy Stok Ekleme</h5>
                    </div>
                    <div class="card-body">
                        <div class="alert alert-info">
                            <div class="d-flex">
                                <div class="flex-shrink-0">
                                    <i class="ri-information-line me-2 align-middle fs-16"></i>
                                </div>
                                <div class="flex-grow-1">
                                    <h5 class="alert-heading">Bilgi!</h5>
                                    <p class="mb-0">
                                        Bu sayfa ile toplu olarak proxy stokları ekleyebilirsiniz. <code>{number}</code> şablonunu kullanarak
                                        numaralandırılmış stoklar oluşturabilirsiniz. Örneğin <code>proxy-user-{number}:pass123</code> formatı,
                                        <code>proxy-user-1:pass123</code>, <code>proxy-user-2:pass123</code> şeklinde stoklar oluşturur.
                                    </p>
                                </div>
                            </div>
                        </div>

                        <form action="{{ route('admin.proxy.bulkStocksStore') }}" method="POST">
                            @csrf

                            <div class="row mb-3">
                                <div class="col-lg-12">
                                    <label for="product_id" class="form-label">Ürün <span class="text-danger">*</span></label>
                                    <select class="form-select @error('product_id') is-invalid @enderror" id="product_id" name="product_id" required>
                                        <option value="">Ürün Seçin</option>
                                        @foreach($proxyProducts as $product)
                                            <option value="{{ $product->id }}">
                                                {{ $product->title }} ({{ number_format($product->price, 2) }}₺)
                                            </option>
                                        @endforeach
                                    </select>
                                    @error('product_id')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>

                            <div class="row mb-3">
                                <div class="col-lg-6">
                                    <label for="stock_count" class="form-label">Kaç Adet Stok <span class="text-danger">*</span></label>
                                    <input type="number" class="form-control @error('stock_count') is-invalid @enderror"
                                           id="stock_count" name="stock_count" value="{{ old('stock_count', 10) }}" min="1" max="500" required>
                                    @error('stock_count')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                    <div class="form-text">
                                        Bir kerede en fazla 500 adet stok ekleyebilirsiniz.
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <label for="start_number" class="form-label">Başlangıç Numarası</label>
                                    <input type="number" class="form-control @error('start_number') is-invalid @enderror"
                                           id="start_number" name="start_number" value="{{ old('start_number', 1) }}" min="1">
                                    @error('start_number')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                    <div class="form-text">
                                        {number} için başlangıç değeri (varsayılan: 1)
                                    </div>
                                </div>
                            </div>

                            <div class="row mb-3">
                                <div class="col-lg-12">
                                    <label for="stock_format" class="form-label">Stok Format Şablonu <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control @error('stock_format') is-invalid @enderror"
                                           id="stock_format" name="stock_format" value="{{ old('stock_format', 'proxy{number}:password123') }}" required>
                                    @error('stock_format')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                    <div class="form-text">
                                        <code>{number}</code> metni, otomatik olarak sayılarla değiştirilecektir.
                                    </div>
                                </div>
                            </div>

                            <div class="card bg-light mt-4 mb-4">
                                <div class="card-header">
                                    <h6 class="mb-0">Önizleme</h6>
                                </div>
                                <div class="card-body">
                                    <div id="preview-container" class="border rounded bg-white p-3" style="max-height: 200px; overflow-y: auto;">
                                        <div class="text-muted">Önizleme burada görünecek...</div>
                                    </div>
                                </div>
                            </div>

                            <div class="row mt-4">
                                <div class="col-lg-12 text-end">
                                    <a href="{{ route('admin.proxy.index') }}" class="btn btn-light">İptal</a>
                                    <button type="submit" class="btn btn-primary">Stok Ekle</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('script')
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const stockFormat = document.getElementById('stock_format');
            const stockCount = document.getElementById('stock_count');
            const startNumber = document.getElementById('start_number');
            const previewContainer = document.getElementById('preview-container');

            // Önizleme üretme fonksiyonu
            function generatePreview() {
                const format = stockFormat.value;
                const count = parseInt(stockCount.value) || 10;
                const start = parseInt(startNumber.value) || 1;

                if (!format) {
                    previewContainer.innerHTML = '<div class="text-muted">Önizleme burada görünecek...</div>';
                    return;
                }

                let html = '';
                const maxPreview = Math.min(count, 10); // En fazla 10 örnek göster

                for (let i = 0; i < maxPreview; i++) {
                    const number = start + i;
                    const content = format.replace(/{number}/g, number);

                    html += `<div class="mb-1 d-flex">
                    <span class="badge bg-soft-primary text-primary me-2" style="width: 24px;">${i+1}</span>
                    <code>${content}</code>
                </div>`;
                }

                if (count > maxPreview) {
                    html += `<div class="text-muted mt-2">... ve ${count - maxPreview} adet daha.</div>`;
                }

                previewContainer.innerHTML = html;
            }

            // Form alanlarını değiştiğinde önizlemeyi güncelle
            stockFormat.addEventListener('input', generatePreview);
            stockCount.addEventListener('input', generatePreview);
            startNumber.addEventListener('input', generatePreview);

            // Sayfa yüklendiğinde önizlemeyi göster
            generatePreview();
        });
    </script>
@endsection