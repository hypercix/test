@extends('admin.layouts.app')
@section('title', 'Proxy Ürünü Düzenle')

@section('content')
    <div class="container-fluid">
        <!-- Başlık -->
        <div class="row">
            <div class="col-12">
                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                    <h4 class="mb-sm-0">Proxy Ürünü Düzenle</h4>
                    <div class="page-title-right">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="{{ route('admin.proxy.index') }}">Proxy Yönetimi</a></li>
                            <li class="breadcrumb-item active">Düzenle</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <!-- Sol Kolon: Ürün Bilgileri -->
            <div class="col-lg-8">
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title mb-0">Ürün Bilgileri</h5>
                    </div>
                    <div class="card-body">
                        <form action="{{ route('admin.proxy.update', $proxy->id) }}" method="POST">
                            @csrf
                            @method('PUT')

                            <div class="row mb-3">
                                <div class="col-lg-12">
                                    <label for="title" class="form-label">Ürün Adı <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control @error('title') is-invalid @enderror" id="title"
                                           name="title" value="{{ old('title', $proxy->title) }}" required>
                                    @error('title')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>

                            <div class="row mb-3">
                                <div class="col-lg-6">
                                    <label for="price" class="form-label">Fiyat (₺) <span class="text-danger">*</span></label>
                                    <input type="number" step="0.01" class="form-control @error('price') is-invalid @enderror"
                                           id="price" name="price" value="{{ old('price', $proxy->price) }}" required>
                                    @error('price')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                                <div class="col-lg-6">
                                    <label for="profit_info" class="form-label">Kâr Bilgisi</label>
                                    <div class="input-group">
                                        <input type="number" class="form-control" id="cost_price" placeholder="Maliyet">
                                        <span class="input-group-text"><i class="ri-arrow-right-line"></i></span>
                                        <input type="text" class="form-control bg-light" id="profit_amount" readonly>
                                    </div>
                                    <div class="form-text">
                                        Maliyet girerek kâr hesaplayabilirsiniz (kaydedilmez)
                                    </div>
                                </div>
                            </div>

                            <div class="row mb-3">
                                <div class="col-lg-12">
                                    <label for="description" class="form-label">Açıklama</label>
                                    <textarea class="form-control @error('description') is-invalid @enderror" id="description"
                                              name="description" rows="4">{{ old('description', $proxy->description) }}</textarea>
                                    @error('description')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>

                            <div class="row mt-4">
                                <div class="col-lg-12 text-end">
                                    <a href="{{ route('admin.proxy.index') }}" class="btn btn-light">İptal</a>
                                    <button type="submit" class="btn btn-primary">Güncelle</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Sağ Kolon: Stok Ekleme ve Bilgiler -->
            <div class="col-lg-4">
                <!-- Stok Ekleme -->
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title mb-0">Stok Ekle</h5>
                    </div>
                    <div class="card-body">
                        <form action="{{ route('admin.proxy.addStocks', $proxy->id) }}" method="POST">
                            @csrf

                            <div class="mb-3">
                                <label for="stock_content" class="form-label">Proxy Bilgileri</label>
                                <textarea class="form-control @error('stock_content') is-invalid @enderror"
                                          id="stock_content" name="stock_content" rows="6"
                                          placeholder="Her satıra bir proxy bilgisi yazın"></textarea>
                                @error('stock_content')
                                <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                                <div class="form-text">
                                    Format: ip:port:kullanıcı:şifre
                                </div>
                            </div>

                            <div class="text-end">
                                <button type="submit" class="btn btn-success">
                                    <i class="ri-add-line me-1"></i> Stok Ekle
                                </button>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- Stok Durumu -->
                <div class="card mt-4">
                    <div class="card-header">
                        <h5 class="card-title mb-0">Stok Durumu</h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="border rounded p-3 mb-3">
                                    <div class="d-flex align-items-center mb-2">
                                        <div class="flex-grow-1">
                                            <span class="text-muted">Toplam Stok</span>
                                        </div>
                                        <div class="flex-shrink-0">
                                            <span class="fw-medium">{{ $proxy->stocks()->count() }}</span>
                                        </div>
                                    </div>
                                    <div class="d-flex align-items-center mb-2">
                                        <div class="flex-grow-1">
                                            <span class="text-muted">Satılabilir Stok</span>
                                        </div>
                                        <div class="flex-shrink-0">
                                            <span class="fw-medium text-success">{{ $proxy->stocks()->where('status', 0)->count() }}</span>
                                        </div>
                                    </div>
                                    <div class="d-flex align-items-center">
                                        <div class="flex-grow-1">
                                            <span class="text-muted">Satılan Stok</span>
                                        </div>
                                        <div class="flex-shrink-0">
                                            <span class="fw-medium text-info">{{ $proxy->stocks()->where('status', 1)->count() }}</span>
                                        </div>
                                    </div>
                                </div>

                                <div class="text-center">
                                    <a href="{{ route('admin.proxy.stocks', $proxy->id) }}" class="btn btn-soft-primary w-100">
                                        <i class="ri-database-2-line me-1"></i> Stokları Görüntüle
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('script')
    <script>
        // Kâr hesaplama
        document.addEventListener('DOMContentLoaded', function() {
            const costPrice = document.getElementById('cost_price');
            const sellingPrice = document.getElementById('price');
            const profitAmount = document.getElementById('profit_amount');

            function calculateProfit() {
                const cost = parseFloat(costPrice.value) || 0;
                const price = parseFloat(sellingPrice.value) || 0;

                if (cost > 0 && price > 0) {
                    const profit = price - cost;
                    const profitPercent = (profit / cost) * 100;

                    profitAmount.value = `${profit.toFixed(2)}₺ (${profitPercent.toFixed(0)}%)`;

                    // Kâr durumuna göre renk değiştir
                    if (profit > 0) {
                        profitAmount.classList.add('text-success');
                        profitAmount.classList.remove('text-danger');
                    } else {
                        profitAmount.classList.add('text-danger');
                        profitAmount.classList.remove('text-success');
                    }
                } else {
                    profitAmount.value = '';
                }
            }

            costPrice.addEventListener('input', calculateProfit);
            sellingPrice.addEventListener('input', calculateProfit);
        });
    </script>
@endsection