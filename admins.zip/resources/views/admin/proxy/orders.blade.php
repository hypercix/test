@extends('layouts.master')
@section('title', 'Proxy Siparişleri')

@section('content')
    <div class="container-fluid">
        <!-- Başlık -->
        <div class="row">
            <div class="col-12">
                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                    <h4 class="mb-sm-0">Proxy Siparişleri</h4>
                    <div class="page-title-right">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="{{ route('admin.proxy.index') }}">Proxy Yönetimi</a></li>
                            <li class="breadcrumb-item active">Siparişler</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

        <!-- Filtreler -->
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title mb-0">Filtreler</h5>
                    </div>
                    <div class="card-body">
                        <form action="{{ route('admin.proxy.orders') }}" method="GET">
                            <div class="row g-3">
                                <div class="col-md-4">
                                    <label for="status" class="form-label">Durum</label>
                                    <select class="form-select" id="status" name="status">
                                        <option value="">Tümü</option>
                                        <option value="{{ \App\Models\Order::STATUS_PENDING }}" {{ request('status') == \App\Models\Order::STATUS_PENDING ? 'selected' : '' }}>Beklemede</option>
                                        <option value="{{ \App\Models\Order::STATUS_COMPLETED }}" {{ request('status') == \App\Models\Order::STATUS_COMPLETED ? 'selected' : '' }}>Tamamlandı</option>
                                        <option value="{{ \App\Models\Order::STATUS_CANCELLED }}" {{ request('status') == \App\Models\Order::STATUS_CANCELLED ? 'selected' : '' }}>İptal Edildi</option>
                                    </select>
                                </div>
                                <div class="col-md-6">
                                    <label for="search" class="form-label">Arama</label>
                                    <input type="text" class="form-control" id="search" name="search" value="{{ request('search') }}" placeholder="Sipariş ID, Kullanıcı Adı veya E-posta">
                                </div>
                                <div class="col-md-2 d-flex align-items-end">
                                    <button type="submit" class="btn btn-primary w-100">Filtrele</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <!-- Siparişler Tablosu -->
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title mb-0">Proxy Siparişleri</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered table-striped align-middle mb-0">
                                <thead class="table-light">
                                <tr>
                                    <th>Sipariş ID</th>
                                    <th>Kullanıcı</th>
                                    <th>Ürün</th>
                                    <th>Miktar</th>
                                    <th>Fiyat</th>
                                    <th>Durum</th>
                                    <th>Tarih</th>
                                    <th class="text-center">İşlemler</th>
                                </tr>
                                </thead>
                                <tbody>
                                @forelse($orders as $order)
                                    <tr>
                                        <td>#{{ $order->id }}</td>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <div class="flex-shrink-0">
                                                    <div class="avatar-xs">
                                                            <span class="avatar-title rounded-circle bg-primary">
                                                                {{ substr($order->user->name, 0, 1) }}
                                                            </span>
                                                    </div>
                                                </div>
                                                <div class="flex-grow-1 ms-2">
                                                    <h6 class="mb-0">{{ $order->user->name }}</h6>
                                                    <small class="text-muted">{{ $order->user->email }}</small>
                                                </div>
                                            </div>
                                        </td>
                                        <td>{{ $order->product->title }}</td>
                                        <td>{{ $order->quantity }}</td>
                                        <td>{{ number_format($order->price, 2) }}₺</td>
                                        <td>
                                            @if($order->status === \App\Models\Order::STATUS_PENDING)
                                                <span class="badge bg-warning">Beklemede</span>
                                            @elseif($order->status === \App\Models\Order::STATUS_COMPLETED)
                                                <span class="badge bg-success">Tamamlandı</span>
                                            @elseif($order->status === \App\Models\Order::STATUS_CANCELLED)
                                                <span class="badge bg-danger">İptal Edildi</span>
                                            @endif
                                        </td>
                                        <td>{{ $order->created_at->format('d.m.Y H:i') }}</td>
                                        <td class="text-center">
                                            <a href="{{ route('admin.proxy.order-detail', $order->id) }}" class="btn btn-sm btn-primary">
                                                <i class="fas fa-eye"></i> Detay
                                            </a>
                                        </td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="8" class="text-center">
                                            <div class="p-3">
                                                <i class="fas fa-inbox fa-3x text-muted mb-3"></i>
                                                <p>Henüz sipariş bulunmuyor.</p>
                                            </div>
                                        </td>
                                    </tr>
                                @endforelse
                                </tbody>
                            </table>
                        </div>

                        <div class="mt-3">
                            {{ $orders->withQueryString()->links() }}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection