@extends('layouts.master')
@section('title', 'Proxy Sipariş Detayı')

@section('content')
    <div class="container-fluid">
        <!-- Başlık -->
        <div class="row">
            <div class="col-12">
                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                    <h4 class="mb-sm-0">Proxy Sipariş Detayı #{{ $order->id }}</h4>
                    <div class="page-title-right">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="{{ route('admin.proxy.index') }}">Proxy Yönetimi</a></li>
                            <li class="breadcrumb-item"><a href="{{ route('admin.proxy.orders') }}">Siparişler</a></li>
                            <li class="breadcrumb-item active">Sipariş #{{ $order->id }}</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

        <!-- Sipariş Bilgileri -->
        <div class="row">
            <div class="col-xl-8">
                <div class="card">
                    <div class="card-header">
                        <div class="d-flex align-items-center">
                            <h5 class="card-title flex-grow-1 mb-0">Sipariş Bilgileri</h5>
                            <div>
                                @if($order->status === \App\Models\Order::STATUS_PENDING)
                                    <span class="badge bg-warning fs-12">Beklemede</span>
                                @elseif($order->status === \App\Models\Order::STATUS_COMPLETED)
                                    <span class="badge bg-success fs-12">Tamamlandı</span>
                                @elseif($order->status === \App\Models\Order::STATUS_CANCELLED)
                                    <span class="badge bg-danger fs-12">İptal Edildi</span>
                                @endif
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <div class="d-flex">
                                    <div class="flex-shrink-0">
                                        <i class="fas fa-box text-primary fs-24 align-middle me-2"></i>
                                    </div>
                                    <div class="flex-grow-1">
                                        <h6 class="mb-1">Ürün</h6>
                                        <p class="text-muted mb-0">{{ $order->product->title }}</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 mb-3">
                                <div class="d-flex">
                                    <div class="flex-shrink-0">
                                        <i class="fas fa-box text-primary fs-24 align-middle me-2"></i>
                                    </div>
                                    <div class="flex-grow-1">
                                        <h6 class="mb-1">Miktar</h6>
                                        <p class="text-muted mb-0">{{ $order->quantity }} adet</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 mb-3">
                                <div class="d-flex">
                                    <div class="flex-shrink-0">
                                        <i class="fas fa-money-bill-wave text-primary fs-24 align-middle me-2"></i>
                                    </div>
                                    <div class="flex-grow-1">
                                        <h6 class="mb-1">Fiyat</h6>
                                        <p class="text-muted mb-0">{{ number_format($order->price, 2) }}₺</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 mb-3">
                                <div class="d-flex">
                                    <div class="flex-shrink-0">
                                        <i class="fas fa-calendar-alt text-primary fs-24 align-middle me-2"></i>
                                    </div>
                                    <div class="flex-grow-1">
                                        <h6 class="mb-1">Sipariş Tarihi</h6>
                                        <p class="text-muted mb-0">{{ $order->created_at->format('d.m.Y H:i') }}</p>
                                    </div>
                                </div>
                            </div>

                            @if($order->status === \App\Models\Order::STATUS_COMPLETED && $order->completed_at)
                                <div class="col-md-6 mb-3">
                                    <div class="d-flex">
                                        <div class="flex-shrink-0">
                                            <i class="fas fa-check-circle text-success fs-24 align-middle me-2"></i>
                                        </div>
                                        <div class="flex-grow-1">
                                            <h6 class="mb-1">Tamamlanma Tarihi</h6>
                                            <p class="text-muted mb-0">{{ \Carbon\Carbon::parse($order->completed_at)->format('d.m.Y H:i') }}</p>
                                        </div>
                                    </div>
                                </div>
                            @endif
                        </div>

                        <div class="mt-4">
                            <h6 class="mb-3">Kullanıcı Bilgileri</h6>
                            <div class="border rounded p-3">
                                <div class="d-flex align-items-center mb-3">
                                    <div class="avatar-xs me-3">
                                        <span class="avatar-title rounded-circle bg-primary text-white">
                                            {{ substr($order->user->name, 0, 1) }}
                                        </span>
                                    </div>
                                    <div>
                                        <h6 class="mb-0">{{ $order->user->name }}</h6>
                                        <p class="text-muted mb-0">{{ $order->user->email }}</p>
                                    </div>
                                </div>

                                <div class="row g-3">
                                    <div class="col-lg-6">
                                        <div class="border rounded p-2">
                                            <small class="text-muted d-block">Kullanıcı ID</small>
                                            <span>{{ $order->user->id }}</span>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="border rounded p-2">
                                            <small class="text-muted d-block">Bakiye</small>
                                            <span>{{ number_format($order->user->balance, 2) }}₺</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Teslim Edilen İçerik -->
                        @if($order->status === \App\Models\Order::STATUS_COMPLETED && $order->delivery_content)
                            <div class="mt-4">
                                <h6 class="mb-3">Teslim Edilen İçerik</h6>
                                <div class="border rounded p-3 position-relative">
                                    <button class="btn btn-sm btn-light position-absolute top-0 end-0 m-2" id="copyDeliveryContent">
                                        <i class="fas fa-copy"></i>
                                    </button>
                                    <pre class="mb-0" style="white-space: pre-wrap;">{{ $order->delivery_content }}</pre>
                                </div>
                            </div>
                        @endif

                        <!-- Notlar -->
                        @if($order->notes)
                            <div class="mt-4">
                                <h6 class="mb-3">Notlar</h6>
                                <div class="border rounded p-3">
                                    <p class="mb-0">{{ $order->notes }}</p>
                                </div>
                            </div>
                        @endif
                    </div>
                </div>
            </div>

            <div class="col-xl-4">
                <!-- Durum Değiştirme Kartı -->
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title mb-0">Sipariş Durumu</h5>
                    </div>
                    <div class="card-body">
                        @if($order->status === \App\Models\Order::STATUS_PENDING)
                            <div class="alert alert-warning">
                                <div class="d-flex">
                                    <div class="flex-shrink-0">
                                        <i class="fas fa-exclamation-triangle me-2"></i>
                                    </div>
                                    <div class="flex-grow-1">
                                        <h6 class="alert-heading">Bekleyen Sipariş</h6>
                                        <p class="mb-0">Bu sipariş henüz tamamlanmamış. Proxy bilgilerini ekleyerek siparişi tamamlayabilirsiniz.</p>
                                    </div>
                                </div>
                            </div>

                            <!-- Tamamlama Formu -->
                            <form action="{{ route('admin.proxy.complete-order', $order->id) }}" method="POST">
                                @csrf

                                <div class="mb-3">
                                    <label for="delivery_content" class="form-label">Proxy Bilgileri</label>
                                    <textarea class="form-control" id="delivery_content" name="delivery_content" rows="8" required placeholder="ip:port:username:password şeklinde proxy bilgilerini girin"></textarea>
                                    <div class="form-text">
                                        Bu içerik müşteriye teslim edilecektir.
                                    </div>
                                </div>

                                <div class="mb-3">
                                    <label for="notes" class="form-label">Notlar (Opsiyonel)</label>
                                    <textarea class="form-control" id="notes" name="notes" rows="3">{{ $order->notes }}</textarea>
                                    <div class="form-text">
                                        Bu notlar sadece admin panelinde görünür.
                                    </div>
                                </div>

                                <div class="d-grid">
                                    <button type="submit" class="btn btn-success">
                                        <i class="fas fa-check-circle me-1"></i> Siparişi Tamamla
                                    </button>
                                </div>
                            </form>

                            <div class="mt-3">
                                <button type="button" class="btn btn-danger w-100" data-bs-toggle="modal" data-bs-target="#cancelOrderModal">
                                    <i class="fas fa-times-circle me-1"></i> Siparişi İptal Et
                                </button>
                            </div>
                        @elseif($order->status === \App\Models\Order::STATUS_COMPLETED)
                            <div class="alert alert-success">
                                <div class="d-flex">
                                    <div class="flex-shrink-0">
                                        <i class="fas fa-check-circle me-2"></i>
                                    </div>
                                    <div class="flex-grow-1">
                                        <h6 class="alert-heading">Tamamlanmış Sipariş</h6>
                                        <p class="mb-0">Bu sipariş başarıyla tamamlanmış ve müşteriye teslim edilmiştir.</p>
                                    </div>
                                </div>
                            </div>
                        @else
                            <div class="alert alert-danger">
                                <div class="d-flex">
                                    <div class="flex-shrink-0">
                                        <i class="fas fa-times-circle me-2"></i>
                                    </div>
                                    <div class="flex-grow-1">
                                        <h6 class="alert-heading">İptal Edilmiş Sipariş</h6>
                                        <p class="mb-0">Bu sipariş iptal edilmiştir. Ödeme müşteriye iade edilmiştir.</p>
                                    </div>
                                </div>
                            </div>
                        @endif
                    </div>
                </div>

                <!-- İşlem Geçmişi -->
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title mb-0">İşlem Geçmişi</h5>
                    </div>
                    <div class="card-body">
                        <div class="acitivity-timeline py-2">
                            <div class="acitivity-item d-flex">
                                <div class="flex-shrink-0">
                                    <div class="avatar-xs acitivity-avatar">
                                        <div class="avatar-title rounded-circle bg-soft-success text-success">
                                            <i class="fas fa-shopping-cart"></i>
                                        </div>
                                    </div>
                                </div>
                                <div class="flex-grow-1 ms-3">
                                    <h6 class="mb-1">Sipariş Oluşturuldu</h6>
                                    <p class="text-muted mb-2">Kullanıcı proxy siparişi verdi.</p>
                                    <small class="mb-0 text-muted">{{ $order->created_at->format('d.m.Y H:i') }}</small>
                                </div>
                            </div>

                            @if($order->status === \App\Models\Order::STATUS_COMPLETED)
                                <div class="acitivity-item d-flex">
                                    <div class="flex-shrink-0">
                                        <div class="avatar-xs acitivity-avatar">
                                            <div class="avatar-title rounded-circle bg-soft-success text-success">
                                                <i class="fas fa-check"></i>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="flex-grow-1 ms-3">
                                        <h6 class="mb-1">Sipariş Tamamlandı</h6>
                                        <p class="text-muted mb-2">Admin tarafından tamamlandı.</p>
                                        <small class="mb-0 text-muted">{{ \Carbon\Carbon::parse($order->completed_at)->format('d.m.Y H:i') }}</small>
                                    </div>
                                </div>
                            @elseif($order->status === \App\Models\Order::STATUS_CANCELLED)
                                <div class="acitivity-item d-flex">
                                    <div class="flex-shrink-0">
                                        <div class="avatar-xs acitivity-avatar">
                                            <div class="avatar-title rounded-circle bg-soft-danger text-danger">
                                                <i class="fas fa-times"></i>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="flex-grow-1 ms-3">
                                        <h6 class="mb-1">Sipariş İptal Edildi</h6>
                                        <p class="text-muted mb-2">Admin tarafından iptal edildi.</p>
                                        <small class="mb-0 text-muted">{{ $order->updated_at->format('d.m.Y H:i') }}</small>
                                    </div>
                                </div>
                            @endif
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- İptal Etme Modal -->
    <div class="modal fade" id="cancelOrderModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Sipariş İptal Onayı</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="alert alert-warning">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        Bu işlem, siparişi iptal edecek ve ödemeyi kullanıcıya iade edecektir.
                    </div>

                    <form action="{{ route('admin.proxy.cancel-order', $order->id) }}" method="POST" id="cancelOrderForm">
                        @csrf
                        <div class="mb-3">
                            <label for="cancel_notes" class="form-label">İptal Nedeni (Opsiyonel)</label>
                            <textarea class="form-control" id="cancel_notes" name="notes" rows="3" placeholder="İptal nedeni..."></textarea>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-light" data-bs-dismiss="modal">Vazgeç</button>
                    <button type="button" class="btn btn-danger" onclick="document.getElementById('cancelOrderForm').submit();">
                        Siparişi İptal Et ve Ödemeyi İade Et
                    </button>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('scripts')
    <script>
        // Teslim edilen içeriği kopyalama
        document.addEventListener('DOMContentLoaded', function() {
            const copyBtn = document.getElementById('copyDeliveryContent');
            if (copyBtn) {
                copyBtn.addEventListener('click', function() {
                    const content = document.querySelector('pre').textContent;
                    navigator.clipboard.writeText(content)
                        .then(() => {
                            copyBtn.innerHTML = '<i class="fas fa-check"></i>';
                            setTimeout(() => {
                                copyBtn.innerHTML = '<i class="fas fa-copy"></i>';
                            }, 2000);
                        })
                        .catch(err => {
                            console.error('Kopyalama hatası:', err);
                        });
                });
            }
        });
    </script>
@endsection