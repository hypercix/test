@extends('admin.layouts.app')
@section('title', 'Proxy Yönetimi')

@section('content')
    <div class="container-fluid">
        <!-- Başlık ve Butonlar -->
        <div class="row">
            <div class="col-12">
                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                    <h4 class="mb-sm-0">Knight Online Proxy Yönetimi</h4>
                    <div class="page-title-right">
                        <div class="d-flex gap-2">
                            <a href="{{ route('admin.proxy.bulk-stocks') }}" class="btn btn-soft-primary">
                                <i class="ri-stack-line align-bottom me-1"></i> Toplu Stok
                            </a>
                            <a href="{{ route('admin.proxy.create') }}" class="btn btn-primary">
                                <i class="ri-add-line align-bottom me-1"></i> Yeni Proxy Ekle
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- İstatistik Kartları -->
        <div class="row">
            <div class="col-xl-3 col-md-6">
                <div class="card card-animate">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <div class="avatar-sm flex-shrink-0">
                                <span class="avatar-title bg-soft-primary text-primary rounded-2 fs-2">
                                    <i class="ri-stack-line"></i>
                                </span>
                            </div>
                            <div class="flex-grow-1 ms-3">
                                <p class="text-uppercase fw-medium text-muted mb-1">Toplam Ürün</p>
                                <h4 class="fs-22 fw-semibold mb-0">{{ $stats['total_products'] }}</h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-3 col-md-6">
                <div class="card card-animate">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <div class="avatar-sm flex-shrink-0">
                                <span class="avatar-title bg-soft-success text-success rounded-2 fs-2">
                                    <i class="ri-database-2-line"></i>
                                </span>
                            </div>
                            <div class="flex-grow-1 ms-3">
                                <p class="text-uppercase fw-medium text-muted mb-1">Stok</p>
                                <h4 class="fs-22 fw-semibold mb-0">{{ $stats['total_available_stock'] }}</h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-3 col-md-6">
                <div class="card card-animate">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <div class="avatar-sm flex-shrink-0">
                                <span class="avatar-title bg-soft-warning text-warning rounded-2 fs-2">
                                    <i class="ri-shopping-cart-2-line"></i>
                                </span>
                            </div>
                            <div class="flex-grow-1 ms-3">
                                <p class="text-uppercase fw-medium text-muted mb-1">Satılan</p>
                                <h4 class="fs-22 fw-semibold mb-0">{{ $stats['total_sold_stock'] }}</h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-3 col-md-6">
                <div class="card card-animate">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <div class="avatar-sm flex-shrink-0">
                                <span class="avatar-title bg-soft-info text-info rounded-2 fs-2">
                                    <i class="ri-money-dollar-circle-line"></i>
                                </span>
                            </div>
                            <div class="flex-grow-1 ms-3">
                                <p class="text-uppercase fw-medium text-muted mb-1">Toplam Satış</p>
                                <h4 class="fs-22 fw-semibold mb-0">{{ number_format($stats['total_sales'], 2) }}₺</h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Ürün Tablosu -->
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header d-flex align-items-center">
                        <h5 class="card-title flex-grow-1 mb-0">Proxy Ürünleri</h5>
                        <div class="flex-shrink-0">
                            <a href="{{ route('admin.proxy.reports') }}" class="btn btn-soft-info btn-sm">
                                <i class="ri-bar-chart-2-line me-1 align-bottom"></i> Satış Raporları
                            </a>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered table-nowrap align-middle mb-0">
                                <thead class="table-light">
                                <tr>
                                    <th scope="col">ID</th>
                                    <th scope="col">Ürün Adı</th>
                                    <th scope="col">Fiyat</th>
                                    <th scope="col">Satılabilir Stok</th>
                                    <th scope="col">Satılan</th>
                                    <th scope="col">Oluşturma Tarihi</th>
                                    <th scope="col" class="text-center">İşlemler</th>
                                </tr>
                                </thead>
                                <tbody>
                                @forelse($proxyProducts as $product)
                                    <tr>
                                        <td>{{ $product->id }}</td>
                                        <td>{{ $product->title }}</td>
                                        <td>{{ number_format($product->price, 2) }}₺</td>
                                        <td>
                                                <span class="badge bg-success-subtle text-success">
                                                    {{ $product->available_stock }}
                                                </span>
                                        </td>
                                        <td>
                                                <span class="badge bg-info-subtle text-info">
                                                    {{ $product->sold_stock }}
                                                </span>
                                        </td>
                                        <td>{{ $product->created_at->format('d.m.Y H:i') }}</td>
                                        <td class="text-center">
                                            <div class="d-flex justify-content-center gap-2">
                                                <a href="{{ route('admin.proxy.stocks', $product->id) }}" class="btn btn-sm btn-soft-primary" data-bs-toggle="tooltip" data-bs-placement="top" title="Stokları Görüntüle">
                                                    <i class="ri-database-2-line"></i>
                                                </a>
                                                <a href="{{ route('admin.proxy.edit', $product->id) }}" class="btn btn-sm btn-soft-info" data-bs-toggle="tooltip" data-bs-placement="top" title="Düzenle">
                                                    <i class="ri-pencil-fill"></i>
                                                </a>
                                                <button type="button" class="btn btn-sm btn-soft-danger"
                                                        onclick="confirmDelete({{ $product->id }})"
                                                        data-bs-toggle="tooltip" data-bs-placement="top" title="Sil">
                                                    <i class="ri-delete-bin-5-line"></i>
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="7" class="text-center py-4">
                                            <div class="d-flex flex-column align-items-center">
                                                <i class="ri-inbox-line display-5 text-muted"></i>
                                                <p class="mt-2">Henüz hiç proxy ürünü eklenmemiş.</p>
                                                <a href="{{ route('admin.proxy.create') }}" class="btn btn-sm btn-primary mt-1">
                                                    <i class="ri-add-line me-1"></i> Yeni Proxy Ekle
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                @endforelse
                                </tbody>
                            </table>
                        </div>

                        <!-- Pagination -->
                        @if($proxyProducts->hasPages())
                            <div class="d-flex justify-content-end mt-3">
                                {{ $proxyProducts->links() }}
                            </div>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Silme Onay Modalı -->
    <div class="modal fade" id="deleteModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Proxy Ürününü Sil</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p>Bu proxy ürününü silmek istediğinizden emin misiniz? Bu işlem geri alınamaz ve tüm stoklar silinecektir.</p>
                    <p class="text-danger"><small>Not: Satılmış ürünler varsa silinemez.</small></p>
                </div>
                <div class="modal-footer">
                    <form id="deleteForm" method="POST" action="">
                        @csrf
                        @method('DELETE')
                        <button type="button" class="btn btn-light" data-bs-dismiss="modal">İptal</button>
                        <button type="submit" class="btn btn-danger">Evet, Sil</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('script')
    <script>
        // Silme işlemi onay
        function confirmDelete(id) {
            const form = document.getElementById('deleteForm');
            form.action = `/admin/proxy/${id}`;

            const modal = new bootstrap.Modal(document.getElementById('deleteModal'));
            modal.show();
        }

        // Tooltip'leri etkinleştir
        document.addEventListener('DOMContentLoaded', function() {
            const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
            tooltipTriggerList.map(function(tooltipTriggerEl) {
                return new bootstrap.Tooltip(tooltipTriggerEl);
            });
        });
    </script>
@endsection