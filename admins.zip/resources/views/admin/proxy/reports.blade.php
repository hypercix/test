@extends('admin.layouts.app')
@section('title', 'Proxy Satış Raporları')

@section('css')
    <!-- Datepicker CSS -->
    <link rel="stylesheet" href="{{ asset('assets/libs/flatpickr/flatpickr.min.css') }}">
    <!-- ApexCharts CSS -->
    <link rel="stylesheet" href="{{ asset('assets/libs/apexcharts/apexcharts.min.css') }}">
@endsection

@section('content')
    <div class="container-fluid">
        <!-- Başlık -->
        <div class="row">
            <div class="col-12">
                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                    <h4 class="mb-sm-0">Proxy Satış Raporları</h4>
                    <div class="page-title-right">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="{{ route('admin.proxy.index') }}">Proxy Yönetimi</a></li>
                            <li class="breadcrumb-item active">Raporlar</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

        <!-- Tarih Filtresi -->
        <div class="row">
            <div class="col-xl-12">
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title mb-0">Tarih Aralığı</h5>
                    </div>
                    <div class="card-body">
                        <form action="{{ route('admin.proxy.reports') }}" method="GET">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="mb-3 mb-md-0">
                                        <label for="start_date" class="form-label">Başlangıç Tarihi</label>
                                        <input type="text" class="form-control flatpickr-input" id="start_date" name="start_date"
                                               value="{{ $startDate }}" placeholder="YYYY-MM-DD">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="mb-3 mb-md-0">
                                        <label for="end_date" class="form-label">Bitiş Tarihi</label>
                                        <input type="text" class="form-control flatpickr-input" id="end_date" name="end_date"
                                               value="{{ $endDate }}" placeholder="YYYY-MM-DD">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="d-flex align-items-end h-100">
                                        <button type="submit" class="btn btn-primary">Filtrele</button>
                                        <div class="ms-2 dropdown">
                                            <button class="btn btn-light dropdown-toggle" type="button" id="quickFilterBtn"
                                                    data-bs-toggle="dropdown" aria-expanded="false">
                                                Hızlı Filtre
                                            </button>
                                            <ul class="dropdown-menu" aria-labelledby="quickFilterBtn">
                                                <li><a class="dropdown-item quick-filter" href="#" data-days="7">Son 7 Gün</a></li>
                                                <li><a class="dropdown-item quick-filter" href="#" data-days="30">Son 30 Gün</a></li>
                                                <li><a class="dropdown-item quick-filter" href="#" data-days="90">Son 3 Ay</a></li>
                                                <li><a class="dropdown-item quick-filter" href="#" data-days="365">Son 1 Yıl</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <!-- Özet Kartları -->
        <div class="row">
            <div class="col-xl-3 col-md-6">
                <div class="card card-animate">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <div class="avatar-sm flex-shrink-0">
                                <span class="avatar-title bg-soft-primary text-primary rounded-2 fs-2">
                                    <i class="ri-shopping-cart-2-line"></i>
                                </span>
                            </div>
                            <div class="flex-grow-1 ms-3">
                                <p class="text-uppercase fw-medium text-muted mb-1">Toplam Sipariş</p>
                                <h4 class="fs-22 fw-semibold mb-0">{{ $dailySales->sum('count') }}</h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-3 col-md-6">
                <div class="card card-animate">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <div class="avatar-sm flex-shrink-0">
                                <span class="avatar-title bg-soft-success text-success rounded-2 fs-2">
                                    <i class="ri-database-2-line"></i>
                                </span>
                            </div>
                            <div class="flex-grow-1 ms-3">
                                <p class="text-uppercase fw-medium text-muted mb-1">Satılan Adet</p>
                                <h4 class="fs-22 fw-semibold mb-0">{{ $dailySales->sum('quantity') }}</h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-3 col-md-6">
                <div class="card card-animate">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <div class="avatar-sm flex-shrink-0">
                                <span class="avatar-title bg-soft-warning text-warning rounded-2 fs-2">
                                    <i class="ri-money-dollar-circle-line"></i>
                                </span>
                            </div>
                            <div class="flex-grow-1 ms-3">
                                <p class="text-uppercase fw-medium text-muted mb-1">Toplam Ciro</p>
                                <h4 class="fs-22 fw-semibold mb-0">{{ number_format($dailySales->sum('total'), 2) }}₺</h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-3 col-md-6">
                <div class="card card-animate">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <div class="avatar-sm flex-shrink-0">
                                <span class="avatar-title bg-soft-info text-info rounded-2 fs-2">
                                    <i class="ri-line-chart-line"></i>
                                </span>
                            </div>
                            <div class="flex-grow-1 ms-3">
                                <p class="text-uppercase fw-medium text-muted mb-1">Günlük Ortalama</p>
                                <h4 class="fs-22 fw-semibold mb-0">
                                    {{ $dailySales->count() > 0 ? number_format($dailySales->sum('total') / $dailySales->count(), 2) : '0.00' }}₺
                                </h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Grafik ve Tablolar -->
        <div class="row">
            <!-- Günlük Satış Grafiği -->
            <div class="col-xl-8">
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title mb-0">Günlük Satış Grafiği</h5>
                    </div>
                    <div class="card-body">
                        <div id="daily-sales-chart" class="apex-charts" dir="ltr" style="min-height: 380px;"></div>
                    </div>
                </div>
            </div>

            <!-- Ürün Dağılımı -->
            <div class="col-xl-4">
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title mb-0">Ürün Dağılımı</h5>
                    </div>
                    <div class="card-body">
                        <div id="product-distribution-chart" class="apex-charts" dir="ltr" style="min-height: 380px;"></div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Ürüne Göre Satışlar -->
        <div class="row">
            <div class="col-xl-12">
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title mb-0">Ürüne Göre Satış Detayları</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered table-striped align-middle mb-0">
                                <thead class="table-light">
                                <tr>
                                    <th>Ürün</th>
                                    <th class="text-center">Sipariş Sayısı</th>
                                    <th class="text-center">Satılan Adet</th>
                                    <th class="text-center">Toplam Ciro</th>
                                    <th class="text-center">Ortalama Fiyat</th>
                                </tr>
                                </thead>
                                <tbody>
                                @forelse($productSales as $sale)
                                    <tr>
                                        <td>{{ $sale->product->title }}</td>
                                        <td class="text-center">{{ $sale->count }}</td>
                                        <td class="text-center">{{ $sale->quantity }}</td>
                                        <td class="text-center">{{ number_format($sale->total, 2) }}₺</td>
                                        <td class="text-center">{{ number_format($sale->total / $sale->count, 2) }}₺</td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="5" class="text-center">Seçilen tarih aralığında satış verisi bulunamadı.</td>
                                    </tr>
                                @endforelse
                                </tbody>
                                @if(count($productSales) > 0)
                                    <tfoot class="table-light">
                                    <tr class="fw-bold">
                                        <td>TOPLAM</td>
                                        <td class="text-center">{{ $productSales->sum('count') }}</td>
                                        <td class="text-center">{{ $productSales->sum('quantity') }}</td>
                                        <td class="text-center">{{ number_format($productSales->sum('total'), 2) }}₺</td>
                                        <td class="text-center">{{ number_format($productSales->sum('total') / $productSales->sum('count'), 2) }}₺</td>
                                    </tr>
                                    </tfoot>
                                @endif
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Günlük Satış Tablosu -->
        <div class="row">
            <div class="col-xl-12">
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title mb-0">Günlük Satış Detayları</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered table-striped align-middle mb-0">
                                <thead class="table-light">
                                <tr>
                                    <th>Tarih</th>
                                    <th class="text-center">Sipariş Sayısı</th>
                                    <th class="text-center">Satılan Adet</th>
                                    <th class="text-center">Toplam Ciro</th>
                                </tr>
                                </thead>
                                <tbody>
                                @forelse($dailySales as $sale)
                                    <tr>
                                        <td>{{ \Carbon\Carbon::parse($sale->date)->format('d.m.Y') }}</td>
                                        <td class="text-center">{{ $sale->count }}</td>
                                        <td class="text-center">{{ $sale->quantity }}</td>
                                        <td class="text-center">{{ number_format($sale->total, 2) }}₺</td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="4" class="text-center">Seçilen tarih aralığında satış verisi bulunamadı.</td>
                                    </tr>
                                @endforelse
                                </tbody>
                                @if(count($dailySales) > 0)
                                    <tfoot class="table-light">
                                    <tr class="fw-bold">
                                        <td>TOPLAM</td>
                                        <td class="text-center">{{ $dailySales->sum('count') }}</td>
                                        <td class="text-center">{{ $dailySales->sum('quantity') }}</td>
                                        <td class="text-center">{{ number_format($dailySales->sum('total'), 2) }}₺</td>
                                    </tr>
                                    </tfoot>
                                @endif
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('script')
    <!-- Flatpickr JS -->
    <script src="{{ asset('assets/libs/flatpickr/flatpickr.min.js') }}"></script>
    <!-- ApexCharts JS -->
    <script src="{{ asset('assets/libs/apexcharts/apexcharts.min.js') }}"></script>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Flatpickr (tarih seçici) ayarları
            flatpickr('#start_date', {
                dateFormat: 'Y-m-d',
                maxDate: 'today'
            });

            flatpickr('#end_date', {
                dateFormat: 'Y-m-d',
                maxDate: 'today'
            });

            // Hızlı filtre işlemleri
            document.querySelectorAll('.quick-filter').forEach(link => {
                link.addEventListener('click', function(e) {
                    e.preventDefault();

                    const days = parseInt(this.dataset.days);
                    const endDate = new Date();
                    const startDate = new Date();
                    startDate.setDate(startDate.getDate() - days);

                    document.getElementById('start_date').value = formatDate(startDate);
                    document.getElementById('end_date').value = formatDate(endDate);

                    // Formu gönder
                    this.closest('form').submit();
                });
            });

            // Tarih formatı fonksiyonu (YYYY-MM-DD)
            function formatDate(date) {
                const year = date.getFullYear();
                const month = String(date.getMonth() + 1).padStart(2, '0');
                const day = String(date.getDate()).padStart(2, '0');
                return `${year}-${month}-${day}`;
            }

            // Günlük Satış Grafiği
            const dailySalesData = @json($dailySales);

            if (dailySalesData.length > 0) {
                const dates = dailySalesData.map(sale => {
                    const date = new Date(sale.date);
                    return date.toLocaleDateString('tr-TR', { day: '2-digit', month: '2-digit' });
                });

                const totals = dailySalesData.map(sale => parseFloat(sale.total));
                const counts = dailySalesData.map(sale => parseInt(sale.count));

                const dailySalesOptions = {
                    series: [
                        {
                            name: 'Ciro (₺)',
                            type: 'area',
                            data: totals
                        },
                        {
                            name: 'Sipariş Sayısı',
                            type: 'line',
                            data: counts
                        }
                    ],
                    chart: {
                        height: 380,
                        type: 'line',
                        toolbar: {
                            show: false
                        }
                    },
                    stroke: {
                        width: [3, 3],
                        curve: 'smooth'
                    },
                    fill: {
                        type: 'gradient',
                        gradient: {
                            shade: 'light',
                            type: "vertical",
                            shadeIntensity: 0.4,
                            inverseColors: false,
                            opacityFrom: 0.4,
                            opacityTo: 0.1,
                            stops: [0, 100]
                        }
                    },
                    dataLabels: {
                        enabled: false
                    },
                    colors: ['#4284F5', '#f1b44c'],
                    labels: dates,
                    xaxis: {
                        type: 'category',
                        tickPlacement: 'on'
                    },
                    yaxis: [
                        {
                            title: {
                                text: 'Ciro (₺)',
                            },
                            labels: {
                                formatter: function(val) {
                                    return val.toFixed(0) + "₺";
                                }
                            }
                        },
                        {
                            opposite: true,
                            title: {
                                text: 'Sipariş Sayısı'
                            },
                            labels: {
                                formatter: function(val) {
                                    return val.toFixed(0);
                                }
                            }
                        }
                    ],
                    tooltip: {
                        y: {
                            formatter: function(val, { seriesIndex }) {
                                if (seriesIndex === 0) {
                                    return val.toFixed(2) + "₺";
                                }
                                return val;
                            }
                        }
                    },
                    legend: {
                        position: 'top',
                        horizontalAlign: 'right'
                    }
                };

                const dailySalesChart = new ApexCharts(document.querySelector("#daily-sales-chart"), dailySalesOptions);
                dailySalesChart.render();
            } else {
                document.querySelector("#daily-sales-chart").innerHTML = '<div class="d-flex align-items-center justify-content-center" style="height: 380px;"><p class="text-muted">Veri bulunamadı</p></div>';
            }

            // Ürün Dağılımı Grafiği
            const productSalesData = @json($productSales);

            if (productSalesData.length > 0) {
                const productLabels = productSalesData.map(sale => {
                    // Ürün başlığını kısaltma
                    const title = sale.product.title;
                    const match = title.match(/(\d+) Adet/);
                    return match ? match[1] + ' Adet' : title;
                });

                const productTotals = productSalesData.map(sale => parseFloat(sale.total));

                const productOptions = {
                    series: productTotals,
                    chart: {
                        type: 'donut',
                        height: 380,
                    },
                    labels: productLabels,
                    colors: ['#4284F5', '#2AB57D', '#F7B84B', '#F06548', '#564AB1', '#33C2E8'],
                    legend: {
                        position: 'bottom'
                    },
                    dataLabels: {
                        enabled: false
                    },
                    tooltip: {
                        y: {
                            formatter: function(val) {
                                return val.toFixed(2) + "₺";
                            }
                        }
                    }
                };

                const productChart = new ApexCharts(document.querySelector("#product-distribution-chart"), productOptions);
                productChart.render();
            } else {
                document.querySelector("#product-distribution-chart").innerHTML = '<div class="d-flex align-items-center justify-content-center" style="height: 380px;"><p class="text-muted">Veri bulunamadı</p></div>';
            }
        });
    </script>
@endsection