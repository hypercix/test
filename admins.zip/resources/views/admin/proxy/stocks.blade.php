@extends('admin.layouts.app')
@section('title', 'Proxy Stokları')

@section('content')
    <div class="container-fluid">
        <!-- Başlık -->
        <div class="row">
            <div class="col-12">
                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                    <h4 class="mb-sm-0">
                        {{ $proxy->title }} - Stoklar
                    </h4>
                    <div class="page-title-right">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="{{ route('admin.proxy.index') }}">Proxy Yönetimi</a></li>
                            <li class="breadcrumb-item active">Stoklar</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

        <!-- Stok Tablosu -->
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header d-flex align-items-center">
                        <h5 class="card-title flex-grow-1 mb-0">Proxy Stokları</h5>
                        <div class="flex-shrink-0 d-flex gap-2">
                            <a href="{{ route('admin.proxy.edit', $proxy->id) }}" class="btn btn-soft-info btn-sm">
                                <i class="ri-pencil-line me-1"></i> Ürünü Düzenle
                            </a>
                            <a href="{{ route('admin.proxy.bulk-stocks') }}" class="btn btn-soft-primary btn-sm">
                                <i class="ri-add-line me-1"></i> Toplu Stok Ekle
                            </a>
                        </div>
                    </div>

                    <div class="card-header bg-soft-light border-top border-bottom">
                        <!-- Filtre ve Arama -->
                        <div class="row align-items-center">
                            <div class="col-md-4">
                                <div class="d-flex align-items-center gap-2">
                                    <div class="flex-shrink-0">
                                        <label for="status-filter" class="form-label mb-0">Durum:</label>
                                    </div>
                                    <div class="flex-grow-1">
                                        <select class="form-select form-select-sm" id="status-filter">
                                            <option value="all">Tümü</option>
                                            <option value="0">Satılmamış</option>
                                            <option value="1">Satılmış</option>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-4">
                                <div class="d-flex align-items-center gap-2">
                                    <div class="flex-shrink-0">
                                        <button type="button" class="btn btn-sm btn-primary" id="toggle-select-all">
                                            <i class="ri-checkbox-multiple-line me-1"></i> Tümünü Seç
                                        </button>
                                    </div>
                                    <div class="flex-shrink-0">
                                        <button type="button" class="btn btn-sm btn-danger" id="delete-selected" disabled>
                                            <i class="ri-delete-bin-line me-1"></i> Seçilenleri Sil
                                        </button>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-4">
                                <div class="search-box">
                                    <input type="text" class="form-control form-control-sm" id="search-input" placeholder="Stok içeriğinde ara...">
                                    <i class="ri-search-line search-icon"></i>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered table-nowrap align-middle mb-0">
                                <thead class="table-light">
                                <tr>
                                    <th class="text-center" width="40">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" id="checkAll">
                                        </div>
                                    </th>
                                    <th class="text-center" width="60">ID</th>
                                    <th>İçerik</th>
                                    <th class="text-center" width="100">Durum</th>
                                    <th class="text-center" width="120">Sipariş</th>
                                    <th class="text-center" width="160">Tarih</th>
                                    <th class="text-center" width="100">İşlemler</th>
                                </tr>
                                </thead>
                                <tbody>
                                @forelse($stocks as $stock)
                                    <tr data-status="{{ $stock->status }}">
                                        <td class="text-center">
                                            <div class="form-check">
                                                <input class="form-check-input stock-checkbox" type="checkbox"
                                                       value="{{ $stock->id }}" {{ $stock->status == 1 ? 'disabled' : '' }}>
                                            </div>
                                        </td>
                                        <td class="text-center">{{ $stock->id }}</td>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <button type="button" class="btn btn-sm btn-soft-info me-2 copy-btn"
                                                        data-clipboard-text="{{ $stock->content }}" title="Kopyala">
                                                    <i class="ri-file-copy-line"></i>
                                                </button>
                                                <div class="stock-content">
                                                    {{ $stock->content }}
                                                </div>
                                            </div>
                                        </td>
                                        <td class="text-center">
                                            @if($stock->status == 0)
                                                <span class="badge bg-success-subtle text-success">Satılmamış</span>
                                            @else
                                                <span class="badge bg-info-subtle text-info">Satılmış</span>
                                            @endif
                                        </td>
                                        <td class="text-center">
                                            @if($stock->order_id)
                                                <a href="{{ route('admin.orders.show', $stock->order_id) }}" class="text-primary">
                                                    #{{ $stock->order_id }}
                                                </a>
                                            @else
                                                <span class="text-muted">-</span>
                                            @endif
                                        </td>
                                        <td class="text-center">{{ $stock->created_at->format('d.m.Y H:i') }}</td>
                                        <td class="text-center">
                                            @if($stock->status == 0)
                                                <button type="button" class="btn btn-sm btn-soft-danger"
                                                        onclick="confirmDelete({{ $stock->id }})"
                                                        data-bs-toggle="tooltip" title="Sil">
                                                    <i class="ri-delete-bin-line"></i>
                                                </button>
                                            @else
                                                <span class="text-muted">-</span>
                                            @endif
                                        </td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="7" class="text-center py-4">
                                            <div class="d-flex flex-column align-items-center">
                                                <i class="ri-inbox-line display-5 text-muted"></i>
                                                <p class="mt-2">Bu ürüne ait stok bulunamadı.</p>
                                                <a href="{{ route('admin.proxy.edit', $proxy->id) }}" class="btn btn-sm btn-primary mt-1">
                                                    <i class="ri-add-line me-1"></i> Stok Ekle
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                @endforelse
                                </tbody>
                            </table>
                        </div>

                        <!-- Pagination -->
                        @if($stocks->hasPages())
                            <div class="d-flex justify-content-end mt-3">
                                {{ $stocks->links() }}
                            </div>
                        @endif

                        <div class="mt-3">
                            <div class="alert alert-info mb-0">
                                <div class="d-flex">
                                    <div class="flex-shrink-0">
                                        <i class="ri-information-line me-2 align-middle fs-16"></i>
                                    </div>
                                    <div class="flex-grow-1">
                                        <p class="mb-0">
                                            Toplam {{ $stocks->total() }} stok,
                                            {{ $proxy->stocks()->where('status', 0)->count() }} satılabilir,
                                            {{ $proxy->stocks()->where('status', 1)->count() }} satılmış.
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Silme Onay Modalı -->
    <div class="modal fade" id="deleteModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Proxy Stokunu Sil</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p>Bu proxy stokunu silmek istediğinizden emin misiniz? Bu işlem geri alınamaz.</p>
                </div>
                <div class="modal-footer">
                    <form id="deleteForm" method="POST" action="">
                        @csrf
                        @method('DELETE')
                        <button type="button" class="btn btn-light" data-bs-dismiss="modal">İptal</button>
                        <button type="submit" class="btn btn-danger">Evet, Sil</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Toplu Silme Onay Modalı -->
    <div class="modal fade" id="bulkDeleteModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Seçili Stokları Sil</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p>Seçili <span id="selected-count">0</span> adet stoku silmek istediğinizden emin misiniz? Bu işlem geri alınamaz.</p>
                </div>
                <div class="modal-footer">
                    <form id="bulkDeleteForm" method="POST" action="{{ route('admin.proxy.bulk-delete') }}">
                        @csrf
                        <input type="hidden" name="stock_ids" id="selected-ids">
                        <button type="button" class="btn btn-light" data-bs-dismiss="modal">İptal</button>
                        <button type="submit" class="btn btn-danger">Evet, Sil</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('script')
    <script src="https://cdn.jsdelivr.net/npm/clipboard@2.0.11/dist/clipboard.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Clipboard.js ile kopyalama
            var clipboard = new ClipboardJS('.copy-btn');

            clipboard.on('success', function(e) {
                const button = e.trigger;
                const originalText = button.innerHTML;

                button.innerHTML = '<i class="ri-check-line"></i>';
                button.classList.add('btn-success');
                button.classList.remove('btn-soft-info');

                setTimeout(function() {
                    button.innerHTML = originalText;
                    button.classList.remove('btn-success');
                    button.classList.add('btn-soft-info');
                }, 1000);

                e.clearSelection();
            });

            // Tümünü Seç/Hiçbirini Seçme
            const checkAllBox = document.getElementById('checkAll');
            const stockCheckboxes = document.querySelectorAll('.stock-checkbox:not([disabled])');

            checkAllBox.addEventListener('change', function() {
                stockCheckboxes.forEach(checkbox => {
                    checkbox.checked = this.checked;
                });
                updateDeleteButton();
            });

            // Toplu seçim toggle butonu
            document.getElementById('toggle-select-all').addEventListener('click', function() {
                const allChecked = [...stockCheckboxes].every(cb => cb.checked);

                stockCheckboxes.forEach(checkbox => {
                    checkbox.checked = !allChecked;
                });

                checkAllBox.checked = !allChecked;
                updateDeleteButton();
            });

            // Her checkbox değiştiğinde
            stockCheckboxes.forEach(checkbox => {
                checkbox.addEventListener('change', function() {
                    updateDeleteButton();

                    // Eğer tüm checkbox'lar seçili ise, "checkAll" da seçili olmalı
                    const allChecked = [...stockCheckboxes].every(cb => cb.checked);
                    checkAllBox.checked = allChecked;
                });
            });

            // Silme butonunu güncelle
            function updateDeleteButton() {
                const selectedCount = document.querySelectorAll('.stock-checkbox:checked').length;
                const deleteButton = document.getElementById('delete-selected');

                deleteButton.disabled = selectedCount === 0;
                document.getElementById('selected-count').textContent = selectedCount;
            }

            // Seçilenleri sil butonu
            document.getElementById('delete-selected').addEventListener('click', function() {
                const selectedIds = [...document.querySelectorAll('.stock-checkbox:checked')].map(cb => cb.value);

                if (selectedIds.length > 0) {
                    document.getElementById('selected-ids').value = selectedIds.join(',');

                    const bulkDeleteModal = new bootstrap.Modal(document.getElementById('bulkDeleteModal'));
                    bulkDeleteModal.show();
                }
            });

            // Filtre işlemleri
            document.getElementById('status-filter').addEventListener('change', function() {
                const status = this.value;
                const rows = document.querySelectorAll('tbody tr');

                rows.forEach(row => {
                    if (status === 'all' || row.dataset.status === status) {
                        row.style.display = '';
                    } else {
                        row.style.display = 'none';
                    }
                });
            });

            // Arama işlemi
            document.getElementById('search-input').addEventListener('keyup', function() {
                const searchValue = this.value.toLowerCase();
                const rows = document.querySelectorAll('tbody tr');

                rows.forEach(row => {
                    const content = row.querySelector('.stock-content')?.textContent.toLowerCase();

                    if (content && content.includes(searchValue)) {
                        row.style.display = '';
                    } else {
                        row.style.display = 'none';
                    }
                });
            });

            // Tooltip'leri etkinleştir
            const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
            tooltipTriggerList.map(function(tooltipTriggerEl) {
                return new bootstrap.Tooltip(tooltipTriggerEl);
            });
        });

        // Tek silme işlemi
        function confirmDelete(id) {
            document.getElementById('deleteForm').action = '/admin/proxy/stock/' + id;

            const deleteModal = new bootstrap.Modal(document.getElementById('deleteModal'));
            deleteModal.show();
        }
    </script>
@endsection