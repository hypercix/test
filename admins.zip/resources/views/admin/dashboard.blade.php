@extends('admin.layouts.app')

@section('title', 'Admin Panel')

@section('content')
    <!-- Genel İstatistikler Kartları -->
    <div class="row">
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-primary shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                Kullanıcılar</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">{{ $stats['users'] }}</div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-users fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-success shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                Ürünler</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">{{ $stats['products'] }}</div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-box fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-info shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                Siparişler</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">{{ $stats['orders'] }}</div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-shopping-cart fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-warning shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                Stok</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">{{ $stats['stocks'] }}</div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-layer-group fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Satış İstatistikleri -->
    <div class="row">
        <div class="col-lg-12 mb-4">
            <div class="card shadow">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold text-primary">Satış İstatistikleri</h6>
                </div>
                <div class="card-body">
                    <div class="row">
                        <!-- Bugünkü Satışlar -->
                        <div class="col-lg-4 mb-4">
                            <div class="card bg-success text-white">
                                <div class="card-body">
                                    <div class="card-title d-flex justify-content-between align-items-start">
                                        <h5 class="text-white">Bugün</h5>
                                        <i class="fas fa-calendar-day fa-2x text-white-50"></i>
                                    </div>
                                    <div class="mt-3">
                                        <h2 class="text-white">{{ number_format($todaySales->total ?? 0, 2) }}₺</h2>
                                        <div class="text-white-50">
                                            <span class="mr-2">{{ $todaySales->count ?? 0 }} Sipariş</span> |
                                            <span>{{ $todaySales->quantity ?? 0 }} Ürün</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Bu Haftaki Satışlar -->
                        <div class="col-lg-4 mb-4">
                            <div class="card bg-primary text-white">
                                <div class="card-body">
                                    <div class="card-title d-flex justify-content-between align-items-start">
                                        <h5 class="text-white">Bu Hafta</h5>
                                        <i class="fas fa-calendar-week fa-2x text-white-50"></i>
                                    </div>
                                    <div class="mt-3">
                                        <h2 class="text-white">{{ number_format($weekSales->total ?? 0, 2) }}₺</h2>
                                        <div class="text-white-50">
                                            <span class="mr-2">{{ $weekSales->count ?? 0 }} Sipariş</span> |
                                            <span>{{ $weekSales->quantity ?? 0 }} Ürün</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Bu Ayki Satışlar -->
                        <div class="col-lg-4 mb-4">
                            <div class="card bg-info text-white">
                                <div class="card-body">
                                    <div class="card-title d-flex justify-content-between align-items-start">
                                        <h5 class="text-white">Bu Ay</h5>
                                        <i class="fas fa-calendar-alt fa-2x text-white-50"></i>
                                    </div>
                                    <div class="mt-3">
                                        <h2 class="text-white">{{ number_format($monthSales->total ?? 0, 2) }}₺</h2>
                                        <div class="text-white-50">
                                            <span class="mr-2">{{ $monthSales->count ?? 0 }} Sipariş</span> |
                                            <span>{{ $monthSales->quantity ?? 0 }} Ürün</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <!-- Son Siparişler -->
        <div class="col-lg-6">
            <div class="card shadow mb-4">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold text-primary">Son Siparişler</h6>
                    <a href="{{ route('admin.orders.index') }}" class="btn btn-sm btn-primary">
                        <i class="fas fa-list fa-sm"></i> Tümünü Gör
                    </a>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" width="100%" cellspacing="0">
                            <thead>
                            <tr>
                                <th>ID</th>
                                <th>Kullanıcı</th>
                                <th>Ürün</th>
                                <th>Fiyat</th>
                                <th>Durum</th>
                                <th>Tarih</th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($recentOrders as $order)
                                <tr>
                                    <td>{{ $order->id }}</td>
                                    <td>{{ optional($order->user)->email ?? 'Silinmiş' }}</td>
                                    <td>{{ optional($order->product)->title ?? 'Silinmiş' }}</td>
                                    <td>{{ number_format($order->price, 2) }}₺</td>
                                    <td>
                                        @if($order->status == 0)
                                            <span class="badge bg-warning">Bekliyor</span>
                                        @else
                                            <span class="badge bg-success">Teslim Edildi</span>
                                        @endif
                                    </td>
                                    <td>{{ $order->created_at->format('d.m.Y H:i') }}</td>
                                </tr>
                            @endforeach

                            @if($recentOrders->isEmpty())
                                <tr>
                                    <td colspan="6" class="text-center">Henüz sipariş bulunmuyor.</td>
                                </tr>
                            @endif
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Ürün Stok Raporu -->
        <div class="col-lg-6">
            <div class="card shadow mb-4">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold text-primary">Ürün Stok Raporu</h6>
                    <a href="{{ route('admin.products.index') }}" class="btn btn-sm btn-primary">
                        <i class="fas fa-list fa-sm"></i> Tümünü Gör
                    </a>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" width="100%" cellspacing="0">
                            <thead>
                            <tr>
                                <th>Ürün</th>
                                <th>Mevcut Stok</th>
                                <th>Satılan</th>
                                <th>Toplam</th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($productStocks as $product)
                                <tr>
                                    <td>{{ $product->title }}</td>
                                    <td>{{ $product->available_stock }} adet</td>
                                    <td>{{ $product->sold_stock }} adet</td>
                                    <td>{{ $product->available_stock + $product->sold_stock }} adet</td>
                                </tr>
                            @endforeach

                            @if($productStocks->isEmpty())
                                <tr>
                                    <td colspan="4" class="text-center">Henüz ürün bulunmuyor.</td>
                                </tr>
                            @endif
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <!-- Son Kayıt Olan Kullanıcılar -->
        <div class="col-lg-6">
            <div class="card shadow mb-4">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold text-primary">Son Kayıt Olan Kullanıcılar</h6>
                    <a href="{{ route('admin.users.index') }}" class="btn btn-sm btn-primary">
                        <i class="fas fa-list fa-sm"></i> Tümünü Gör
                    </a>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" width="100%" cellspacing="0">
                            <thead>
                            <tr>
                                <th>ID</th>
                                <th>Ad Soyad</th>
                                <th>E-posta</th>
                                <th>Bakiye</th>
                                <th>Kayıt Tarihi</th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($recentUsers as $user)
                                <tr>
                                    <td>{{ $user->id }}</td>
                                    <td>{{ $user->name }}</td>
                                    <td>{{ $user->email }}</td>
                                    <td>{{ number_format($user->balance, 2) }}₺</td>
                                    <td>{{ $user->created_at->format('d.m.Y H:i') }}</td>
                                </tr>
                            @endforeach

                            @if($recentUsers->isEmpty())
                                <tr>
                                    <td colspan="5" class="text-center">Henüz kullanıcı bulunmuyor.</td>
                                </tr>
                            @endif
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection