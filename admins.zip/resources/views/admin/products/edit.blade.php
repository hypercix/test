@extends('admin.layouts.app')

@section('title', 'Ürün Düzenle')

@section('content')
    <div class="card mb-4">
        <div class="card-header">
            <h3 class="card-title">Ürün Düzenle: {{ $product->title }}</h3>
        </div>
        <div class="card-body">
            <form action="{{ route('admin.products.update', $product) }}" method="POST">
                @csrf
                @method('PUT')

                <div class="mb-3">
                    <label for="title" class="form-label">Ürün Adı</label>
                    <input type="text" class="form-control @error('title') is-invalid @enderror" id="title" name="title" value="{{ old('title', $product->title) }}" required>
                    @error('title')
                    <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>

                <div class="mb-3">
                    <label for="type" class="form-label">Tür</label>
                    <input type="text" class="form-control @error('type') is-invalid @enderror" id="type" name="type" value="{{ old('type', $product->type) }}">
                    @error('type')
                    <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>

                <div class="mb-3">
                    <label for="price" class="form-label">Fiyat (₺)</label>
                    <input type="number" step="0.01" class="form-control @error('price') is-invalid @enderror" id="price" name="price" value="{{ old('price', $product->price) }}" required>
                    @error('price')
                    <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>

                <div class="mb-3">
                    <label for="delivery_format" class="form-label">Teslim Şekli</label>
                    <input type="text" class="form-control @error('delivery_format') is-invalid @enderror" id="delivery_format" name="delivery_format" value="{{ old('delivery_format', $product->delivery_format) }}">
                    @error('delivery_format')
                    <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>

                <div class="mb-3">
                    <label for="description" class="form-label">Açıklama</label>
                    <textarea class="form-control @error('description') is-invalid @enderror" id="description" name="description" rows="5">{{ old('description', $product->description) }}</textarea>
                    @error('description')
                    <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>

                <div class="d-flex justify-content-between">
                    <a href="{{ route('admin.products.index') }}" class="btn btn-secondary">İptal</a>
                    <button type="submit" class="btn btn-primary">Güncelle</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Stok Listesi -->
    <div class="card mb-4">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h3 class="card-title">Stoklar</h3>
            <button type="button" class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#importStocksModal">
                <i class="fas fa-upload"></i> Toplu Stok Ekle
            </button>
        </div>
        <div class="card-body">
            @php
                $availableStocks = $product->stocks()->where('status', 0)->count();
                $soldStocks = $product->stocks()->where('status', 1)->count();
            @endphp

            <div class="row mb-4">
                <div class="col-md-6">
                    <div class="card bg-success text-white">
                        <div class="card-body">
                            <h5 class="card-title">Mevcut Stok</h5>
                            <p class="card-text display-6">{{ $availableStocks }} adet</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card bg-info text-white">
                        <div class="card-body">
                            <h5 class="card-title">Satılan Stok</h5>
                            <p class="card-text display-6">{{ $soldStocks }} adet</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="table-responsive">
                <table class="table table-striped table-hover">
                    <thead>
                    <tr>
                        <th>ID</th>
                        <th>İçerik</th>
                        <th>Durum</th>
                        <th>Eklenme Tarihi</th>
                        <th>İşlemler</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($product->stocks()->latest()->take(15)->get() as $stock)
                        <tr>
                            <td>{{ $stock->id }}</td>
                            <td>{{ \Illuminate\Support\Str::limit($stock->content, 50) }}</td>
                            <td>
                                @if($stock->status == 0)
                                    <span class="badge bg-success">Stokta</span>
                                @else
                                    <span class="badge bg-warning">Satıldı</span>
                                @endif
                            </td>
                            <td>{{ $stock->created_at->format('d.m.Y H:i') }}</td>
                            <td>
                                <div class="btn-group">
                                    <a href="{{ route('admin.stocks.edit', $stock) }}" class="btn btn-sm btn-info">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <button type="button" class="btn btn-sm btn-danger" onclick="confirmDeleteStock({{ $stock->id }})">
                                        <i class="fas fa-trash"></i>
                                    </button>

                                    <form id="delete-stock-form-{{ $stock->id }}" action="{{ route('admin.stocks.destroy', $stock) }}" method="POST" style="display: none;">
                                        @csrf
                                        @method('DELETE')
                                    </form>
                                </div>
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>

            <div class="text-center mt-3">
                <a href="{{ route('admin.stocks.index', ['product_id' => $product->id]) }}" class="btn btn-outline-primary">
                    Tüm Stokları Görüntüle
                </a>
            </div>
        </div>
    </div>

    <!-- Toplu Stok Ekleme Modal -->
    <div class="modal fade" id="importStocksModal" tabindex="-1" aria-labelledby="importStocksModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <form action="{{ route('admin.products.import-stocks', $product) }}" method="POST">
                    @csrf

                    <div class="modal-header">
                        <h5 class="modal-title" id="importStocksModalLabel">Toplu Stok Ekle: {{ $product->title }}</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>

                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="stock_content" class="form-label">Stok İçerikleri</label>
                            <p class="text-muted">Her satıra bir stok içeriği gelecek şekilde ekleyin.</p>
                            <textarea class="form-control" id="stock_content" name="stock_content" rows="10" required></textarea>
                        </div>
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                        <button type="submit" class="btn btn-primary">Stokları Ekle</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection

@section('scripts')
    <script>
        function confirmDeleteStock(stockId) {
            if (confirm('Bu stoku silmek istediğinize emin misiniz?')) {
                document.getElementById('delete-stock-form-' + stockId).submit();
            }
        }
    </script>
@endsection