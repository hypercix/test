@extends('admin.layouts.app')

@section('title', 'Stok Yönetimi')

@section('content')
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center mb-3">
        <h1 class="h2">Stoklar</h1>
    </div>

    <div class="card mb-4">
        <div class="card-header">
            <h3 class="card-title">Filtrele</h3>
        </div>
        <div class="card-body">
            <form action="{{ route('admin.stocks.index') }}" method="GET">
                <div class="row">
                    <div class="col-md-4">
                        <div class="mb-3">
                            <label for="product_id" class="form-label">Ürün</label>
                            <select class="form-select" id="product_id" name="product_id">
                                <option value="">Tüm Ürünler</option>
                                @foreach($products as $product)
                                    <option value="{{ $product->id }}" {{ request('product_id') == $product->id ? 'selected' : '' }}>
                                        {{ $product->title }}
                                    </option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="mb-3">
                            <label for="status" class="form-label">Durum</label>
                            <select class="form-select" id="status" name="status">
                                <option value="">Tüm Durumlar</option>
                                <option value="0" {{ request('status') === '0' ? 'selected' : '' }}>Stokta</option>
                                <option value="1" {{ request('status') === '1' ? 'selected' : '' }}>Satıldı</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-4 d-flex align-items-end">
                        <div class="mb-3 w-100">
                            <button type="submit" class="btn btn-primary w-100">Filtrele</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped table-hover">
                    <thead>
                    <tr>
                        <th>ID</th>
                        <th>Ürün</th>
                        <th>İçerik</th>
                        <th>Durum</th>
                        <th>Eklenme Tarihi</th>
                        <th>İşlemler</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($stocks as $stock)
                        <tr>
                            <td>{{ $stock->id }}</td>
                            <td>{{ optional($stock->product)->title }}</td>
                            <td>{{ \Illuminate\Support\Str::limit($stock->content, 50) }}</td>
                            <td>
                                @if($stock->status == 0)
                                    <span class="badge bg-success">Stokta</span>
                                @else
                                    <span class="badge bg-warning">Satıldı</span>
                                @endif
                            </td>
                            <td>{{ $stock->created_at->format('d.m.Y H:i') }}</td>
                            <td>
                                <div class="btn-group">
                                    <a href="{{ route('admin.stocks.edit', $stock) }}" class="btn btn-sm btn-info">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <button type="button" class="btn btn-sm btn-danger" onclick="confirmDelete({{ $stock->id }})">
                                        <i class="fas fa-trash"></i>
                                    </button>

                                    <form id="delete-form-{{ $stock->id }}" action="{{ route('admin.stocks.destroy', $stock) }}" method="POST" style="display: none;">
                                        @csrf
                                        @method('DELETE')
                                    </form>
                                </div>
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>

            <div class="d-flex justify-content-center mt-4">
                {{ $stocks->links('vendor.pagination.custom') }}
            </div>
        </div>
    </div>
@endsection

@section('scripts')
    <script>
        function confirmDelete(stockId) {
            if (confirm('Bu stoku silmek istediğinize emin misiniz?')) {
                document.getElementById('delete-form-' + stockId).submit();
            }
        }
    </script>
@endsection