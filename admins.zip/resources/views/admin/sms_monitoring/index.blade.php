@extends('admin.layouts.app')

@section('title', 'SMS Aktivasyon İzleme')

@section('content')
    <div class="row">
        <!-- İstatistik Kartları -->
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-primary shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                Toplam Aktivasyon</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">{{ $stats['total'] }}</div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-sms fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-success shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                Başarılı Aktivasyon (Toplam)</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">{{ $stats['completed_total'] }}</div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-check-circle fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-info shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                Bugünkü Aktivasyon</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">{{ $stats['today'] }}</div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-calendar-day fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-warning shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                Başarısız Aktivasyon (Bugün)</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">{{ $stats['failed_today'] }}</div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-times-circle fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- İkinci satır istatistik kartları -->
    <div class="row mb-4">
        <div class="col-xl-6 col-md-6">
            <div class="card border-left-success shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                Başarılı Aktivasyon (Bugün)</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">{{ $stats['completed_today'] }}</div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-check fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-6 col-md-6">
            <div class="card border-left-danger shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-danger text-uppercase mb-1">
                                Başarısız Aktivasyon (Toplam)</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">{{ $stats['failed_total'] }}</div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-ban fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Filtre Kartı -->
    <div class="card mb-4">
        <div class="card-header">
            <h5 class="card-title mb-0">Filtreleme</h5>
        </div>
        <div class="card-body">
            <form action="{{ route('admin.sms-monitoring.index') }}" method="GET">
                <div class="row">
                    <div class="col-md-3">
                        <div class="mb-3">
                            <label for="search" class="form-label">Arama</label>
                            <input type="text" class="form-control" id="search" name="search" value="{{ request('search') }}" placeholder="Telefon, kod veya kullanıcı">
                        </div>
                    </div>

                    <div class="col-md-3">
                        <div class="mb-3">
                            <label for="status" class="form-label">Durum</label>
                            <select class="form-select" id="status" name="status">
                                <option value="">Tüm Durumlar</option>
                                @foreach($statuses as $value => $label)
                                    <option value="{{ $value }}" {{ request('status') == $value ? 'selected' : '' }}>{{ $label }}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>

                    <div class="col-md-3">
                        <div class="mb-3">
                            <label for="service" class="form-label">Servis</label>
                            <select class="form-select" id="service" name="service">
                                <option value="">Tüm Servisler</option>
                                @foreach($services as $code => $name)
                                    <option value="{{ $code }}" {{ request('service') == $code ? 'selected' : '' }}>{{ $name }}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>

                    <div class="col-md-3">
                        <div class="mb-3">
                            <label for="user_id" class="form-label">Kullanıcı</label>
                            <select class="form-select" id="user_id" name="user_id">
                                <option value="">Tüm Kullanıcılar</option>
                                @foreach($users as $user)
                                    <option value="{{ $user->id }}" {{ request('user_id') == $user->id ? 'selected' : '' }}>{{ $user->name }} ({{ $user->email }})</option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-3">
                        <div class="mb-3">
                            <label for="date_from" class="form-label">Başlangıç Tarihi</label>
                            <input type="date" class="form-control" id="date_from" name="date_from" value="{{ request('date_from') }}">
                        </div>
                    </div>

                    <div class="col-md-3">
                        <div class="mb-3">
                            <label for="date_to" class="form-label">Bitiş Tarihi</label>
                            <input type="date" class="form-control" id="date_to" name="date_to" value="{{ request('date_to') }}">
                        </div>
                    </div>

                    <div class="col-md-6 d-flex align-items-end">
                        <div class="mb-3 d-flex gap-2 w-100">
                            <button type="submit" class="btn btn-primary flex-grow-1">
                                <i class="fas fa-filter me-1"></i> Filtrele
                            </button>
                            <a href="{{ route('admin.sms-monitoring.index') }}" class="btn btn-secondary">
                                <i class="fas fa-redo me-1"></i> Sıfırla
                            </a>
                            <a href="{{ route('admin.sms-monitoring.export') }}" class="btn btn-success">
                                <i class="fas fa-file-export me-1"></i> Dışa Aktar
                            </a>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Tablo Kartı -->
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h5 class="card-title mb-0">SMS Aktivasyonları</h5>
            <span class="badge bg-primary">Toplam: {{ $activations->total() }}</span>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped table-hover">
                    <thead>
                    <tr>
                        <th>ID</th>
                        <th>Kullanıcı</th>
                        <th>Servis</th>
                        <th>Telefon</th>
                        <th>Fiyat</th>
                        <th>Durum</th>
                        <th>SMS</th>
                        <th>Tarih</th>
                        <th>İşlemler</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($activations as $activation)
                        <tr>
                            <td>{{ $activation->id }}</td>
                            <td>
                                @if($activation->user)
                                    <a href="{{ route('admin.users.edit', $activation->user) }}">{{ $activation->user->email }}</a>
                                @else
                                    <span class="text-muted">Kullanıcı Silinmiş</span>
                                @endif
                            </td>
                            <td>{{ $serviceNames[$activation->service] ?? $activation->service }}</td>
                            <td>{{ $activation->phone_number }}</td>
                            <td>{{ number_format($activation->price, 2) }}₺</td>
                            <td>
                                @if($activation->status == 'waiting')
                                    <span class="badge bg-warning">Bekliyor</span>
                                @elseif($activation->status == 'waiting_with_message')
                                    <span class="badge bg-info">Mesaj Aldı, Bekliyor</span>
                                @elseif($activation->status == 'completed')
                                    <span class="badge bg-success">Tamamlandı</span>
                                @elseif($activation->status == 'canceled')
                                    <span class="badge bg-danger">İptal</span>
                                @elseif($activation->status == 'expired')
                                    <span class="badge bg-secondary">Süresi Doldu</span>
                                @endif
                            </td>
                            <td>
                                @if($activation->messages->count() > 0)
                                    <span class="badge bg-success">{{ $activation->messages->count() }} Mesaj</span>
                                @else
                                    <span class="badge bg-secondary">Mesaj Yok</span>
                                @endif
                            </td>
                            <td>{{ $activation->created_at->format('d.m.Y H:i') }}</td>
                            <td>
                                <a href="{{ route('admin.sms-monitoring.show', $activation) }}" class="btn btn-sm btn-info">
                                    <i class="fas fa-eye"></i> Detay
                                </a>
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>

            @if($activations->isEmpty())
                <div class="text-center py-4">
                    <p class="text-muted">Sonuç bulunamadı.</p>
                </div>
            @endif

            <div class="d-flex justify-content-center mt-4">
                {{ $activations->links('vendor.pagination.custom') }}
            </div>
        </div>
    </div>
@endsection