@extends('admin.layouts.app')

@section('title', 'SMS Aktivasyon Detayı #' . $activation->id)

@section('content')
    <div class="mb-3">
        <a href="{{ route('admin.sms-monitoring.index') }}" class="btn btn-secondary">
            <i class="fas fa-arrow-left me-1"></i> Listeye Dön
        </a>
    </div>

    <div class="row">
        <!-- Aktivasyon Bilgileri -->
        <div class="col-lg-6">
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="card-title">Aktivasyon Bilgileri</h5>
                </div>
                <div class="card-body">
                    <table class="table table-bordered">
                        <tr>
                            <th style="width: 30%">ID</th>
                            <td>{{ $activation->id }}</td>
                        </tr>
                        <tr>
                            <th>Kullanıcı</th>
                            <td>
                                @if($activation->user)
                                    <a href="{{ route('admin.users.edit', $activation->user) }}">
                                        {{ $activation->user->name }} ({{ $activation->user->email }})
                                    </a>
                                @else
                                    <span class="text-muted">Kullanıcı Silinmiş</span>
                                @endif
                            </td>
                        </tr>
                        <tr>
                            <th>Servis</th>
                            <td>{{ $serviceName }} ({{ $activation->service }})</td>
                        </tr>
                        <tr>
                            <th>Ülke</th>
                            <td>{{ $activation->country }}</td>
                        </tr>
                        <tr>
                            <th>Telefon</th>
                            <td>{{ $activation->phone_number }}</td>
                        </tr>
                        <tr>
                            <th>Fiyat</th>
                            <td>{{ number_format($activation->price, 2) }}₺</td>
                        </tr>
                        <tr>
                            <th>Durum</th>
                            <td>
                                @if($activation->status == 'waiting')
                                    <span class="badge bg-warning">Bekliyor</span>
                                @elseif($activation->status == 'waiting_with_message')
                                    <span class="badge bg-info">Mesaj Aldı, Bekliyor</span>
                                @elseif($activation->status == 'completed')
                                    <span class="badge bg-success">Tamamlandı</span>
                                @elseif($activation->status == 'canceled')
                                    <span class="badge bg-danger">İptal</span>
                                @elseif($activation->status == 'expired')
                                    <span class="badge bg-secondary">Süresi Doldu</span>
                                @endif
                            </td>
                        </tr>
                        <tr>
                            <th>SMS Kodu</th>
                            <td>
                                @if($activation->code)
                                    <div style="max-height: 100px; overflow-y: auto; white-space: pre-line;">{{ $activation->code }}</div>
                                @else
                                    <span class="text-muted">Kod Yok</span>
                                @endif
                            </td>
                        </tr>
                        <tr>
                            <th>Oluşturulma Tarihi</th>
                            <td>{{ $activation->created_at->format('d.m.Y H:i:s') }}</td>
                        </tr>
                        <tr>
                            <th>Son Geçerlilik Tarihi</th>
                            <td>
                                @if($activation->expires_at)
                                    {{ $activation->expires_at->format('d.m.Y H:i:s') }}
                                    @if($activation->isExpired())
                                        <span class="badge bg-danger ms-2">Süre Dolmuş</span>
                                    @endif
                                @else
                                    <span class="text-muted">Belirtilmemiş</span>
                                @endif
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>

        <!-- SMS Mesajları -->
        <div class="col-lg-6">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title">SMS Mesajları</h5>
                </div>
                <div class="card-body">
                    @if($activation->messages->count() > 0)
                        <div class="list-group">
                            @foreach($activation->messages->sortByDesc('received_at') as $message)
                                <div class="list-group-item">
                                    <div class="d-flex justify-content-between align-items-center mb-2">
                                        <small class="text-muted">
                                            <i class="fas fa-clock me-1"></i> {{ $message->received_at->format('d.m.Y H:i:s') }}
                                        </small>
                                        @if($message->phone_from)
                                            <small class="text-muted">
                                                <i class="fas fa-phone me-1"></i> {{ $message->phone_from }}
                                            </small>
                                        @endif
                                    </div>
                                    <div style="white-space: pre-line;">{{ $message->text }}</div>
                                </div>
                            @endforeach
                        </div>
                    @else
                        <div class="alert alert-info">
                            <i class="fas fa-info-circle me-1"></i> Bu aktivasyon için henüz SMS mesajı bulunmuyor.
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
@endsection