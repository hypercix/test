@extends('admin.layouts.app')

@section('title', 'Kullanıcı Düzenle')

@section('content')
    <div class="card mb-4">
        <div class="card-header">
            <h3 class="card-title">Kullanıcı Düzenle: {{ $user->name }}</h3>
        </div>
        <div class="card-body">
            <form action="{{ route('admin.users.update', $user) }}" method="POST">
                @csrf
                @method('PUT')

                <div class="mb-3">
                    <label for="name" class="form-label">Ad Soyad</label>
                    <input type="text" class="form-control @error('name') is-invalid @enderror" id="name" name="name" value="{{ old('name', $user->name) }}" required>
                    @error('name')
                    <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>

                <div class="mb-3">
                    <label for="email" class="form-label">E-posta</label>
                    <input type="email" class="form-control @error('email') is-invalid @enderror" id="email" name="email" value="{{ old('email', $user->email) }}" required>
                    @error('email')
                    <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>

                <div class="mb-3">
                    <label for="password" class="form-label">Şifre (Değiştirmek istemiyorsanız boş bırakın)</label>
                    <input type="password" class="form-control @error('password') is-invalid @enderror" id="password" name="password">
                    @error('password')
                    <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>

                <div class="mb-3">
                    <label for="balance" class="form-label">Mevcut Bakiye (₺)</label>
                    <div class="input-group">
                        <input type="number" step="0.01" class="form-control @error('balance') is-invalid @enderror" id="balance" value="{{ $user->balance }}" readonly>
                        <button type="button" class="btn btn-outline-primary" data-bs-toggle="modal" data-bs-target="#balanceModal">
                            <i class="fas fa-plus"></i> Bakiye Ekle
                        </button>
                    </div>
                    <small class="text-muted">Bakiye eklemek için "Bakiye Ekle" butonunu kullanın.</small>
                    @error('balance')
                    <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>

                <div class="mb-3 form-check">
                    <input type="checkbox" class="form-check-input" id="is_admin" name="is_admin" value="1" {{ old('is_admin', $user->is_admin) ? 'checked' : '' }}>
                    <label class="form-check-label" for="is_admin">Yönetici Yetkisi</label>
                </div>

                <div class="d-flex justify-content-between">
                    <a href="{{ route('admin.users.index') }}" class="btn btn-secondary">İptal</a>
                    <button type="submit" class="btn btn-primary">Güncelle</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Bakiye İşlemleri -->
    <div class="card mb-4">
        <div class="card-header">
            <h3 class="card-title">Bakiye İşlemleri</h3>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped table-hover">
                    <thead>
                    <tr>
                        <th>İşlem No</th>
                        <th>Miktar</th>
                        <th>Not</th>
                        <th>Tarih</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($user->balanceTransactions()->latest()->get() as $transaction)
                        <tr>
                            <td>{{ $transaction->id }}</td>
                            <td class="{{ $transaction->amount > 0 ? 'text-success' : 'text-danger' }}">
                                {{ $transaction->amount > 0 ? '+' : '' }}{{ $transaction->amount }} ₺
                            </td>
                            <td>{{ $transaction->note ?? '-' }}</td>
                            <td>{{ $transaction->created_at->format('d.m.Y H:i') }}</td>
                        </tr>
                    @endforeach

                    @if($user->balanceTransactions()->count() == 0)
                        <tr>
                            <td colspan="4" class="text-center">Henüz bakiye işlemi bulunmuyor.</td>
                        </tr>
                    @endif
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Bakiye Ekleme Modal -->
    <div class="modal fade" id="balanceModal" tabindex="-1" aria-labelledby="balanceModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form action="{{ route('admin.users.add-balance', $user) }}" method="POST">
                    @csrf

                    <div class="modal-header">
                        <h5 class="modal-title" id="balanceModalLabel">Bakiye Ekle</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>

                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="amount" class="form-label">Miktar (₺)</label>
                            <input type="number" step="0.01" class="form-control" id="amount" name="amount" required min="1">
                        </div>

                        <div class="mb-3">
                            <label for="note" class="form-label">Not (İsteğe Bağlı)</label>
                            <textarea class="form-control" id="note" name="note" rows="3"></textarea>
                        </div>
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                        <button type="submit" class="btn btn-primary">Bakiye Ekle</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection