@extends('admin.layouts.app')

@section('title', 'Sipariş Yönetimi')

@section('content')
    <div class="card mb-4">
        <div class="card-header">
            <h3 class="card-title">Sipariş Filtrele</h3>
        </div>
        <div class="card-body">
            <form action="{{ route('admin.orders.index') }}" method="GET">
                <div class="row">
                    <div class="col-md-3">
                        <div class="mb-3">
                            <label for="status" class="form-label">Durum</label>
                            <select class="form-select" id="status" name="status">
                                <option value="">Tüm Durumlar</option>
                                <option value="0" {{ request('status') === '0' ? 'selected' : '' }}>Bekliyor</option>
                                <option value="1" {{ request('status') === '1' ? 'selected' : '' }}>Teslim Edildi</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="mb-3">
                            <label for="date_from" class="form-label">Başlangıç Tarihi</label>
                            <input type="date" class="form-control" id="date_from" name="date_from" value="{{ request('date_from') }}">
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="mb-3">
                            <label for="date_to" class="form-label">Bitiş Tarihi</label>
                            <input type="date" class="form-control" id="date_to" name="date_to" value="{{ request('date_to') }}">
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="mb-3">
                            <label for="search" class="form-label">Ara</label>
                            <input type="text" class="form-control" id="search" name="search" placeholder="E-posta, isim veya ürün" value="{{ request('search') }}">
                        </div>
                    </div>
                </div>
                <div class="text-end">
                    <a href="{{ route('admin.orders.index') }}" class="btn btn-secondary">Sıfırla</a>
                    <button type="submit" class="btn btn-primary">Filtrele</button>
                </div>
            </form>
        </div>
    </div>

    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h3 class="card-title">Siparişler</h3>
            <span class="badge bg-primary">Toplam: {{ $orders->total() }}</span>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped table-hover">
                    <thead>
                    <tr>
                        <th>ID</th>
                        <th>Kullanıcı</th>
                        <th>Ürün</th>
                        <th>Adet</th>
                        <th>Fiyat</th>
                        <th>Durum</th>
                        <th>Tarih</th>
                        <th>İşlemler</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($orders as $order)
                        <tr>
                            <td>{{ $order->id }}</td>
                            <td>
                                @if($order->user)
                                    <a href="{{ route('admin.users.edit', $order->user) }}">{{ $order->user->email }}</a>
                                @else
                                    <span class="text-muted">Kullanıcı Silinmiş</span>
                                @endif
                            </td>
                            <td>{{ optional($order->product)->title }}</td>
                            <td>{{ $order->quantity }}</td>
                            <td>{{ number_format($order->price, 2) }}₺</td>
                            <td>
                                @if($order->status == 0)
                                    <span class="badge bg-warning">Bekliyor</span>
                                @else
                                    <span class="badge bg-success">Teslim Edildi</span>
                                @endif
                            </td>
                            <td>{{ $order->created_at->format('d.m.Y H:i') }}</td>
                            <td>
                                <a href="{{ route('admin.orders.show', $order) }}" class="btn btn-sm btn-primary">
                                    <i class="fas fa-eye"></i> Görüntüle
                                </a>
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>

            @if($orders->isEmpty())
                <div class="text-center py-4">
                    <p class="text-muted">Sonuç bulunamadı.</p>
                </div>
            @endif

            <div class="d-flex justify-content-center mt-4">
                {{ $orders->links('vendor.pagination.custom') }}
            </div>
        </div>
    </div>
@endsection