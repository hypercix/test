@extends('admin.layouts.app')

@section('title', 'Sipariş Detayı #' . $order->id)

@section('content')
    <div class="row">
        <div class="col-md-8">
            <!-- Sipariş Bilgileri -->
            <div class="card mb-4">
                <div class="card-header">
                    <h3 class="card-title">Sipariş Bilgileri</h3>
                </div>
                <div class="card-body">
                    <div class="row mb-3">
                        <div class="col-md-4">
                            <strong>Sipariş No:</strong>
                        </div>
                        <div class="col-md-8">
                            #{{ $order->id }}
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-4">
                            <strong>Ürün:</strong>
                        </div>
                        <div class="col-md-8">
                            {{ optional($order->product)->title }}
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-4">
                            <strong>Miktar:</strong>
                        </div>
                        <div class="col-md-8">
                            {{ $order->quantity }} adet
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-4">
                            <strong>Fiyat:</strong>
                        </div>
                        <div class="col-md-8">
                            {{ number_format($order->price, 2) }}₺
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-4">
                            <strong>Sipariş Tarihi:</strong>
                        </div>
                        <div class="col-md-8">
                            {{ $order->created_at->format('d.m.Y H:i') }}
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-4">
                            <strong>Durum:</strong>
                        </div>
                        <div class="col-md-8">
                            @if($order->status == 0)
                                <span class="badge bg-warning">Bekliyor</span>
                            @else
                                <span class="badge bg-success">Teslim Edildi</span>
                            @endif
                        </div>
                    </div>
                </div>
            </div>

            <!-- Müşteri Bilgileri -->
            <div class="card mb-4">
                <div class="card-header">
                    <h3 class="card-title">Müşteri Bilgileri</h3>
                </div>
                <div class="card-body">
                    @if($order->user)
                        <div class="row mb-3">
                            <div class="col-md-4">
                                <strong>Müşteri:</strong>
                            </div>
                            <div class="col-md-8">
                                {{ $order->user->name }}
                            </div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-md-4">
                                <strong>E-posta:</strong>
                            </div>
                            <div class="col-md-8">
                                {{ $order->user->email }}
                            </div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-md-4">
                                <strong>Bakiye:</strong>
                            </div>
                            <div class="col-md-8">
                                {{ number_format($order->user->balance, 2) }}₺
                            </div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-md-4">
                                <strong>Kayıt Tarihi:</strong>
                            </div>
                            <div class="col-md-8">
                                {{ $order->user->created_at->format('d.m.Y') }}
                            </div>
                        </div>
                        <div class="mt-3">
                            <a href="{{ route('admin.users.edit', $order->user) }}" class="btn btn-sm btn-outline-primary">
                                <i class="fas fa-user"></i> Kullanıcı Detayı
                            </a>
                        </div>
                    @else
                        <div class="alert alert-warning">
                            Kullanıcı hesabı silinmiş.
                        </div>
                    @endif
                </div>
            </div>

            <!-- Stok Bilgileri -->
            <div class="card mb-4">
                <div class="card-header">
                    <h3 class="card-title">Stok Bilgileri</h3>
                </div>
                <div class="card-body">
                    @if($order->stocks->count() > 0)
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                <tr>
                                    <th>Stok ID</th>
                                    <th>İçerik</th>
                                    <th>Eklenme Tarihi</th>
                                </tr>
                                </thead>
                                <tbody>
                                @foreach($order->stocks as $stock)
                                    <tr>
                                        <td>{{ $stock->id }}</td>
                                        <td>
                                            <div style="max-height: 100px; overflow-y: auto;">
                                                {{ $stock->content }}
                                            </div>
                                        </td>
                                        <td>{{ $stock->created_at->format('d.m.Y H:i') }}</td>
                                    </tr>
                                @endforeach
                                </tbody>
                            </table>
                        </div>
                    @else
                        <div class="alert alert-info">
                            Bu siparişe henüz stok atanmamış.
                        </div>
                    @endif
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <!-- Sipariş İşlemleri -->
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Hızlı İşlemler</h3>
                </div>
                <div class="card-body">
                    <a href="{{ route('admin.orders.index') }}" class="btn btn-outline-secondary mb-2 w-100">
                        <i class="fas fa-arrow-left"></i> Sipariş Listesine Dön
                    </a>

                    @if($order->product)
                        <a href="{{ route('admin.products.edit', $order->product) }}" class="btn btn-outline-info mb-2 w-100">
                            <i class="fas fa-box"></i> Ürün Detayını Görüntüle
                        </a>
                    @endif
                </div>
            </div>
        </div>
    </div>
@endsection