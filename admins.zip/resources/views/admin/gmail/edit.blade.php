@extends('admin.layouts.app')
@section('title', 'Gmail Ürünü Düzenle')

@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                    <h4 class="mb-sm-0">Gmail Ürünü Düzenle</h4>
                    <div class="page-title-right">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="{{ route('admin.gmail.index') }}">Gmail Ürünleri</a></li>
                            <li class="breadcrumb-item active">Düzenle</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <!-- Ürün Bilgileri Düzenleme -->
            <div class="col-lg-8">
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title mb-0">Ürün Bilgileri</h5>
                    </div>
                    <div class="card-body">
                        <form action="{{ route('admin.gmail.update', $product->id) }}" method="POST">
                            @csrf
                            @method('PUT')

                            <div class="mb-3">
                                <label for="title" class="form-label">Ürün Adı</label>
                                <input type="text" class="form-control @error('title') is-invalid @enderror" id="title" name="title" value="{{ old('title', $product->title) }}" required>
                                @error('title')
                                <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>

                            <div class="mb-3">
                                <label for="price" class="form-label">Fiyat (₺)</label>
                                <input type="number" step="0.01" class="form-control @error('price') is-invalid @enderror" id="price" name="price" value="{{ old('price', $product->price) }}" required>
                                @error('price')
                                <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>

                            <div class="mb-3">
                                <label for="delivery_format" class="form-label">Teslimat Formatı</label>
                                <input type="text" class="form-control @error('delivery_format') is-invalid @enderror" id="delivery_format" name="delivery_format" value="{{ old('delivery_format', $product->delivery_format) }}" placeholder="Örn: mail:pass:recovery">
                                @error('delivery_format')
                                <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                                <div class="form-text">Hesapların nasıl teslim edileceğini belirtin. Örn: mail:şifre:telefon</div>
                            </div>

                            <div class="mb-3">
                                <label for="description" class="form-label">Açıklama</label>
                                <textarea class="form-control @error('description') is-invalid @enderror" id="description" name="description" rows="4">{{ old('description', $product->description) }}</textarea>
                                @error('description')
                                <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>

                            <div class="text-end">
                                <a href="{{ route('admin.gmail.index') }}" class="btn btn-light me-2">İptal</a>
                                <button type="submit" class="btn btn-primary">Güncelle</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Stok Ekleme -->
            <div class="col-lg-4">
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title mb-0">Stok Ekle</h5>
                    </div>
                    <div class="card-body">
                        <form action="{{ route('admin.gmail.import-stocks', $product->id) }}" method="POST">
                            @csrf

                            <div class="mb-3">
                                <label for="stock_content" class="form-label">Gmail Hesapları</label>
                                <textarea class="form-control @error('stock_content') is-invalid @enderror" id="stock_content" name="stock_content" rows="10" placeholder="Her satıra bir hesap bilgisi girin"></textarea>
                                @error('stock_content')
                                <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                                <div class="form-text">
                                    Her satıra bir Gmail hesabı bilgisi girin. Format: <br>
                                    örnek@gmail.com:şifre:kurtarmamail:telefon
                                </div>
                            </div>

                            <div class="text-end">
                                <button type="submit" class="btn btn-success">
                                    <i class="ri-upload-cloud-line me-1"></i> Stok Ekle
                                </button>
                            </div>
                        </form>
                    </div>
                </div>

                <div class="card mt-4">
                    <div class="card-header">
                        <h5 class="card-title mb-0">Stok Durumu</h5>
                    </div>
                    <div class="card-body">
                        <div class="d-flex align-items-center mb-3">
                            <div class="flex-grow-1">
                                <h6 class="mb-0">Toplam Stok</h6>
                            </div>
                            <div class="flex-shrink-0">
                                <h6 class="mb-0">{{ $product->stocks()->count() }}</h6>
                            </div>
                        </div>
                        <div class="d-flex align-items-center mb-3">
                            <div class="flex-grow-1">
                                <h6 class="mb-0">Satılabilir Stok</h6>
                            </div>
                            <div class="flex-shrink-0">
                                <h6 class="mb-0 text-success">{{ $product->stocks()->where('status', 0)->count() }}</h6>
                            </div>
                        </div>
                        <div class="d-flex align-items-center">
                            <div class="flex-grow-1">
                                <h6 class="mb-0">Satılan Stok</h6>
                            </div>
                            <div class="flex-shrink-0">
                                <h6 class="mb-0 text-primary">{{ $product->stocks()->where('status', 1)->count() }}</h6>
                            </div>
                        </div>

                        <div class="mt-4 text-center">
                            <a href="{{ route('admin.gmail.stocks', $product->id) }}" class="btn btn-soft-primary btn-sm w-100">
                                <i class="ri-list-check me-1"></i> Tüm Stokları Görüntüle
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection