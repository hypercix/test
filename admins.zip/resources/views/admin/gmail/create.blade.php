@extends('admin.layouts.app')
@section('title', 'Yeni Gmail Ürünü Ekle')

@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                    <h4 class="mb-sm-0">Yeni Gmail Ürünü Ekle</h4>
                    <div class="page-title-right">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="{{ route('admin.gmail.index') }}">Gmail Ürünleri</a></li>
                            <li class="breadcrumb-item active">Yeni Ekle</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title mb-0">Ürün Bilgileri</h5>
                    </div>
                    <div class="card-body">
                        <form action="{{ route('admin.gmail.store') }}" method="POST">
                            @csrf

                            <div class="row g-3">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="title" class="form-label">Ürün Adı</label>
                                        <input type="text" class="form-control @error('title') is-invalid @enderror" id="title" name="title" value="{{ old('title') }}" required>
                                        @error('title')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                        <div class="form-text">
                                            Örnek: "Gmail Accounts (Standart)", "Gmail Mobile (Premium)" gibi.
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="price" class="form-label">Fiyat (₺)</label>
                                        <input type="number" step="0.01" class="form-control @error('price') is-invalid @enderror" id="price" name="price" value="{{ old('price') }}" required>
                                        @error('price')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                </div>

                                <div class="col-12">
                                    <div class="mb-3">
                                        <label for="delivery_format" class="form-label">Teslimat Formatı</label>
                                        <input type="text" class="form-control @error('delivery_format') is-invalid @enderror" id="delivery_format" name="delivery_format" value="{{ old('delivery_format') }}" placeholder="Örn: email:password:recovery_email:phone">
                                        @error('delivery_format')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                        <div class="form-text">Kullanıcıya hesapların hangi formatta teslim edileceğini belirtin.</div>
                                    </div>
                                </div>

                                <div class="col-12">
                                    <div class="mb-3">
                                        <label for="description" class="form-label">Açıklama</label>
                                        <textarea class="form-control @error('description') is-invalid @enderror" id="description" name="description" rows="4">{{ old('description') }}</textarea>
                                        @error('description')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                        <div class="form-text">Ürün hakkında detaylı bilgi (opsiyonel).</div>
                                    </div>
                                </div>
                            </div>

                            <div class="row my-4">
                                <div class="col-12">
                                    <div class="alert alert-primary">
                                        <div class="d-flex">
                                            <div class="flex-shrink-0">
                                                <i class="ri-information-line text-primary align-middle fs-18 me-2"></i>
                                            </div>
                                            <div class="flex-grow-1">
                                                <h5 class="mt-0 text-primary">Önemli Bilgi</h5>
                                                <p class="mb-0">
                                                    Ürün oluşturduktan sonra, ürün düzenleme sayfasından stok ekleyebilirsiniz.
                                                    Gmail ürünleriniz <strong>"Gmail"</strong> ile başlamalıdır (örn: "Gmail Accounts").
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="text-end">
                                <a href="{{ route('admin.gmail.index') }}" class="btn btn-light me-2">İptal</a>
                                <button type="submit" class="btn btn-success">Oluştur</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection