@extends('admin.layouts.app')
@section('title', 'Gmail Ürün Stokları')

@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                    <h4 class="mb-sm-0">Gmail Stokları: {{ $product->title }}</h4>
                    <div class="page-title-right">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="{{ route('admin.gmail.index') }}">Gmail Ürünleri</a></li>
                            <li class="breadcrumb-item active">Stoklar</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="card-title mb-0">Stok Listesi</h5>
                        <div>
                            <a href="{{ route('admin.gmail.edit', $product->id) }}" class="btn btn-sm btn-primary">
                                <i class="ri-add-line me-1"></i> Stok Ekle
                            </a>
                            <button class="btn btn-sm btn-danger" id="btnDeleteSelected" disabled>
                                <i class="ri-delete-bin-line me-1"></i> Seçilenleri Sil
                            </button>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <div class="d-flex gap-2">
                                    <div class="flex-shrink-0">
                                        <button class="btn btn-sm btn-soft-primary" id="toggleSelectAll">Tümünü Seç</button>
                                    </div>
                                    <div class="flex-grow-1">
                                        <select class="form-select form-select-sm w-auto" id="filterStatus">
                                            <option value="">Tüm Durumlar</option>
                                            <option value="0">Satılmamış</option>
                                            <option value="1">Satılmış</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="search-box">
                                    <input type="text" class="form-control search" placeholder="Stok içeriğinde ara...">
                                    <i class="ri-search-line search-icon"></i>
                                </div>
                            </div>
                        </div>

                        <div class="table-responsive">
                            <table class="table table-striped table-nowrap align-middle">
                                <thead class="table-light">
                                <tr>
                                    <th width="50">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" id="checkAll">
                                        </div>
                                    </th>
                                    <th>ID</th>
                                    <th>İçerik</th>
                                    <th>Durum</th>
                                    <th>Sipariş</th>
                                    <th>Tarih</th>
                                    <th>İşlemler</th>
                                </tr>
                                </thead>
                                <tbody>
                                @forelse($stocks as $stock)
                                    <tr data-status="{{ $stock->status }}">
                                        <td>
                                            <div class="form-check">
                                                <input class="form-check-input stock-checkbox" type="checkbox" value="{{ $stock->id }}" {{ $stock->status == 1 ? 'disabled' : '' }}>
                                            </div>
                                        </td>
                                        <td>{{ $stock->id }}</td>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <button class="btn btn-xs btn-soft-info clipboard-btn me-1"
                                                        data-clipboard-text="{{ $stock->content }}"
                                                        title="Kopyala">
                                                    <i class="ri-clipboard-line"></i>
                                                </button>
                                                <span class="stock-content">{{ $stock->content }}</span>
                                            </div>
                                        </td>
                                        <td>
                                            @if($stock->status == 0)
                                                <span class="badge bg-success-subtle text-success">Satılmamış</span>
                                            @else
                                                <span class="badge bg-warning-subtle text-warning">Satılmış</span>
                                            @endif
                                        </td>
                                        <td>
                                            @if($stock->order_id)
                                                <a href="{{ route('admin.orders.show', $stock->order_id) }}" class="text-primary fw-medium">
                                                    #{{ $stock->order_id }}
                                                </a>
                                            @else
                                                <span class="text-muted">-</span>
                                            @endif
                                        </td>
                                        <td>{{ $stock->created_at->format('d.m.Y H:i') }}</td>
                                        <td>
                                            <div class="hstack gap-2">
                                                @if($stock->status == 0)
                                                    <button type="button" class="btn btn-sm btn-soft-danger"
                                                            onclick="confirmDelete('{{ route('admin.stocks.destroy', $stock->id) }}')"
                                                            title="Sil">
                                                        <i class="ri-delete-bin-line"></i>
                                                    </button>
                                                @else
                                                    <span class="text-muted">-</span>
                                                @endif
                                            </div>
                                        </td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="7" class="text-center">Henüz stok bulunmamaktadır.</td>
                                    </tr>
                                @endforelse
                                </tbody>
                            </table>
                        </div>

                        <div class="mt-3">
                            {{ $stocks->links() }}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Silme Onay Modalı -->
    <div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="deleteModalLabel">Silme Onayı</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    Bu stok kaydını silmek istediğinizden emin misiniz?
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-light" data-bs-dismiss="modal">İptal</button>
                    <form id="deleteForm" method="POST" action="">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-danger">Evet, Sil</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Çoklu Silme Modal -->
    <div class="modal fade" id="bulkDeleteModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Çoklu Silme Onayı</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p>Seçilen <span id="selectedCount">0</span> stok kaydını silmek istediğinizden emin misiniz?</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-light" data-bs-dismiss="modal">İptal</button>
                    <form id="bulkDeleteForm" method="POST" action="{{ route('admin.stocks.bulk-delete') }}">
                        @csrf
                        <input type="hidden" name="stock_ids" id="selectedStockIds">
                        <button type="submit" class="btn btn-danger">Evet, Sil</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('script')
    <script src="https://cdn.jsdelivr.net/npm/clipboard@2.0.11/dist/clipboard.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Clipboard
            var clipboard = new ClipboardJS('.clipboard-btn');

            clipboard.on('success', function(e) {
                const button = e.trigger;
                button.innerHTML = '<i class="ri-check-line"></i>';
                setTimeout(function() {
                    button.innerHTML = '<i class="ri-clipboard-line"></i>';
                }, 1000);
            });

            // Arama fonksiyonu
            document.querySelector('.search').addEventListener('keyup', function() {
                const searchText = this.value.toLowerCase();
                const rows = document.querySelectorAll('tbody tr');

                rows.forEach(row => {
                    const content = row.querySelector('.stock-content').textContent.toLowerCase();
                    if (content.includes(searchText)) {
                        row.style.display = '';
                    } else {
                        row.style.display = 'none';
                    }
                });
            });

            // Durum filtresi
            document.getElementById('filterStatus').addEventListener('change', function() {
                const status = this.value;
                const rows = document.querySelectorAll('tbody tr');

                rows.forEach(row => {
                    if (!status || row.dataset.status === status) {
                        row.style.display = '';
                    } else {
                        row.style.display = 'none';
                    }
                });
            });

            // Tümünü seç
            const checkAllBox = document.getElementById('checkAll');
            const stockCheckboxes = document.querySelectorAll('.stock-checkbox:not([disabled])');

            checkAllBox.addEventListener('change', function() {
                stockCheckboxes.forEach(checkbox => {
                    checkbox.checked = this.checked;
                });
                updateDeleteButton();
            });

            // Tümünü seç düğmesi
            document.getElementById('toggleSelectAll').addEventListener('click', function() {
                checkAllBox.checked = !checkAllBox.checked;
                stockCheckboxes.forEach(checkbox => {
                    checkbox.checked = checkAllBox.checked;
                });
                updateDeleteButton();
            });

            // Tekil checkbox değişikliği
            stockCheckboxes.forEach(checkbox => {
                checkbox.addEventListener('change', function() {
                    updateDeleteButton();
                    // Eğer tüm checkbox'lar seçiliyse, checkAll'ı da seç
                    checkAllBox.checked = document.querySelectorAll('.stock-checkbox:not([disabled]):checked').length === stockCheckboxes.length;
                });
            });

            // Silme butonu durumunu güncelle
            function updateDeleteButton() {
                const checkedCount = document.querySelectorAll('.stock-checkbox:checked').length;
                const deleteButton = document.getElementById('btnDeleteSelected');

                deleteButton.disabled = checkedCount === 0;
                document.getElementById('selectedCount').textContent = checkedCount;
            }

            // Çoklu silme işlemi
            document.getElementById('btnDeleteSelected').addEventListener('click', function() {
                const selectedIds = Array.from(document.querySelectorAll('.stock-checkbox:checked')).map(cb => cb.value);
                document.getElementById('selectedStockIds').value = selectedIds.join(',');

                const bulkDeleteModal = new bootstrap.Modal(document.getElementById('bulkDeleteModal'));
                bulkDeleteModal.show();
            });
        });

        // Tekil silme onayı
        function confirmDelete(url) {
            document.getElementById('deleteForm').action = url;
            const deleteModal = new bootstrap.Modal(document.getElementById('deleteModal'));
            deleteModal.show();
        }
    </script>
@endsection