@extends('layouts.master')
@section('title', 'Anasayfa')

@section('content')
    @component('components.breadcrumb')
        @slot('li_1') Anasayfa @endslot
        @slot('title') Anasayfa @endslot
    @endcomponent
    @php
        use Illuminate\Support\Str;
        $user = Auth::user();
        $balance = $user->balance ?? 0;
        $products = \App\Models\Product::withCount(['stocks' => fn($q) => $q->where('status', 0)])->get();

        // Stok sayıları için dizi oluşturalım
        $stockCounts = [];
        foreach ($products as $product) {
            $stockCounts[$product->title] = $product->stocks_count;
        }
    @endphp

    <style>
        :root {
            /* USKO Hesap Sayfasındaki renkler */
            --primary: #0284c7;
            --primary-light: #0ea5e9;
            --primary-dark: #0369a1;
            --primary-gradient: linear-gradient(135deg, #0ea5e9, #0284c7);
            --accent: #06b6d4;
            --background: #f8fafc;
            --card-bg: #ffffff;
            --border-color: #e5e7eb;
            --text-color: #1f2937;
            --text-muted: #6b7280;
            --card-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
            --hover-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }

        /* Genel Stiller */
        .page-container {
            padding: 0;
        }

        /* Kart Stilleri */
        .custom-card {
            background: var(--card-bg);
            border-radius: 10px;
            box-shadow: var(--card-shadow);
            margin-bottom: 20px;
            border: 1px solid var(--border-color);
            transition: all 0.3s ease;
            overflow: hidden;
        }

        .custom-card:hover {
            box-shadow: var(--hover-shadow);
            transform: translateY(-3px);
        }

        .card-title-section {
            padding: 15px 20px;
            border-bottom: 1px solid var(--border-color);
            display: flex;
            align-items: center;
            justify-content: space-between;
            background-color: #fbfbfd;
        }

        .card-title {
            margin: 0;
            font-size: 16px;
            font-weight: 600;
            display: flex;
            align-items: center;
        }

        .card-title i {
            margin-right: 8px;
            color: var(--primary);
        }

        .card-body-custom {
            padding: 20px;
        }

        /* Hoşgeldiniz Kartı - USKO Hesap Sayfası Benzeri */
        .welcome-card {
            background: var(--primary-gradient);
            color: white;
            border: none;
            padding: 20px 25px;
            border-radius: 10px;
            margin-bottom: 20px;
            position: relative;
            overflow: hidden;
        }

        .welcome-card::before, .welcome-card::after {
            content: '';
            position: absolute;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.1);
            z-index: 0;
        }

        .welcome-card::before {
            width: 150px;
            height: 150px;
            top: -50px;
            right: -30px;
        }

        .welcome-card::after {
            width: 100px;
            height: 100px;
            bottom: -30px;
            left: 30%;
        }

        .welcome-content {
            position: relative;
            z-index: 1;
        }

        .welcome-title {
            font-size: 22px;
            font-weight: 700;
            margin-bottom: 8px;
            text-shadow: 0 1px 2px rgba(0,0,0,0.1);
        }

        .welcome-message {
            font-size: 14px;
            opacity: 0.9;
            margin-bottom: 15px;
        }

        .balance-section {
            background: rgba(255, 255, 255, 0.15);
            border-radius: 8px;
            padding: 15px;
            margin: 15px 0;
            backdrop-filter: blur(5px);
        }

        .balance-label {
            font-size: 14px;
            opacity: 0.8;
            margin-bottom: 5px;
        }

        .balance-amount {
            font-size: 26px;
            font-weight: 700;
            text-shadow: 0 1px 2px rgba(0,0,0,0.1);
        }

        .btn-balance {
            background: rgba(255, 255, 255, 0.15);
            color: white;
            border: none;
            padding: 10px 18px;
            border-radius: 8px;
            display: inline-flex;
            align-items: center;
            font-weight: 500;
            transition: all 0.3s ease;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }

        .btn-balance:hover {
            background: rgba(255, 255, 255, 0.25);
            transform: translateY(-2px);
            box-shadow: 0 3px 6px rgba(0,0,0,0.15);
        }

        .btn-balance i {
            margin-right: 8px;
        }

        /* Hızlı İşlemler */
        .quick-actions {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 15px;
            margin-bottom: 20px;
        }

        .action-button {
            background: var(--card-bg);
            padding: 15px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--text-color);
            text-decoration: none;
            box-shadow: var(--card-shadow);
            border: 1px solid var(--border-color);
            transition: all 0.3s ease;
            font-weight: 500;
        }

        .action-button:hover {
            transform: translateY(-3px);
            box-shadow: var(--hover-shadow);
            color: var(--primary);
        }

        .action-button i {
            margin-right: 8px;
            color: var(--primary);
            font-size: 18px;
        }

        /* Ürün Listesi */
        .product-list {
            margin: 0;
            padding: 0;
            list-style: none;
        }

        .product-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px 15px;
            border-bottom: 1px solid var(--border-color);
            transition: background-color 0.2s ease;
        }

        .product-item:last-child {
            border-bottom: none;
        }

        .product-item:hover {
            background-color: #f9fafb;
        }

        .product-info {
            display: flex;
            align-items: center;
        }

        .product-info i {
            color: var(--primary);
            margin-right: 10px;
        }

        .product-title {
            font-weight: 500;
        }

        .product-actions {
            display: flex;
            align-items: center;
        }

        .product-stock {
            background-color: #e0f2fe;
            color: #0369a1;
            padding: 4px 10px;
            border-radius: 6px;
            font-size: 13px;
            font-weight: 500;
            margin-right: 10px;
        }

        .btn-small {
            padding: 5px 12px;
            font-size: 13px;
            border-radius: 6px;
            background-color: white;
            border: 1px solid var(--border-color);
            color: var(--primary);
            cursor: pointer;
            transition: all 0.2s ease;
            font-weight: 500;
        }

        .btn-small:hover {
            background-color: var(--primary);
            color: white;
            border-color: var(--primary);
        }

        /* Duyurular */
        .announcement-list {
            margin: 0;
            padding: 0;
            list-style: none;
        }

        .announcement-item {
            padding: 12px 0;
            border-bottom: 1px solid var(--border-color);
        }

        .announcement-item:last-child {
            border-bottom: none;
        }

        .announcement-date {
            font-size: 12px;
            color: var(--text-muted);
            margin-bottom: 5px;
            display: inline-block;
            background-color: #e0f2fe;
            color: #0369a1;
            padding: 3px 8px;
            border-radius: 4px;
        }

        .announcement-title {
            font-size: 15px;
            font-weight: 600;
            margin-bottom: 5px;
            color: var(--text-color);
        }

        .announcement-text {
            font-size: 13px;
            color: var(--text-muted);
        }

        /* İletişim Bağlantıları */
        .contact-link {
            display: flex;
            align-items: center;
            padding: 12px 0;
            text-decoration: none;
            color: var(--text-color);
            border-bottom: 1px solid var(--border-color);
        }

        .contact-link:last-child {
            border-bottom: none;
        }

        .contact-icon {
            width: 32px;
            height: 32px;
            border-radius: 6px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 12px;
        }

        .icon-telegram {
            background-color: #eef2ff;
            color: #4338ca;
        }

        .icon-whatsapp {
            background-color: #ecfdf5;
            color: #10b981;
        }

        .icon-email {
            background-color: #fef2f2;
            color: #ef4444;
        }

        .contact-info {
            flex: 1;
        }

        .contact-name {
            font-weight: 500;
            font-size: 14px;
            margin-bottom: 2px;
        }

        .contact-desc {
            font-size: 12px;
            color: var(--text-muted);
        }

        /* Hesap Bilgileri */
        .account-details dt {
            font-weight: 500;
            color: var(--text-muted);
            font-size: 13px;
            margin-bottom: 5px;
        }

        .account-details dd {
            margin-bottom: 15px;
            font-size: 14px;
        }

        .btn-outline-secondary {
            background-color: transparent;
            border: 1px solid var(--border-color);
            color: var(--text-color);
            padding: 8px 14px;
            border-radius: 6px;
            font-size: 13px;
            cursor: pointer;
            transition: all 0.2s ease;
            font-weight: 500;
            display: inline-flex;
            align-items: center;
        }

        .btn-outline-secondary:hover {
            background-color: #f3f4f6;
        }

        .btn-outline-secondary i {
            margin-right: 6px;
        }

        /* Sayfa Başlığı */
        .page-title {
            font-size: 20px;
            font-weight: 600;
            margin-bottom: 5px;
            color: var(--text-color);
        }

        .breadcrumb-item {
            font-size: 14px;
            color: var(--text-muted);
        }

        .breadcrumb-item a {
            color: var(--primary);
            text-decoration: none;
        }
    </style>


    <div class="row">
        <!-- Sol Taraf -->
        <div class="col-lg-8">
            <!-- Hoşgeldiniz Kartı -->
            <div class="welcome-card">
                <div class="welcome-content">
                    <h1 class="welcome-title">Hoş Geldiniz, {{ $user->name }}!</h1>
                    <p class="welcome-message">ACCZ.Net hesabınıza başarıyla giriş yaptınız.</p>

                    <div class="balance-section">
                        <div class="balance-label">Mevcut Bakiye</div>
                        <div class="balance-amount">{{ number_format($balance, 2) }}₺</div>
                    </div>

                    <button class="btn-balance" onclick="window.location.href='{{ route('payments.index') }}'">
                        <i class="ri-add-line"></i> Bakiye Yükle
                    </button>
                </div>
            </div>

            <!-- Hızlı İşlemler -->
            <div class="quick-actions">
                <a href="{{ route('uskohesap.index') }}" class="action-button">
                    <i class="ri-shopping-cart-2-line"></i> Alışveriş Yap
                </a>
                <a href="/panel/siparislerim" class="action-button">
                    <i class="ri-time-line"></i> Geçmiş Siparişler
                </a>
            </div>

            <!-- Ürün ve Stok Bilgileri -->
            <div class="custom-card">
                <div class="card-title-section">
                    <h6 class="card-title">
                        <i class="ri-box-3-line"></i> Ürün ve Stok Bilgileri
                    </h6>
                </div>
                <div class="card-body-custom p-0">
                    <ul class="product-list">
                        <li class="product-item">
                            <div class="product-info">
                                <i class="ri-checkbox-circle-line"></i>
                                <span class="product-title">ZERO (Auth ID-PASS)</span>
                            </div>
                            <div class="product-actions">
                                <span class="product-stock">{{ $stockCounts['ZERO (Auth ID-PASS)'] ?? 0 }} adet</span>
                                <a href="javascript:void(0)" onclick="goToProductTab('ZERO', 'Auth ID-PASS')" class="btn-small">İncele</a>
                            </div>
                        </li>
                        <li class="product-item">
                            <div class="product-info">
                                <i class="ri-checkbox-circle-line"></i>
                                <span class="product-title">ZERO (COPY OTP)</span>
                            </div>
                            <div class="product-actions">
                                <span class="product-stock">{{ $stockCounts['ZERO (COPY OTP)'] ?? 0 }} adet</span>
                                <a href="javascript:void(0)" onclick="goToProductTab('ZERO', 'COPY OTP')" class="btn-small">İncele</a>
                            </div>
                        </li>
                        <li class="product-item">
                            <div class="product-info">
                                <i class="ri-checkbox-circle-line"></i>
                                <span class="product-title">PANDORA (Auth ID-PASS)</span>
                            </div>
                            <div class="product-actions">
                                <span class="product-stock">{{ $stockCounts['PANDORA (Auth ID-PASS)'] ?? 0 }} adet</span>
                                <a href="javascript:void(0)" onclick="goToProductTab('PANDORA', 'Auth ID-PASS')" class="btn-small">İncele</a>
                            </div>
                        </li>
                        <li class="product-item">
                            <div class="product-info">
                                <i class="ri-checkbox-circle-line"></i>
                                <span class="product-title">PANDORA (COPY OTP)</span>
                            </div>
                            <div class="product-actions">
                                <span class="product-stock">{{ $stockCounts['PANDORA (COPY OTP)'] ?? 0 }} adet</span>
                                <a href="javascript:void(0)" onclick="goToProductTab('PANDORA', 'COPY OTP')" class="btn-small">İncele</a>
                            </div>
                        </li>
                        <li class="product-item">
                            <div class="product-info">
                                <i class="ri-checkbox-circle-line"></i>
                                <span class="product-title">AGARTHA (Auth ID-PASS)</span>
                            </div>
                            <div class="product-actions">
                                <span class="product-stock">{{ $stockCounts['AGARTHA (Auth ID-PASS)'] ?? 0 }} adet</span>
                                <a href="javascript:void(0)" onclick="goToProductTab('AGARTHA', 'Auth ID-PASS')" class="btn-small">İncele</a>
                            </div>
                        </li>
                        <li class="product-item">
                            <div class="product-info">
                                <i class="ri-checkbox-circle-line"></i>
                                <span class="product-title">AGARTHA (COPY OTP)</span>
                            </div>
                            <div class="product-actions">
                                <span class="product-stock">{{ $stockCounts['AGARTHA (COPY OTP)'] ?? 0 }} adet</span>
                                <a href="javascript:void(0)" onclick="goToProductTab('AGARTHA', 'COPY OTP')" class="btn-small">İncele</a>
                            </div>
                        </li>
                        <li class="product-item">
                            <div class="product-info">
                                <i class="ri-checkbox-circle-line"></i>
                                <span class="product-title">FELIS (Auth ID-PASS)</span>
                            </div>
                            <div class="product-actions">
                                <span class="product-stock">{{ $stockCounts['FELIS (Auth ID-PASS)'] ?? 0 }} adet</span>
                                <a href="javascript:void(0)" onclick="goToProductTab('FELIS', 'Auth ID-PASS')" class="btn-small">İncele</a>
                            </div>
                        </li>
                        <li class="product-item">
                            <div class="product-info">
                                <i class="ri-checkbox-circle-line"></i>
                                <span class="product-title">FELIS (COPY OTP)</span>
                            </div>
                            <div class="product-actions">
                                <span class="product-stock">{{ $stockCounts['FELIS (COPY OTP)'] ?? 0 }} adet</span>
                                <a href="javascript:void(0)" onclick="goToProductTab('FELIS', 'COPY OTP')" class="btn-small">İncele</a>
                            </div>
                        </li>
                        <li class="product-item">
                            <div class="product-info">
                                <i class="ri-checkbox-circle-line"></i>
                                <span class="product-title">ESKI SERVERLAR (OTP KAYDEDİLEBİLİR)</span>
                            </div>
                            <div class="product-actions">
                                <span class="product-stock">{{ $stockCounts['ESKI SERVERLAR (OTP KAYDEDİLEBİLİR)'] ?? 0 }} adet</span>
                                <a href="javascript:void(0)" onclick="goToProductTab('ESKI SERVERLAR', 'OTP KAYDEDİLEBİLİR')" class="btn-small">İncele</a>
                            </div>
                        </li>
                        <li class="product-item">
                            <div class="product-info">
                                <i class="ri-checkbox-circle-line"></i>
                                <span class="product-title">ESKI SERVERLAR (OTP KURULAMAZ)</span>
                            </div>
                            <div class="product-actions">
                                <span class="product-stock">{{ $stockCounts['ESKI SERVERLAR (OTP KURULAMAZ)'] ?? 0 }} adet</span>
                                <a href="javascript:void(0)" onclick="goToProductTab('ESKI SERVERLAR', 'OTP KURULAMAZ')" class="btn-small">İncele</a>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>

        <!-- Sağ Taraf -->
        <div class="col-lg-4">
            <!-- Duyurular -->
            <div class="custom-card">
                <div class="card-title-section">
                    <h6 class="card-title">
                        <i class="ri-notification-2-line"></i> Duyurular
                    </h6>
                </div>
                <div class="card-body-custom">
                    <ul class="announcement-list">
                        <li class="announcement-item">
                            <div class="announcement-date">21 Mart 2025</div>
                            <div class="announcement-title">Yeni SMS API Eklendi</div>
                            <div class="announcement-text">Artık daha hızlı ve güvenilir SMS gönderim imkanı sağlayan yeni API sistemimiz aktif.</div>
                        </li>
                        <li class="announcement-item">
                            <div class="announcement-date">18 Mart 2025</div>
                            <div class="announcement-title">SMS API Performans İyileştirildi</div>
                            <div class="announcement-text">Sistemimiz artık %40 daha hızlı çalışıyor ve daha az hata veriyor.</div>
                        </li>
                        <li class="announcement-item">
                            <div class="announcement-date">15 Mart 2025</div>
                            <div class="announcement-title">Profesyonel Kullanıcı Güncellemeleri</div>
                            <div class="announcement-text">ACCZ.Net profesyonel kullanıcılarımız için yeni özellikler ekledik.</div>
                        </li>
                    </ul>
                </div>
            </div>

            <!-- Hızlı İletişim -->
            <div class="custom-card">
                <div class="card-title-section">
                    <h6 class="card-title">
                        <i class="ri-customer-service-2-line"></i> Hızlı İletişim
                    </h6>
                </div>
                <div class="card-body-custom">
                    <a href="https://t.me/" class="contact-link">
                        <div class="contact-icon icon-telegram">
                            <i class="ri-telegram-fill"></i>
                        </div>
                        <div class="contact-info">
                            <div class="contact-name">Telegram</div>
                            <div class="contact-desc">7/24 Anında Destek</div>
                        </div>
                    </a>
                    <a href="https://wa.me/447459288735" class="contact-link">
                        <div class="contact-icon icon-whatsapp">
                            <i class="ri-whatsapp-fill"></i>
                        </div>
                        <div class="contact-info">
                            <div class="contact-name">WhatsApp</div>
                            <div class="contact-desc">Hızlı Mesajlaşma</div>
                        </div>
                    </a>
                    <a href="mailto:info@accz.net" class="contact-link">
                        <div class="contact-icon icon-email">
                            <i class="ri-mail-fill"></i>
                        </div>
                        <div class="contact-info">
                            <div class="contact-name">E-posta</div>
                            <div class="contact-desc">Detaylı Destek Talebi</div>
                        </div>
                    </a>
                </div>
            </div>

            <!-- Hesap Bilgileri -->
            <div class="custom-card">
                <div class="card-title-section">
                    <h6 class="card-title">
                        <i class="ri-user-settings-line"></i> Hesap Bilgileri
                    </h6>
                </div>
                <div class="card-body-custom">
                    <dl class="account-details">
                        <dt>IP Adresi</dt>
                        <dd>{{ request()->ip() }}</dd>

                        <dt>Son Giriş Zamanı</dt>
                        <dd>{{ \Carbon\Carbon::now()->format('d.m.Y H:i') }}</dd>
                    </dl>

                    <a href="/profile" class="btn-outline-secondary">
                        <i class="ri-lock-password-line"></i> Şifre Değiştir
                    </a>
                </div>
            </div>
        </div>
    </div>
    </div>
@endsection

@section('script')
    <script>
        // Ürün tabı için yönlendirme fonksiyonu
        function goToProductTab(server, type) {
            // Öncelikle uskohesap sayfasına git
            window.location.href = "{{ route('uskohesap.index') }}?server=" + encodeURIComponent(server) + "&type=" + encodeURIComponent(type);

            // Not: Burada sayfaya gittiğinde ilgili tabı otomatik olarak açacak bir JavaScript kodu da ekleyebiliriz
            // Ancak bu, sayfanın yapısına bağlı olarak değişir
            // Aşağıdaki gibi ek bir kod da gönderilebilir (localStorage kullanarak)

            localStorage.setItem('activeUskoTab', 'tab-' + (getServerIndex(server)));

            // Veya daha basit bir yöntem olarak query string parametreleri kullanılabilir
            // Sayfa yüklendiğinde bu parametreleri kontrol eden bir script ekleyebiliriz
        }

        // Server indeksini almak için yardımcı fonksiyon
        function getServerIndex(server) {
            const servers = ['ZERO', 'PANDORA', 'AGARTHA', 'FELIS', 'ESKI SERVERLAR'];
            return servers.indexOf(server);
        }
    </script>
    <script src="{{ URL::asset('build/js/app.js') }}"></script>
@endsection