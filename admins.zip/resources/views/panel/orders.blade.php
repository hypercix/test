@extends('layouts.master')
@section('title', 'Siparişlerim')

@section('css')
    <style>
        /* Modern kart stilleri */
        .stat-card {
            border-radius: 12px;
            border: none;
            overflow: hidden;
            transition: all 0.3s ease;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
            height: 100%;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
        }

        .stat-card .card-body {
            padding: 1.5rem;
        }

        .stat-card .card-title {
            font-size: 0.9rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 0.75rem;
            font-weight: 500;
            opacity: 0.9;
        }

        .stat-card .stat-value {
            font-size: 1.8rem;
            font-weight: 700;
            margin-bottom: 0;
        }

        .stat-card .stat-icon {
            position: absolute;
            top: 1.5rem;
            right: 1.5rem;
            font-size: 1.8rem;
            opacity: 0.2;
        }

        /* Modern tablo stilleri */
        .orders-table {
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
        }

        .orders-table .table {
            margin-bottom: 0;
        }

        .orders-table thead th {
            background-color: #f8f9fa;
            font-weight: 600;
            text-transform: uppercase;
            font-size: 0.8rem;
            letter-spacing: 0.5px;
            padding: 1rem;
            border-bottom: none;
        }

        .orders-table tbody tr {
            transition: all 0.2s ease;
            border-bottom: 1px solid #f5f5f5;
        }

        .orders-table tbody tr:hover {
            background-color: #f8f9fa;
            transform: scale(1.005);
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.05);
        }

        .orders-table tbody td {
            padding: 1rem;
            vertical-align: middle;
        }

        .order-id {
            font-weight: 600;
            color: #3b7ddd;
        }

        .btn-detail {
            border-radius: 50px;
            padding: 0.4rem 1rem;
            font-size: 0.8rem;
            font-weight: 500;
            transition: all 0.3s ease;
            box-shadow: 0 2px 5px rgba(59, 125, 221, 0.2);
        }

        .btn-detail:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(59, 125, 221, 0.3);
        }

        /* Pagination stilleri */
        .pagination {
            justify-content: center;
            margin-top: 2rem;
        }

        .pagination .page-item.active .page-link {
            background-color: #3b7ddd;
            border-color: #3b7ddd;
        }

        .pagination .page-link {
            color: #3b7ddd;
            border-radius: 5px;
            margin: 0 3px;
            padding: 0.5rem 0.75rem;
        }

        .empty-state {
            padding: 3rem 1rem;
            text-align: center;
        }

        .empty-state i {
            font-size: 3rem;
            color: #e0e0e0;
            margin-bottom: 1rem;
        }

        .empty-state p {
            color: #9e9e9e;
            font-size: 1rem;
        }
    </style>
@endsection

@section('content')
    @component('components.breadcrumb')
        @slot('li_1') Panel @endslot
        @slot('title') Siparişlerim @endslot
    @endcomponent

    <div class="container-fluid">
        <!-- İstatistik Kartları (modernize edilmiş) -->
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="card stat-card bg-gradient-primary text-white">
                    <div class="card-body">
                        <i class="ri-shopping-cart-line stat-icon"></i>
                        <h6 class="card-title">TOPLAM SATIN ALIM</h6>
                        <h3 class="stat-value">{{ $totalQuantity }}</h3>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card stat-card bg-gradient-success text-white">
                    <div class="card-body">
                        <i class="ri-currency-line stat-icon"></i>
                        <h6 class="card-title">TOPLAM HARCAMA</h6>
                        <h3 class="stat-value">{{ number_format($totalSpent, 2) }} ₺</h3>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card stat-card">
                    <div class="card-body">
                        <p class="m-0">Son siparişlerinizi aşağıda görebilirsiniz. Detaylı bilgi için "Detay" butonuna tıklayabilirsiniz.</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Sipariş Tablosu (modernize edilmiş) -->
        <div class="card orders-table">
            <div class="card-header d-flex justify-content-between align-items-center py-3">
                <h5 class="mb-0"><i class="ri-shopping-bag-line me-2"></i>Sipariş Geçmişiniz</h5>
                <div class="dropdown">
                    <button class="btn btn-sm btn-light" type="button" id="orderOptionsDropdown" data-bs-toggle="dropdown">
                        <i class="ri-filter-3-line me-1"></i> Filtrele
                    </button>
                    <ul class="dropdown-menu" aria-labelledby="orderOptionsDropdown">
                        <li><a class="dropdown-item" href="#">Tüm Siparişler</a></li>
                        <li><a class="dropdown-item" href="#">Son 7 Gün</a></li>
                        <li><a class="dropdown-item" href="#">Son 30 Gün</a></li>
                    </ul>
                </div>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                        <tr>
                            <th>SİPARİŞ NO</th>
                            <th>ÜRÜN</th>
                            <th>ADET</th>
                            <th>TOPLAM</th>
                            <th>TARİH</th>
                            <th>İŞLEM</th>
                        </tr>
                        </thead>
                        <tbody>
                        @forelse($orders as $order)
                            <tr>
                                <td class="order-id">#{{ $order->id }}</td>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <div class="avatar-sm me-2 bg-light rounded d-flex align-items-center justify-content-center">
                                            <i class="ri-shopping-bag-line text-primary"></i>
                                        </div>
                                        <span>{{ $order->product ? $order->product->title : 'Ürün Bulunamadı' }}</span>
                                    </div>
                                </td>
                                <td>{{ $order->quantity }}</td>
                                <td><span class="fw-bold">{{ number_format($order->price, 2) }} ₺</span></td>
                                <td>
                                    <div class="d-flex flex-column">
                                        <span class="fw-medium">{{ $order->created_at->format('d.m.Y') }}</span>
                                        <small class="text-muted">{{ $order->created_at->format('H:i') }}</small>
                                    </div>
                                </td>
                                <td>
                                    <a href="{{ route('panel.order.detail', $order->id) }}" class="btn btn-primary btn-detail">
                                        <i class="ri-eye-line me-1"></i> Detay
                                    </a>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="6">
                                    <div class="empty-state">
                                        <i class="ri-shopping-bag-line"></i>
                                        <p>Henüz sipariş bulunmamaktadır.</p>
                                    </div>
                                </td>
                            </tr>
                        @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
            @if($orders->count() > 0)
                <div class="card-footer bg-white py-3">
                    {{ $orders->links('vendor.pagination.custom') }}
                </div>
            @endif
        </div>
    </div>
@endsection

@section('script')
    <script src="{{ URL::asset('build/js/app.js') }}"></script>
@endsection