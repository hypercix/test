@extends('layouts.master')
@section('title', 'Sipariş Detayı')

@section('css')
    <style>
        /* Modern Sipariş Detay Sayfası Stilleri */
        .order-detail-card {
            border-radius: 10px;
            overflow: hidden;
            border: 1px solid #e0e0e0;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            margin-bottom: 2rem;
        }

        .order-header {
            background: linear-gradient(135deg, #2257bf, #1a439e);
            padding: 1.5rem;
            color: #fff;
            border-bottom: 2px solid #1a439e;
        }

        .order-id {
            font-weight: 700;
            font-size: 1.1rem;
            display: inline-block;
            background: rgba(255, 255, 255, 0.2);
            padding: 0.3rem 0.7rem;
            border-radius: 30px;
            margin-left: 0.5rem;
            border: 1px solid rgba(255, 255, 255, 0.3);
        }

        .order-body {
            padding: 2rem;
        }

        .order-info {
            background-color: #f5f7fa;
            border-radius: 8px;
            padding: 1.5rem;
            margin-bottom: 2rem;
            border: 1px solid #e5e9f2;
        }

        .info-label {
            color: #495057;
            font-size: 0.85rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 0.2rem;
            font-weight: 500;
        }

        .info-value {
            font-weight: 600;
            font-size: 1.1rem;
            color: #212529;
            margin-bottom: 1rem;
        }

        .accounts-section {
            margin-top: 2rem;
            border-top: 1px solid #e5e9f2;
            padding-top: 2rem;
        }

        .section-title {
            font-size: 1.1rem;
            font-weight: 600;
            margin-bottom: 1rem;
            display: flex;
            align-items: center;
            color: #2257bf;
        }

        .section-title i {
            margin-right: 0.5rem;
            background-color: #e9f2ff;
            color: #2257bf;
            width: 30px;
            height: 30px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            border: 1px solid #d1e3ff;
        }

        .accounts-table {
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
            border: 1px solid #e0e0e0;
        }

        .accounts-table th {
            background-color: #f2f4f8;
            font-weight: 600;
            text-transform: uppercase;
            font-size: 0.8rem;
            letter-spacing: 0.5px;
            padding: 1rem;
            border-bottom: 1px solid #e0e0e0;
            color: #495057;
        }

        .accounts-table td {
            padding: 1rem;
            vertical-align: middle;
            border-bottom: 1px solid #e9ecef;
        }

        .accounts-table tr:hover {
            background-color: #f8f9fa;
        }

        .account-number {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 30px;
            height: 30px;
            background-color: #2257bf;
            color: white;
            border-radius: 50%;
            font-weight: 600;
            font-size: 0.85rem;
            border: 1px solid #1a439e;
        }

        .content-code {
            font-family: 'Consolas', 'Monaco', monospace;
            background-color: #f8f9fa;
            padding: 0.75rem;
            border-radius: 5px;
            border: 1px solid #dde2e6;
            color: #212529;
            display: block;
            white-space: pre-wrap;
            word-break: break-all;
            font-size: 0.85rem;
            line-height: 1.5;
        }

        .copy-btn {
            padding: 0.3rem 0.6rem;
            font-size: 0.8rem;
            background-color: #f8f9fa;
            color: #495057;
            border: 1px solid #ced4da;
            border-radius: 4px;
            margin-left: 0.5rem;
            cursor: pointer;
            transition: all 0.2s;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
        }

        .copy-btn:hover {
            background-color: #2257bf;
            color: white;
            border-color: #2257bf;
        }

        .order-footer {
            background-color: #f5f7fa;
            padding: 1.5rem 2rem;
            border-top: 1px solid #e0e0e0;
        }

        /* İki buton için ortak stil - aynı gradient arka plan */
        .btn-back, .btn-download {
            background: linear-gradient(135deg, #2257bf, #1a439e);
            color: white !important;
            border: none;
            padding: 0.5rem 1.2rem;
            border-radius: 50px;
            font-weight: 500;
            box-shadow: 0 2px 5px rgba(26, 67, 158, 0.3);
            transition: all 0.3s;
        }

        .btn-back:hover, .btn-download:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(26, 67, 158, 0.4);
            color: white !important;
        }

        /* Bildirim toast style */
        .custom-toast {
            position: fixed;
            bottom: 20px;
            right: 20px;
            background-color: #2257bf;
            color: white;
            padding: 12px 20px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            z-index: 1060;
            display: flex;
            align-items: center;
        }

        .custom-toast i {
            margin-right: 8px;
        }

        /* Header'daki başlık yazısını daha belirgin yaptık */
        .order-header h4 {
            color: white !important;
            font-weight: 600;
            text-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
        }
    </style>
@endsection

@section('content')
    @component('components.breadcrumb')
        @slot('li_1') Panel @endslot
        @slot('title') Sipariş Detayı @endslot
    @endcomponent

    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-xl-8 col-lg-10">
                <div class="card order-detail-card">
                    <!-- Sipariş Başlığı -->
                    <div class="order-header">
                        <h4 class="mb-0 d-flex align-items-center">
                            <i class="ri-file-list-3-line me-2"></i>
                            Sipariş Detayı
                            <span class="order-id">#{{ $order->id }}</span>
                        </h4>
                    </div>

                    <!-- Sipariş Bilgileri -->
                    <div class="order-body">
                        <div class="order-info">
                            <div class="row">
                                <div class="col-md-6 col-sm-12 mb-3 mb-md-0">
                                    <div class="d-flex align-items-center mb-3">
                                        <div class="avatar-sm bg-light rounded d-flex align-items-center justify-content-center me-3" style="border: 1px solid #e0e0e0;">
                                            <i class="ri-shopping-bag-line text-primary"></i>
                                        </div>
                                        <div>
                                            <div class="info-label">Ürün</div>
                                            <div class="info-value">{{ $order->product->title }}</div>
                                        </div>
                                    </div>

                                    <div class="d-flex align-items-center">
                                        <div class="avatar-sm bg-light rounded d-flex align-items-center justify-content-center me-3" style="border: 1px solid #e0e0e0;">
                                            <i class="ri-calendar-line text-primary"></i>
                                        </div>
                                        <div>
                                            <div class="info-label">Tarih</div>
                                            <div class="info-value">{{ $order->created_at->format('d.m.Y H:i') }}</div>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-6 col-sm-12">
                                    <div class="d-flex align-items-center mb-3">
                                        <div class="avatar-sm bg-light rounded d-flex align-items-center justify-content-center me-3" style="border: 1px solid #e0e0e0;">
                                            <i class="ri-numbers-line text-primary"></i>
                                        </div>
                                        <div>
                                            <div class="info-label">Adet</div>
                                            <div class="info-value">{{ $order->quantity }}</div>
                                        </div>
                                    </div>

                                    <div class="d-flex align-items-center">
                                        <div class="avatar-sm bg-light rounded d-flex align-items-center justify-content-center me-3" style="border: 1px solid #e0e0e0;">
                                            <i class="ri-money-dollar-circle-line text-primary"></i>
                                        </div>
                                        <div>
                                            <div class="info-label">Toplam Tutar</div>
                                            <div class="info-value text-primary">{{ number_format($order->price, 2) }} ₺</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Teslim Edilen Hesaplar -->
                        <div class="accounts-section">
                            <div class="section-title">
                                <i class="ri-gift-line"></i>
                                Teslim Edilen Hesaplar ({{ $order->stocks->count() }})
                            </div>

                            <div class="accounts-table">
                                <table class="table mb-0">
                                    <thead>
                                    <tr>
                                        <th style="width: 80px;" class="text-center">Sıra</th>
                                        <th>İçerik</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    @foreach ($order->stocks as $index => $stock)
                                        <tr>
                                            <td class="text-center">
                                                <span class="account-number">{{ $index + 1 }}</span>
                                            </td>
                                            <td>
                                                <div class="d-flex align-items-start justify-content-between">
                                                    <code class="content-code">{{ $stock->content }}</code>
                                                    <button class="copy-btn" onclick="copyContent('{{ addslashes($stock->content) }}')">
                                                        <i class="ri-file-copy-line"></i>
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                    @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                    <!-- Sipariş Footer -->
                    <div class="order-footer d-flex justify-content-between align-items-center">
                        <a href="{{ route('panel.orders') }}" class="btn btn-back">
                            <i class="ri-arrow-left-line me-1"></i> Siparişlere Dön
                        </a>

                        <a href="{{ route('panel.order.download', $order->id) }}" class="btn btn-download">
                            <i class="ri-download-line me-1"></i> Hesapları İndir
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('script')
    <script src="{{ URL::asset('build/js/app.js') }}"></script>
    <script>
        function copyContent(content) {
            // JavaScript textarea oluştur ve kopyala
            var textarea = document.createElement('textarea');
            textarea.value = content;
            document.body.appendChild(textarea);
            textarea.select();
            document.execCommand('copy');
            document.body.removeChild(textarea);

            // Kullanıcıya bildirim göster
            var toastEl = document.createElement('div');
            toastEl.className = 'custom-toast';
            toastEl.innerHTML = '<i class="ri-check-line"></i> İçerik kopyalandı!';
            document.body.appendChild(toastEl);

            // 2 saniye sonra toast'ı kaldır
            setTimeout(function() {
                toastEl.style.opacity = '0';
                toastEl.style.transition = 'opacity 0.5s ease';
                setTimeout(function() {
                    document.body.removeChild(toastEl);
                }, 500);
            }, 2000);
        }
    </script>
@endsection