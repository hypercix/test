@extends('layouts.master')

@section('title', 'Ödeme Başarısız')

@section('content')
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-body text-center p-5">
                        <div class="mb-4">
                            <i class="ri-error-warning-line text-danger display-1"></i>
                        </div>

                        <h1 class="card-title mb-4">Ödeme Başarısız</h1>

                        <p class="lead mb-4">
                            Ödeme işleminiz sırasında bir hata oluştu.
                        </p>

                        <div class="alert alert-danger">
                            {{ $message }}
                        </div>

                        <div class="d-flex justify-content-center gap-3 mt-4">
                            <a href="{{ route('home') }}" class="btn btn-outline-secondary btn-lg">
                                <i class="ri-home-3-line me-1"></i> Ana Sayfa
                            </a>
                            <a href="{{ route('payments.index') }}" class="btn btn-primary btn-lg">
                                <i class="ri-restart-line me-1"></i> Tekrar Dene
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection