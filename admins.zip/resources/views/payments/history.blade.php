@extends('layouts.master')

@section('title', 'Ödeme Geçmişi')

@section('content')
    <div class="container py-4">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h4 class="card-title mb-0">Ödeme Geçmişi</h4>
                        <a href="{{ route('payments.index') }}" class="btn btn-primary">
                            <i class="ri-add-line me-1"></i> Bakiye Yükle
                        </a>
                    </div>
                    <div class="card-body">
                        @if($payments->isEmpty())
                            <div class="text-center py-5">
                                <i class="ri-inbox-line display-4 text-muted"></i>
                                <p class="mt-3">Henüz ödeme işlemi bulunmuyor.</p>
                                <a href="{{ route('payments.index') }}" class="btn btn-primary mt-3">
                                    İlk Bakiye Yüklemeni Yap
                                </a>
                            </div>
                        @else
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                    <tr>
                                        <th>İşlem No</th>
                                        <th>Tarih</th>
                                        <th>Tutar</th>
                                        <th>Ödeme Yöntemi</th>
                                        <th>Durum</th>
                                        <th>Açıklama</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    @foreach($payments as $payment)
                                        <tr>
                                            <td>{{ substr($payment->payment_id, 0, 10) }}...</td>
                                            <td>{{ $payment->created_at->format('d.m.Y H:i') }}</td>
                                            <td>{{ number_format($payment->amount, 2) }} TL</td>
                                            <td>
                                                @if($payment->payment_method === 'stripe')
                                                    <span class="badge bg-info">Kredi Kartı</span>
                                                @elseif($payment->payment_method === 'manual')
                                                    <span class="badge bg-secondary">Manuel</span>
                                                @else
                                                    <span class="badge bg-secondary">{{ $payment->payment_method }}</span>
                                                @endif
                                            </td>
                                            <td>
                                                @if($payment->status === 'succeeded')
                                                    <span class="badge bg-success">Başarılı</span>
                                                @elseif($payment->status === 'pending')
                                                    <span class="badge bg-warning">Beklemede</span>
                                                @elseif($payment->status === 'failed')
                                                    <span class="badge bg-danger">Başarısız</span>
                                                @elseif($payment->status === 'refunded')
                                                    <span class="badge bg-secondary">İade</span>
                                                @endif
                                            </td>
                                            <td>{{ $payment->description ?: 'Bakiye Yükleme' }}</td>
                                        </tr>
                                    @endforeach
                                    </tbody>
                                </table>
                            </div>

                            <div class="d-flex justify-content-center mt-4">
                                {{ $payments->links() }}
                            </div>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection