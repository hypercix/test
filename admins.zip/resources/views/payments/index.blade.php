@extends('layouts.master')

@section('title', 'Bakiye Yükle')

@section('css')
    <style>
        .amount-option {
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .amount-option:hover, .amount-option.active {
            background-color: #e9ecef;
            border-color: #adb5bd;
        }

        .payment-history-card {
            transition: all 0.3s ease;
        }

        .payment-history-card:hover {
            box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
        }
    </style>
@endsection

@section('content')
    <div class="container py-4">
        <div class="row">
            <div class="col-lg-8">
                <div class="card mb-4">
                    <div class="card-header">
                        <h4 class="card-title mb-0">Bakiye Yükleme</h4>
                    </div>
                    <div class="card-body">
                        @if (session('error'))
                            <div class="alert alert-danger">
                                {{ session('error') }}
                            </div>
                        @endif

                        <form action="{{ route('payments.checkout') }}" method="POST" id="balanceForm">
                            @csrf

                            <div class="mb-4">
                                <label class="form-label">Mevcut Bakiye</label>
                                <div class="input-group">
                                    <input type="text" class="form-control" value="{{ number_format($user->balance, 2) }} TL" readonly>
                                    <span class="input-group-text bg-primary text-white">
                                    <i class="ri-wallet-3-line"></i>
                                </span>
                                </div>
                            </div>

                            <div class="mb-4">
                                <label for="amount" class="form-label">Yüklenecek Tutar (TL)</label>
                                <input type="number" class="form-control @error('amount') is-invalid @enderror"
                                       id="amount" name="amount" min="10" step="1"
                                       value="{{ old('amount', 100) }}" required>
                                @error('amount')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                                @enderror
                                <div class="form-text">Minimum 10 TL, maksimum 10.000 TL yükleyebilirsiniz.</div>
                            </div>

                            <div class="mb-4">
                                <label class="form-label">Hızlı Tutar Seçimi</label>
                                <div class="row g-2">
                                    @foreach($predefinedAmounts as $predefinedAmount)
                                        <div class="col-4 col-md-2">
                                            <div class="card amount-option text-center py-2"
                                                 onclick="document.getElementById('amount').value = {{ $predefinedAmount }}">
                                                <div class="card-body p-0">
                                                    <h5 class="mb-0">{{ $predefinedAmount }} TL</h5>
                                                </div>
                                            </div>
                                        </div>
                                    @endforeach
                                </div>
                            </div>

                            <div class="d-grid gap-2">
                                <button type="submit" class="btn btn-primary btn-lg">
                                    <i class="ri-secure-payment-line me-2"></i> Ödeme Yap
                                </button>
                                <a href="{{ route('payments.history') }}" class="btn btn-outline-secondary">
                                    <i class="ri-history-line me-2"></i> Ödeme Geçmişim
                                </a>
                            </div>
                        </form>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title mb-0">Bakiye Yükleme Hakkında</h4>
                    </div>
                    <div class="card-body">
                        <h5>Ödeme Yöntemleri</h5>
                        <p>Bakiye yükleme işlemleriniz için kredi kartı veya banka kartı kullanabilirsiniz. Tüm ödemeleriniz Stripe altyapısı üzerinden gerçekleştirilmektedir.</p>

                        <h5>Güvenlik</h5>
                        <p>Stripe, PCI DSS Level 1 sertifikalı bir ödeme altyapısıdır. Kart bilgileriniz bizim sunucularımızda saklanmaz, tüm ödeme işlemleri Stripe güvenli altyapısı üzerinden gerçekleştirilir.</p>

                        <h5>Bakiye Kullanımı</h5>
                        <p>Yüklediğiniz bakiye, sitemizdeki tüm hizmetleri satın almak için kullanılabilir. Bakiyeniz hesabınızda süresiz olarak saklanır.</p>

                        <div class="alert alert-info mt-3">
                            <i class="ri-information-line me-2"></i>
                            <span>Sorun yaşarsanız, lütfen info@accz.net</a> ile iletişime geçin.</span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-4">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h4 class="card-title mb-0">Son İşlemler</h4>
                        <a href="{{ route('payments.history') }}" class="btn btn-sm btn-primary">Tümünü Gör</a>
                    </div>
                    <div class="card-body">
                        @if($recentPayments->isEmpty())
                            <div class="text-center py-4">
                                <i class="ri-inbox-line display-4 text-muted"></i>
                                <p class="mt-3">Henüz ödeme işlemi bulunmuyor.</p>
                            </div>
                        @else
                            <div class="list-group list-group-flush">
                                @foreach($recentPayments as $payment)
                                    <div class="list-group-item px-0 payment-history-card">
                                        <div class="d-flex justify-content-between align-items-center">
                                            <div>
                                                <h6 class="mb-1">{{ number_format($payment->amount, 2) }} TL</h6>
                                                <p class="text-muted small mb-0">
                                                    {{ $payment->created_at->format('d.m.Y H:i') }}
                                                </p>
                                            </div>
                                            <div>
                                                @if($payment->status === 'succeeded')
                                                    <span class="badge bg-success">Başarılı</span>
                                                @elseif($payment->status === 'pending')
                                                    <span class="badge bg-warning">Beklemede</span>
                                                @elseif($payment->status === 'failed')
                                                    <span class="badge bg-danger">Başarısız</span>
                                                @elseif($payment->status === 'refunded')
                                                    <span class="badge bg-secondary">İade</span>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                @endforeach
                            </div>
                        @endif
                    </div>
                </div>

                <div class="card mt-4">
                    <div class="card-body">
                        <h5 class="card-title">Neden Bakiye Yüklemeliyim?</h5>
                        <ul class="list-unstyled">
                            <li class="mb-2">
                                <i class="ri-check-line text-success me-2"></i>
                                <span>Anlık hizmet satın alımları için ön yükleme</span>
                            </li>
                            <li class="mb-2">
                                <i class="ri-check-line text-success me-2"></i>
                                <span>Daha hızlı işlem yapma imkanı</span>
                            </li>
                            <li class="mb-2">
                                <i class="ri-check-line text-success me-2"></i>
                                <span>İhtiyaç duyduğunuzda anında hizmet alımı</span>
                            </li>
                            <li class="mb-2">
                                <i class="ri-check-line text-success me-2"></i>
                                <span>Hesabınızda süresiz bakiye kullanımı</span>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('script')
    <script>
        // Hızlı tutar seçimini aktif etme
        document.querySelectorAll('.amount-option').forEach(option => {
            option.addEventListener('click', function() {
                document.querySelectorAll('.amount-option').forEach(opt => {
                    opt.classList.remove('active');
                });
                this.classList.add('active');
            });
        });
    </script>
@endsection