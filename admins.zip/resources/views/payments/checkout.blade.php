@extends('layouts.master')

@section('title', 'Ödeme')

@section('css')
    <style>
        #payment-form {
            max-width: 500px;
            margin: 0 auto;
        }

        #payment-element {
            margin-bottom: 24px;
        }

        /* Spinner/Processing state */
        #spinner,
        #button-text {
            display: inline-block;
            transition: visibility 0.1s linear;
        }

        #spinner {
            visibility: hidden;
        }

        #payment-message {
            color: rgb(105, 115, 134);
            font-size: 16px;
            line-height: 20px;
            padding-top: 12px;
            text-align: center;
        }

        #payment-element .StripeElement {
            border-radius: 4px;
            padding: 12px;
            border: 1px solid rgba(0, 0, 0, 0.1);
            max-height: 44px;
        }

        .card-image {
            max-width: 120px;
            height: auto;
        }
    </style>
@endsection

@section('content')
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title mb-0">Bakiye Yükleme</h4>
                    </div>
                    <div class="card-body">
                        <div class="text-center mb-4">
                            <h5 class="mb-3">Toplam Tutar</h5>
                            <h1 class="display-4 fw-bold text-primary">{{ number_format($amount, 2) }} TL</h1>
                        </div>
                        

                        <form id="payment-form">
                            <div id="payment-element"></div>
                            <button id="submit" class="btn btn-primary w-100 btn-lg">
                                <div id="spinner" class="spinner-border spinner-border-sm" role="status"></div>
                                <span id="button-text">Ödemeyi Tamamla</span>
                            </button>
                            <div id="payment-message" class="mt-3 text-center" style="display: none;"></div>
                        </form>

                        <div class="text-center mt-4">
                            <a href="{{ route('payments.index') }}" class="btn btn-outline-secondary">
                                <i class="ri-arrow-left-line me-1"></i> Geri Dön
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('script')
    <script src="https://js.stripe.com/v3/"></script>
    <script>
        // Stripe başlatma
        const stripe = Stripe('{{ $stripeKey }}');
        let elements;

        initialize();
        checkStatus();

        document.querySelector("#payment-form").addEventListener("submit", handleSubmit);

        async function initialize() {
            const clientSecret = '{{ $clientSecret }}';

            elements = stripe.elements({ clientSecret });

            const paymentElement = elements.create("payment");
            paymentElement.mount("#payment-element");
        }

        async function handleSubmit(e) {
            e.preventDefault();
            setLoading(true);

            const { error } = await stripe.confirmPayment({
                elements,
                confirmParams: {
                    return_url: "{{ route('payments.result') }}",
                },
            });

            if (error.type === "card_error" || error.type === "validation_error") {
                showMessage(error.message);
            } else {
                showMessage("Beklenmeyen bir hata oluştu.");
            }

            setLoading(false);
        }

        // Sayfa yeniden yüklendiğinde ödeme durumunu kontrol et
        async function checkStatus() {
            const clientSecret = '{{ $clientSecret }}';

            if (!clientSecret) {
                return;
            }

            const { paymentIntent } = await stripe.retrievePaymentIntent(clientSecret);

            switch (paymentIntent.status) {
                case "succeeded":
                    showMessage("Ödeme başarılı!");
                    window.location.href = "{{ route('payments.result') }}?payment_intent=" + paymentIntent.id;
                    break;
                case "processing":
                    showMessage("Ödemeniz işleniyor...");
                    break;
                case "requires_payment_method":
                    // showMessage("Ödeme yöntemi seçin");
                    break;
                default:
                    showMessage("Bir şeyler yanlış gitti.");
                    break;
            }
        }

        function showMessage(messageText) {
            const messageContainer = document.querySelector("#payment-message");

            messageContainer.textContent = messageText;
            messageContainer.style.display = "block";

            setTimeout(function () {
                messageContainer.style.display = "none";
                messageContainer.textContent = "";
            }, 6000);
        }

        // Loading UI
        function setLoading(isLoading) {
            if (isLoading) {
                document.querySelector("#submit").disabled = true;
                document.querySelector("#spinner").style.visibility = "visible";
                document.querySelector("#button-text").style.visibility = "hidden";
            } else {
                document.querySelector("#submit").disabled = false;
                document.querySelector("#spinner").style.visibility = "hidden";
                document.querySelector("#button-text").style.visibility = "visible";
            }
        }
    </script>
@endsection