@extends('layouts.master')

@section('title', 'SMS Onay')

@section('css')
    <!-- Mesajlar Modal -->
    <div class="modal fade" id="messagesModal" tabindex="-1" aria-labelledby="messagesModalLabel" aria-hidden="true" style="display: none;">
        <div class="modal-dialog modal-lg" style="margin-top: 100px; margin-bottom: 100px;">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="messagesModalLabel">SMS Mesajları</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body" style="max-height: 60vh; overflow-y: auto;">
                    <div id="messagesList" class="message-list">
                        <div class="text-center">
                            <div class="spinner-border text-primary" role="status">
                                <span class="visually-hidden">Yükleniyor...</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Kapat</button>
                </div>
            </div>
        </div>
    </div>
    <style>
        .sms-activation-table th,
        .sms-activation-table td {
            vertical-align: middle;
        }

        .countdown {
            font-weight: bold;
        }

        .btn-copy {
            cursor: pointer;
            margin-left: 5px;
            color: #6c757d;
        }

        .btn-copy:hover {
            color: #343a40;
        }

        .message-list {
            max-height: 300px;
            overflow-y: auto;
        }

        .message-item {
            border-bottom: 1px solid #eee;
            padding: 10px 0;
        }

        .message-item:last-child {
            border-bottom: none;
        }

        /* Sayfalama stil düzenlemeleri */
        .pagination {
            display: flex;
            justify-content: center;
            align-items: center;
            margin: 20px 0;
            padding: 0;
            list-style: none;
        }

        .pagination li {
            margin: 0 2px;
        }

        .pagination li a,
        .pagination li span {
            display: flex;
            align-items: center;
            justify-content: center;
            min-width: 36px;
            height: 36px;
            padding: 0 10px;
            border-radius: 4px;
            background-color: #fff;
            border: 1px solid #dee2e6;
            color: #007bff;
            text-decoration: none;
            transition: all 0.2s ease;
        }

        .pagination li.active span {
            background-color: #007bff;
            border-color: #007bff;
            color: #fff;
        }

        .pagination li a:hover {
            background-color: #e9ecef;
            border-color: #dee2e6;
            color: #0056b3;
        }

        .pagination li.disabled span {
            color: #6c757d;
            background-color: #fff;
            border-color: #dee2e6;
            cursor: not-allowed;
        }

    </style>
@endsection

@section('content')
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">SMS Onay Numarası Al</h4>
                </div>
                <!-- Bildirim alanı -->
                <div id="notificationArea" class="mt-3" style="display:none;">
                    <div class="alert" id="notificationAlert">
                        <span id="notificationMessage"></span>
                    </div>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="service" class="form-label">Servis Seçin</label>
                                <select class="form-select" id="service" name="service">
                                    <option value="">Servis Seçin</option>
                                    @foreach($services as $code => $name)
                                        <option value="{{ $code }}" data-price="{{ $servicePrices[$code] ?? 20 }}">{{ $name }} ({{ $servicePrices[$code] ?? 20 }} TL)</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="country" class="form-label">Ülke Seçin</label>
                                <select class="form-select" id="country" name="country">
                                    @foreach($countries as $code => $name)
                                        <option value="{{ $code }}" {{ $code == 62 ? 'selected' : '' }}>{{ $name }}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="alert alert-info" id="balanceInfo">
                        <p class="mb-0">
                            <i class="ri-information-line me-2"></i>
                            SMS onay numarası almak için <strong id="requiredAmount">{{ Auth::user()->balance < 20 ? 'yetersiz bakiyeniz var' : '20 TL' }}</strong> ödemeniz gerekecektir.
                            <span id="balanceAfterPayment">{{ Auth::user()->balance < 20 ? 'Lütfen bakiyenizi yükseltin.' : 'İşlem sonrası bakiyeniz: ' . number_format(Auth::user()->balance - 20, 2) . ' TL olacaktır.' }}</span>
                        </p>
                    </div>

                    <div class="text-end">
                        <button type="button" id="getNumberBtn" class="btn btn-primary" {{ Auth::user()->balance < 20 ? 'disabled' : '' }}>
                            <i class="ri-phone-line me-1"></i> SMS Onay Numarası Al
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Aktif Numaralar</h4>
                </div>

                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered sms-activation-table">
                            <thead class="table-light">
                            <tr>
                                <th>KALAN SÜRE</th>
                                <th>SERVİS</th>
                                <th>ÜCRET</th>
                                <th>NUMARA</th>
                                <th>MESAJ</th>
                                <th>İŞLEMLER</th>
                            </tr>
                            </thead>
                            <tbody id="activeActivationsTableBody">
                            @if($activeActivations->isEmpty())
                                <tr>
                                    <td colspan="6" class="text-center">Aktif numara bulunamadı</td>
                                </tr>
                            @else
                                @foreach($activeActivations as $activation)
                                    <tr data-activation-id="{{ $activation->id }}">
                                        <td>
                                            <!-- Aktivasyon süresi dolana kadar geri sayım göster -->
                                            <div class="countdown" data-expires="{{ $activation->expires_at->timestamp }}">
                                                {{ $activation->expires_at->diffForHumans(null, true) }}
                                            </div>
                                        </td>
                                        <td>{{ \App\Models\SmsActivation::getServiceName($activation->service) }}</td>
                                        <td>{{ number_format($activation->price, 2) }} TL</td>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <span class="me-2">{{ $activation->phone_number }}</span>
                                                <i class="ri-file-copy-line btn-copy" data-clipboard-text="{{ $activation->phone_number }}" data-bs-toggle="tooltip" title="Kopyala"></i>
                                            </div>
                                        </td>
                                        <td>
                                            @if($activation->status === 'completed' || $activation->status === 'waiting_with_message' || !empty($activation->code))
                                                <div class="d-flex align-items-center">
                                                    <div class="me-2">
                                                        <!-- SMS'i satır atlayarak göster -->
                                                        <div style="white-space: pre-line; max-width: 300px;">{{ $activation->code }}</div>
                                                    </div>
                                                    <i class="ri-file-copy-line btn-copy" data-clipboard-text="{{ $activation->code }}" data-bs-toggle="tooltip" title="Kopyala"></i>
                                                </div>
                                            @else
                                                <div class="message-status">Mesaj bekleniyor...</div>
                                            @endif
                                        </td>
                                        <td>
                                            <!-- İptal butonu - ilk 2 dakika + 5 saniye boyunca devre dışı -->
                                            @if($activation->status === 'waiting' || $activation->status === 'waiting_with_message')
                                                <button type="button" class="btn btn-sm btn-danger cancel-btn" data-id="{{ $activation->id }}"
                                                        {{ $activation->getMinutesSinceCreation() < 2.08 ? 'disabled' : '' }}
                                                        data-created="{{ $activation->created_at->timestamp }}">
                                                    {{ $activation->getMinutesSinceCreation() < 2.08 ? '('.(2-$activation->getMinutesSinceCreation()).' dk)' : '' }}
                                                    İptal Et
                                                </button>
                                            @endif

                                            <!-- Tamamlanmış numaralar için "Tekrar SMS İste" butonu -->
                                            @if(($activation->status === 'completed' || $activation->status === 'waiting_with_message') && !$activation->isExpired())
                                                <button type="button" class="btn btn-sm btn-warning request-sms-btn me-1" data-id="{{ $activation->id }}">
                                                    Tekrar SMS İste
                                                </button>
                                            @endif

                                            <button type="button" class="btn btn-sm btn-info show-messages-btn" data-id="{{ $activation->id }}" data-bs-toggle="modal" data-bs-target="#messagesModal">
                                                Mesajları Göster
                                            </button>
                                        </td>
                                    </tr>
                                @endforeach
                            @endif
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Arşiv Numaralar</h4>
                </div>

                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered sms-activation-table">
                            <thead class="table-light">
                            <tr>
                                <th>TARİH</th>
                                <th>SERVİS</th>
                                <th>ÜCRET</th>
                                <th>NUMARA</th>
                                <th>DURUM</th>
                                <th>İŞLEMLER</th>
                            </tr>
                            </thead>
                            <tbody>
                            @if($archiveActivations->isEmpty())
                                <tr>
                                    <td colspan="6" class="text-center">Arşiv numara bulunamadı</td>
                                </tr>
                            @else
                                @foreach($archiveActivations as $activation)
                                    <tr>
                                        <td>{{ $activation->created_at->format('d.m.Y H:i') }}</td>
                                        <td>{{ \App\Models\SmsActivation::getServiceName($activation->service) }}</td>
                                        <td>{{ number_format($activation->price, 2) }} TL</td>
                                        <td>{{ $activation->phone_number }}</td>
                                        <td>
                                            @if($activation->status === 'completed' || $activation->status === 'waiting_with_message')
                                                <div class="badge bg-success">Tamamlandı</div>
                                            @elseif($activation->status === 'canceled')
                                                <div class="badge bg-danger">İptal Edildi</div>
                                            @elseif($activation->status === 'expired')
                                                <div class="badge bg-danger">İptal Edildi</div>
                                            @endif
                                        </td>
                                        <td>
                                            <button type="button" class="btn btn-sm btn-info show-messages-btn" data-id="{{ $activation->id }}" data-bs-toggle="modal" data-bs-target="#messagesModal">
                                                Mesajları Göster
                                            </button>
                                        </td>
                                    </tr>
                                @endforeach
                            @endif
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Pagination -->
    
        <div class="d-flex justify-content-center mt-4">
            {{ $archiveActivations->links('vendor.pagination.custom') }}
        </div>

        <!-- Sayfalama için CSS -->
        <style>
            .pagination {
                display: flex;
                justify-content: center;
                padding-left: 0;
                list-style: none;
                border-radius: 0.25rem;
            }
            .pagination .page-item.active .page-link {
                background-color: #007bff;
                border-color: #007bff;
            }
            .pagination .page-link {
                padding: 0.5rem 0.75rem;
                margin-left: -1px;
                line-height: 1.25;
                color: #007bff;
                background-color: #fff;
                border: 1px solid #dee2e6;
            }
            .pagination .page-link:hover {
                color: #0056b3;
                background-color: #e9ecef;
                border-color: #dee2e6;
            }
            .pagination .page-item:first-child .page-link {
                margin-left: 0;
                border-top-left-radius: 0.25rem;
                border-bottom-left-radius: 0.25rem;
            }
            .pagination .page-item:last-child .page-link {
                border-top-right-radius: 0.25rem;
                border-bottom-right-radius: 0.25rem;
            }
        </style>


@endsection

@section('script')
    <script src="https://cdnjs.cloudflare.com/ajax/libs/clipboard.js/2.0.8/clipboard.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Clipboard.js başlat
            new ClipboardJS('.btn-copy');

            // Tooltips başlat
            var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
            var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
                return new bootstrap.Tooltip(tooltipTriggerEl)
            });

            // Normal clipboard instance (mesaj kopyalama için)
            new ClipboardJS('.btn-copy');

            // Tooltips başlat
            var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
            var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
                return new bootstrap.Tooltip(tooltipTriggerEl)
            });

            // Bildirim gösterme fonksiyonu
            function showNotification(message, type = 'info', timeout = 0) {
                const notificationArea = document.getElementById('notificationArea');
                const notificationAlert = document.getElementById('notificationAlert');
                const notificationMessage = document.getElementById('notificationMessage');

                // Alert tipini ayarla
                notificationAlert.className = 'alert';
                if (type === 'success') {
                    notificationAlert.classList.add('alert-success');
                } else if (type === 'error') {
                    notificationAlert.classList.add('alert-danger');
                } else if (type === 'warning') {
                    notificationAlert.classList.add('alert-warning');
                } else {
                    notificationAlert.classList.add('alert-info');
                }

                // Mesajı ayarla ve göster
                notificationMessage.innerHTML = message;
                notificationArea.style.display = 'block';

                // Otomatik kapanma süresi varsa ayarla
                if (timeout > 0) {
                    setTimeout(() => {
                        notificationArea.style.display = 'none';
                    }, timeout);
                }
            }

            // Bildirimi kapat
            function hideNotification() {
                document.getElementById('notificationArea').style.display = 'none';
            }

            // Servis değiştiğinde fiyat bilgisini güncelle
            document.getElementById('service').addEventListener('change', function() {
                if (this.value) {
                    const selectedOption = this.options[this.selectedIndex];
                    const price = parseFloat(selectedOption.getAttribute('data-price') || 20);
                    const priceText = price.toFixed(2) + ' TL';

                    const userBalance = {{ Auth::user()->balance }};
                    const requiredAmount = document.getElementById('requiredAmount');
                    const balanceAfterPayment = document.getElementById('balanceAfterPayment');
                    const getNumberBtn = document.getElementById('getNumberBtn');

                    requiredAmount.textContent = priceText;

                    if (userBalance < price) {
                        balanceAfterPayment.textContent = 'Yetersiz bakiyeniz var. Lütfen bakiyenizi yükseltin.';
                        getNumberBtn.disabled = true;
                    } else {
                        balanceAfterPayment.textContent = 'İşlem sonrası bakiyeniz: ' + (userBalance - price).toFixed(2) + ' TL olacaktır.';
                        getNumberBtn.disabled = false;
                    }
                }
            });

            // Sayfa yüklendiğinde AJAX başlatıldıktan sonra tüm aktivasyonlar için otomatik kontrol başlat
            setTimeout(() => {
                // Her 30 saniyede bir, tüm aktivasyonları gözden geçir ve süreleri uzatılmış olanları kontrol et
                setInterval(() => {
                    document.querySelectorAll('#activeActivationsTableBody tr[data-activation-id]').forEach(row => {
                        const countdownEl = row.querySelector('.countdown');
                        if (countdownEl && !countdownEl.classList.contains('text-danger')) {
                            // Süresi dolmamış aktivasyonlar için
                            const activationId = row.getAttribute('data-activation-id');
                            if (activationId) {
                                // İstek zamanlamasını her aktivasyon için biraz kaydır
                                setTimeout(() => {
                                    updateActivationStatus(activationId);
                                }, Math.random() * 5000); // 0-5 saniye arası rastgele bekle
                            }
                        }
                    });
                }, 30000); // 30 saniyede bir kontrol et
            }, 5000); // Sayfa yüklendikten 5 saniye sonra başlat

            // Numara alma butonu
            document.getElementById('getNumberBtn').addEventListener('click', function() {
                const service = document.getElementById('service').value;
                const country = document.getElementById('country').value;

                if (!service) {
                    showNotification('Lütfen bir servis seçin', 'warning');
                    return;
                }

                this.disabled = true;
                this.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Numara alınıyor...';

                // İşleme başladığını bildir
                showNotification('Numara alınıyor, lütfen bekleyin. Bu işlem biraz zaman alabilir...', 'info');

                fetch('{{ route('sms-activation.get-number') }}', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}',
                        'Accept': 'application/json',
                    },
                    body: JSON.stringify({
                        service: service,
                        country: country
                    })
                })
                    .then(response => response.json())
                    .then(data => {
                        this.disabled = false;
                        this.innerHTML = '<i class="ri-phone-line me-1"></i> SMS Onay Numarası Al';

                        if (data.status === 'success') {
                            // Başarılı mesajı göster
                            showNotification(data.message || 'Numara başarıyla alındı.', 'success', 3000);

                            // Sayfayı yenile
                            setTimeout(() => {
                                window.location.reload();
                            }, 1500);
                        } else if (data.status === 'processing') {
                            // İşlem devam ediyor mesajı
                            showNotification(data.message, 'info');
                        } else {
                            // Hata mesajı göster
                            showNotification(data.message || 'Numara alınırken bir hata oluştu.', 'error');
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        this.disabled = false;
                        this.innerHTML = '<i class="ri-phone-line me-1"></i> SMS Onay Numarası Al';
                        showNotification('Bir hata oluştu. Lütfen tekrar deneyin.', 'error');
                    });
            });

            // İptal butonları
            document.querySelectorAll('.cancel-btn').forEach(button => {
                button.addEventListener('click', function() {
                    const activationId = this.getAttribute('data-id');

                    if (confirm('Bu aktivasyonu iptal etmek istediğinizden emin misiniz? Bakiyeniz iade edilecektir.')) {
                        this.disabled = true;
                        this.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>';

                        // İşleme başladığını bildir
                        showNotification('İptal işlemi yapılıyor...', 'info');

                        fetch(`{{ url('sms-activation/cancel') }}/${activationId}`, {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json',
                                'X-CSRF-TOKEN': '{{ csrf_token() }}',
                                'Accept': 'application/json',
                            }
                        })
                            .then(response => response.json())
                            .then(data => {
                                if (data.status === 'success') {
                                    showNotification(data.message, 'success', 3000);
                                    // Sayfayı yenile
                                    setTimeout(() => {
                                        window.location.reload();
                                    }, 1500);
                                } else {
                                    showNotification(data.message || 'İptal işlemi başarısız', 'error');
                                    this.disabled = false;
                                    this.innerHTML = 'İptal Et';
                                }
                            })
                            .catch(error => {
                                console.error('Error:', error);
                                showNotification('Bir hata oluştu. Lütfen tekrar deneyin.', 'error');
                                this.disabled = false;
                                this.innerHTML = 'İptal Et';
                            });
                    }
                });
            });

            // Tekrar SMS iste butonları
            document.querySelectorAll('.request-sms-btn').forEach(button => {
                button.addEventListener('click', function() {
                    const activationId = this.getAttribute('data-id');

                    this.disabled = true;
                    this.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>';

                    // İşleme başladığını bildir
                    showNotification('Yeni SMS isteği gönderiliyor...', 'info');

                    fetch(`{{ url('sms-activation/request-new-sms') }}/${activationId}`, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': '{{ csrf_token() }}',
                            'Accept': 'application/json',
                        }
                    })
                        .then(response => response.json())
                        .then(data => {
                            this.disabled = false;
                            this.innerHTML = 'Tekrar SMS İste';

                            if (data.status === 'success') {
                                showNotification(data.message || 'Yeni SMS isteği gönderildi. Lütfen bekleyin.', 'success');
                            } else {
                                showNotification(data.message || 'Yeni SMS isteği gönderilirken bir hata oluştu', 'error');
                            }
                        })
                        .catch(error => {
                            console.error('Error:', error);
                            this.disabled = false;
                            this.innerHTML = 'Tekrar SMS İste';
                            showNotification('Bir hata oluştu. Lütfen tekrar deneyin.', 'error');
                        });
                });
            });

            // Mesajları göster butonları
            document.querySelectorAll('.show-messages-btn').forEach(button => {
                button.addEventListener('click', function() {
                    const activationId = this.getAttribute('data-id');
                    loadMessages(activationId);
                });
            });

            // Aktivasyon durumunu güncelle
            function updateActivationStatus(activationId) {
                const row = document.querySelector(`tr[data-activation-id="${activationId}"]`);
                if (!row) return;

                const messageStatus = row.querySelector('.message-status');
                const countdownEl = row.querySelector('.countdown');
                const cancelBtn = row.querySelector('.cancel-btn');

                fetch(`{{ url('sms-activation/check-status') }}/${activationId}`)
                    .then(response => response.json())
                    .then(data => {
                        if (data.status === 'success') {
                            // SMS kodu alındı
                            if (messageStatus) {
                                // Gelen mesajı işle ve formatla
                                let displayCode = data.code;

                                // NTTGame mesajlarını frontend'de de kontrol et ve formatla
                                if (typeof displayCode === 'string' && displayCode.includes('NTTGame')) {
                                    const regex = /OTP ID:(.*?)Auth Code:(\d+)/s;
                                    const matches = displayCode.match(regex);
                                    if (matches && matches.length >= 3) {
                                        const otpId = matches[1].trim();
                                        const authCode = matches[2].trim();
                                        displayCode = `OTP ID:${otpId} Auth Code:${authCode}`;
                                    }
                                }

                                messageStatus.innerHTML = `
                                <div class="d-flex align-items-center">
                                    <div class="me-2">
                                        <div style="white-space: pre-line; max-width: 300px;">${displayCode}</div>
                                    </div>
                                    <i class="ri-file-copy-line btn-copy" data-clipboard-text="${displayCode}" data-bs-toggle="tooltip" title="Kopyala"></i>
                                </div>
                                `;
                            }

                            // Yeni mesaj geldiğinde bildirim göster
                            if (data.new_messages) {
                                showNotification('Yeni SMS mesajı alındı!', 'success', 3000);
                            }

                            // Tekrar SMS iste butonunu ekle/güncelle
                            let requestSmsBtn = row.querySelector('.request-sms-btn');
                            if (!requestSmsBtn && data.remaining_minutes > 0) {
                                const actionsCell = row.querySelector('td:last-child');
                                requestSmsBtn = document.createElement('button');
                                requestSmsBtn.className = 'btn btn-sm btn-warning request-sms-btn me-1';
                                requestSmsBtn.setAttribute('data-id', activationId);
                                requestSmsBtn.innerHTML = 'Tekrar SMS İste';

                                // Event listener ekle
                                requestSmsBtn.addEventListener('click', function() {
                                    const activationId = this.getAttribute('data-id');

                                    this.disabled = true;
                                    this.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>';

                                    // İşleme başladığını bildir
                                    showNotification('Yeni SMS isteği gönderiliyor...', 'info');

                                    fetch(`{{ url('sms-activation/request-new-sms') }}/${activationId}`, {
                                        method: 'POST',
                                        headers: {
                                            'Content-Type': 'application/json',
                                            'X-CSRF-TOKEN': '{{ csrf_token() }}',
                                            'Accept': 'application/json',
                                        }
                                    })
                                        .then(response => response.json())
                                        .then(data => {
                                            this.disabled = false;
                                            this.innerHTML = 'Tekrar SMS İste';

                                            if (data.status === 'success') {
                                                showNotification(data.message || 'Yeni SMS isteği gönderildi. Lütfen bekleyin.', 'success');

                                                // Burada önemli değişiklik: Statusu waiting'e döndürdük,
                                                // bu nedenle tekrar SMS kontrolüne başlamalıyız
                                                updateActivationStatus(activationId);
                                            } else {
                                                showNotification(data.message || 'Yeni SMS isteği gönderilirken bir hata oluştu', 'error');
                                            }
                                        })
                                        .catch(error => {
                                            console.error('Error:', error);
                                            this.disabled = false;
                                            this.innerHTML = 'Tekrar SMS İste';
                                            showNotification('Bir hata oluştu. Lütfen tekrar deneyin.', 'error');
                                        });
                                });

                                // Ekle
                                actionsCell.insertBefore(requestSmsBtn, actionsCell.firstChild);
                            }

                            // İptal butonunu kaldır
                            if (cancelBtn) cancelBtn.remove();

                            // Clipboard ve tooltip yeniden başlat
                            new ClipboardJS('.btn-copy');
                            var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
                            var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
                                return new bootstrap.Tooltip(tooltipTriggerEl)
                            });

                            // Otomatik olarak kontrole devam etme
                            if (data.auto_check) {
                                setTimeout(() => {
                                    updateActivationStatus(activationId);
                                }, 10000); // 10 saniyede bir kontrol et
                            }
                        } else if (data.status === 'waiting') {
                            // Hala bekleniyor, ancak önceki bir mesaj varsa göster
                            if (data.has_previous_message && data.last_code && messageStatus) {
                                // Gelen mesajı işle ve formatla
                                let displayCode = data.last_code;

                                // NTTGame mesajlarını frontend'de de kontrol et ve formatla
                                if (typeof displayCode === 'string' && displayCode.includes('NTTGame')) {
                                    const regex = /OTP ID:(.*?)Auth Code:(\d+)/s;
                                    const matches = displayCode.match(regex);
                                    if (matches && matches.length >= 3) {
                                        const otpId = matches[1].trim();
                                        const authCode = matches[2].trim();
                                        displayCode = `OTP ID:${otpId} Auth Code:${authCode}`;
                                    }
                                }

                                messageStatus.innerHTML = `
                                <div class="d-flex align-items-center">
                                    <div class="me-2">
                                        <div style="white-space: pre-line; max-width: 300px;">${displayCode}</div>
                                    </div>
                                    <i class="ri-file-copy-line btn-copy" data-clipboard-text="${displayCode}" data-bs-toggle="tooltip" title="Kopyala"></i>
                                </div>
                                `;

                                // Clipboard ve tooltip yeniden başlat
                                new ClipboardJS('.btn-copy');
                                var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
                                var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
                                    return new bootstrap.Tooltip(tooltipTriggerEl)
                                });
                            }

                            // 10 saniye sonra tekrar kontrol et
                            if (data.auto_check) {
                                setTimeout(() => {
                                    updateActivationStatus(activationId);
                                }, 10000); // 10 saniyede bir kontrol et
                            }
                        } else if (data.status === 'error') {
                            // Hata durumunda kullanıcıyı bilgilendir
                            if (messageStatus) {
                                messageStatus.innerHTML = `<div class="text-danger">${data.message || 'Bir hata oluştu'}</div>`;
                            }
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        // Hata durumunda 10 saniye sonra tekrar dene
                        setTimeout(() => {
                            updateActivationStatus(activationId);
                        }, 10000);
                    });
            }

            // İptal butonlarını güncelleyen fonksiyon
            function updateCancelButtons() {
                document.querySelectorAll('.cancel-btn').forEach(button => {
                    if (button.hasAttribute('disabled')) {
                        const createdTimestamp = parseInt(button.getAttribute('data-created'));
                        const createdDate = new Date(createdTimestamp * 1000);
                        const now = new Date();

                        // Dakika farkını hesapla (milisaniye -> dakika)
                        const minutesDiff = (now - createdDate) / (1000 * 60);

                        // 2 dakika 5 saniye (2.08 dakika) geçti mi kontrol et
                        if (minutesDiff >= 2.08) {
                            // Butonu aktifleştir ve içindeki metni güncelle
                            button.removeAttribute('disabled');
                            button.innerHTML = 'İptal Et';
                        } else {
                            // Kalan süreyi güncelle
                            const remainingMinutes = (2.08 - minutesDiff).toFixed(1);
                            button.innerHTML = `(${remainingMinutes} dk) İptal Et`;
                        }
                    }
                });
            }

            // Her saniye kontrol et
            setInterval(updateCancelButtons, 1000);

            // Sayfa yüklendiğinde başlat
            updateCancelButtons();

            // Sayfa yüklendiğinde servis seçili ise fiyat bilgilerini güncelle
            if (document.getElementById('service').value) {
                const serviceSelect = document.getElementById('service');
                const selectedOption = serviceSelect.options[serviceSelect.selectedIndex];
                if (selectedOption.value) {
                    const price = parseFloat(selectedOption.getAttribute('data-price') || 20);
                    document.getElementById('requiredAmount').textContent = price.toFixed(2) + ' TL';

                    const userBalance = {{ Auth::user()->balance }};
                    if (userBalance < price) {
                        document.getElementById('balanceAfterPayment').textContent = 'Yetersiz bakiyeniz var. Lütfen bakiyenizi yükseltin.';
                        document.getElementById('getNumberBtn').disabled = true;
                    } else {
                        document.getElementById('balanceAfterPayment').textContent = 'İşlem sonrası bakiyeniz: ' + (userBalance - price).toFixed(2) + ' TL olacaktır.';
                    }
                }
            }

            // Geri sayım
            function startCountdown(countdownElement) {
                if (!countdownElement) return;

                const expiresTimestamp = parseInt(countdownElement.getAttribute('data-expires'));
                const expiresDate = new Date(expiresTimestamp * 1000);

                function updateCountdown() {
                    const now = new Date();
                    const diff = expiresDate - now;

                    if (diff <= 0) {
                        countdownElement.innerHTML = 'Süresi Doldu';
                        countdownElement.classList.add('text-danger');

                        // Sayfayı yenile (opsiyonel)
                        // window.location.reload();
                        return;
                    }

                    const minutes = Math.floor(diff / 60000);
                    const seconds = Math.floor((diff % 60000) / 1000);

                    countdownElement.innerHTML = `${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;

                    // Her saniye güncelle
                    setTimeout(updateCountdown, 1000);
                }

                updateCountdown();
            }

            // Sayfa yüklendiğinde tüm geri sayımları başlat
            document.querySelectorAll('.countdown').forEach(countdown => {
                startCountdown(countdown);
            });

            // Mesajları yükle
            function loadMessages(activationId) {
                const messagesList = document.getElementById('messagesList');
                messagesList.innerHTML = `
                <div class="text-center">
                    <div class="spinner-border text-primary" role="status">
                        <span class="visually-hidden">Yükleniyor...</span>
                    </div>
                </div>
            `;

                fetch(`{{ url('sms-activation/get-messages') }}/${activationId}`)
                    .then(response => response.json())
                    .then(data => {
                        if (data.status === 'success') {
                            if (data.messages.length === 0) {
                                messagesList.innerHTML = `
                                <div class="text-center py-3">
                                    <p>Bu aktivasyon için henüz mesaj bulunmuyor.</p>
                                </div>
                            `;
                            } else {
                                let html = '';
                                data.messages.forEach(message => {
                                    const date = new Date(message.received_at);
                                    html += `
                                    <div class="message-item">
                                        <div class="d-flex justify-content-between mb-2">
                                            <small class="text-muted">${date.toLocaleString('tr-TR')}</small>
                                            ${message.phone_from ? `<small class="text-muted">Gönderen: ${message.phone_from}</small>` : ''}
                                        </div>
                                        <div class="message-content">
                                            <p class="mb-0">${message.text}</p>
                                        </div>
                                    </div>
                                `;
                                });
                                messagesList.innerHTML = html;
                            }
                        } else {
                            messagesList.innerHTML = `
                            <div class="text-center py-3">
                                <p>Mesajlar yüklenirken bir hata oluştu.</p>
                            </div>
                        `;
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        messagesList.innerHTML = `
                        <div class="text-center py-3">
                            <p>Mesajlar yüklenirken bir hata oluştu.</p>
                        </div>
                    `;
                    });
            }
        });
    </script>
@endsection