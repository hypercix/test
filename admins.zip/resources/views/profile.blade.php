@extends('layouts.master')

@section('title', 'Profilim')

@section('content')
    <div class="position-relative mx-n4 mt-n4">
        <div class="profile-wid-bg profile-setting-img">
            <img src="{{ URL::asset('build/images/profile-bg.jpg') }}" class="profile-wid-img" alt="">
        </div>
    </div>

    <div class="row">
        <div class="col-xxl-3">
            <div class="card mt-n5">
                <div class="card-body p-4 text-center">
                    <div class="profile-user position-relative d-inline-block mx-auto mb-3">
                        <img src="@if(Auth::user()->avatar) {{ asset('images/' . Auth::user()->avatar) }} @else {{ asset('build/images/users/avatar-1.jpg') }} @endif"
                             class="rounded-circle avatar-xl img-thumbnail user-profile-image shadow"
                             alt="Kullanıcı">
                    </div>
                    <h5 class="fs-16 mb-1">{{ Auth::user()->name }}</h5>
                    <p class="text-muted mb-0">Müşteri</p>
                    <p class="mt-2 mb-0"><strong>Bakiye:</strong> {{ number_format(Auth::user()->balance, 2) }} ₺</p>
                    <p class="text-muted"><strong>Eposta:</strong> {{ Auth::user()->email }}</p>
                </div>
            </div>
        </div>

        <div class="col-xxl-9">
            <div class="card mt-xxl-n5">
                <div class="card-header border-bottom-0">
                    <ul class="nav nav-tabs-custom rounded card-header-tabs" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" data-bs-toggle="tab" href="#changePassword" role="tab">
                                <i class="ri-lock-password-line me-1"></i> Şifre Değiştir
                            </a>
                        </li>
                    </ul>
                </div>

                <div class="card-body p-4">
                    <div class="tab-content">
                        <div class="tab-pane active" id="changePassword" role="tabpanel">
                            <form method="POST" action="{{ route('profile.changePassword') }}">
                                @csrf
                                @if (session('success'))
                                    <div class="alert alert-success">{{ session('success') }}</div>
                                @elseif(session('error'))
                                    <div class="alert alert-danger">{{ session('error') }}</div>
                                @endif
                                <div class="row g-2">
                                    <div class="col-lg-4">
                                        <div>
                                            <label for="current_password" class="form-label">Mevcut Şifre</label>
                                            <input type="password" name="current_password" class="form-control" required>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div>
                                            <label for="new_password" class="form-label">Yeni Şifre</label>
                                            <input type="password" name="new_password" class="form-control" required>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div>
                                            <label for="new_password_confirmation" class="form-label">Yeni Şifre (Tekrar)</label>
                                            <input type="password" name="new_password_confirmation" class="form-control" required>
                                        </div>
                                    </div>
                                    <div class="col-lg-12 mt-3 text-end">
                                        <button type="submit" class="btn btn-success">Şifreyi Güncelle</button>
                                    </div>
                                </div>
                            </form>
                        </div>

                    </div><!-- end tab-content -->
                </div>
            </div>
        </div>
    </div>
@endsection
