<?php

namespace App\Services;

use GuzzleHttp\Client;
use Illuminate\Support\Facades\Log;
use Carbon\Carbon;

class SmsActivateService
{
    protected $client;
    protected $apiKey;
    protected $baseUrl;

    public function __construct()
    {
        $this->client = new Client();
        $this->apiKey = config('services.sms_activate.api_key');
        $this->baseUrl = config('services.sms_activate.base_url', 'https://api.sms-activate.org/stubs/handler_api.php');
    }

    /**
     * Get account balance
     *
     * @return mixed
     */
    public function getBalance()
    {
        try {
            $response = $this->makeRequest('getBalance');

            // Response format: ACCESS_BALANCE:10.00
            if (strpos($response, 'ACCESS_BALANCE') !== false) {
                return (float) explode(':', $response)[1];
            }

            return false;
        } catch (\Exception $e) {
            Log::error('SMS-Activate getBalance error: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * NTTGame (zy) servisi için özel numara alma stratejisi
     * Önce ucuz numaraları tüketir, sonra kaliteli numara verir
     *
     * @param int $country Ülke kodu (default 62 for Turkey)
     * @return array|false
     */
    public function getNttGameNumber($country = 62)
    {
        try {
            Log::info('NTTGame özel stratejisi başlatılıyor...');

            // 1. Adım: Önce ucuz numaraları tüket (maxPrice=0.1)
            $consumedCount = 0;
            $reservedIds = [];

            // 30 tane ucuz numara rezerve etmeye çalış
            for ($i = 0; $i < 30; $i++) {
                $cheapResult = $this->makeRequest('getNumber', [
                    'service' => 'zy',
                    'country' => $country,
                    'maxPrice' => 0.1
                ]);

                // Eğer numara rezerve edilirse, ID'sini kaydet
                if (strpos($cheapResult, 'ACCESS_NUMBER') !== false) {
                    $parts = explode(':', $cheapResult);
                    $phoneId = $parts[1];
                    $reservedIds[] = $phoneId;
                    $consumedCount++;

                    Log::info("Ucuz numara rezerve edildi: ID {$phoneId} (Toplam: {$consumedCount})");

                    // Hızlı ardışık istekler için küçük bir bekleme
                    usleep(200000); // 0.2 saniye
                } else {
                    // Ucuz numara kalmadıysa döngüden çık
                    if ($cheapResult === 'NO_NUMBERS') {
                        Log::info("Ucuz numara kalmadı, döngüden çıkılıyor. Tüketilen: {$consumedCount}");
                        break;
                    }
                }
            }

            // 2. Adım: Tüm rezerve edilmiş numaraları iptal et
            foreach ($reservedIds as $id) {
                $this->cancelActivation($id);
                // API üzerinde aşırı yük oluşturmamak için kısa bir bekleme
                usleep(100000); // 0.1 saniye
            }

            Log::info("Toplam {$consumedCount} ucuz numara tüketildi ve iptal edildi");

            // 3. Adım: Kaliteli numara al (maxPrice=0.2) - birkaç kez dene
            Log::info("Kaliteli numara alınıyor (maxPrice=0.2)...");

            // Maksimum 5 kez deneyelim
            $maxRetries = 5;
            $currentRetry = 0;
            $result = null;

            while ($currentRetry < $maxRetries) {
                $response = $this->makeRequest('getNumber', [
                    'service' => 'zy',
                    'country' => $country,
                    'maxPrice' => 0.2
                ]);

                // Kaliteli numara başarıyla alındı mı kontrol et
                if (strpos($response, 'ACCESS_NUMBER') !== false) {
                    $parts = explode(':', $response);
                    $result = [
                        'status' => 'success',
                        'phone_id' => $parts[1],
                        'phone_number' => $parts[2],
                    ];
                    Log::info("Kaliteli numara başarıyla alındı: " . $result['phone_number']);
                    break; // Başarılı olduk, döngüden çık
                }

                // NO_NUMBERS hatası aldıysak, tekrar dene
                if ($response === 'NO_NUMBERS') {
                    $currentRetry++;
                    Log::warning("Kaliteli numara alınamadı (NO_NUMBERS), tekrar deneniyor... ({$currentRetry}/{$maxRetries})");
                    // Kısa bir bekleme
                    sleep(1);
                    continue;
                }

                // Başka bir hata aldıysak, döngüden çık
                Log::error("Kaliteli numara alınamadı, hata: " . $response);
                break;
            }

            // Eğer numara alabildiyse, sonucu döndür
            if ($result !== null) {
                return $result;
            }

            // Kaliteli numara alınamadıysa kullanıcı dostu hata mesajı döndür
            return [
                'status' => 'error',
                'message' => 'Şu anda NTTGame servisi için numara bulunmuyor. Lütfen daha sonra tekrar deneyin.',
                'original_error' => $response ?? 'NO_NUMBERS_AFTER_RETRIES'
            ];

        } catch (\Exception $e) {
            Log::error('NTTGame numara alma hatası: ' . $e->getMessage());
            return [
                'status' => 'error',
                'message' => 'Numara alınırken bir hata oluştu. Lütfen daha sonra tekrar deneyin.',
                'original_error' => $e->getMessage()
            ];
        }
    }

    /**
     * Get number for verification
     *
     * @param string $service Service code (e.g. 'tg' for Telegram)
     * @param int $country Country code (default 62 for Turkey)
     * @return array|false
     */
    /**
     * Get number for verification
     *
     * @param string $service Service code (e.g. 'tg' for Telegram)
     * @param int $country Country code (default 62 for Turkey)
     * @return array|false
     */
    public function getNumber($service, $country = 62)
    {
        try {
            // NTTGame (zy) servisi için özel strateji kullan
            if ($service === 'zy') {
                return $this->getNttGameNumber($country);
            }

            // Diğer servisler için - maksimum 3 kez dene
            $maxRetries = 3;
            $currentRetry = 0;

            while ($currentRetry < $maxRetries) {
                // Normal numara alma işlemi
                $response = $this->makeRequest('getNumber', [
                    'service' => $service,
                    'country' => $country,
                ]);

                // Response format: ACCESS_NUMBER:phoneId:phoneNumber
                if (strpos($response, 'ACCESS_NUMBER') !== false) {
                    $parts = explode(':', $response);
                    return [
                        'status' => 'success',
                        'phone_id' => $parts[1],
                        'phone_number' => $parts[2],
                    ];
                }

                // NO_NUMBERS hatası aldıysak, tekrar dene
                if ($response === 'NO_NUMBERS') {
                    $currentRetry++;
                    Log::warning("Numara alınamadı (NO_NUMBERS), tekrar deneniyor... ({$currentRetry}/{$maxRetries})");
                    // Kısa bir bekleme
                    sleep(1);
                    continue;
                }

                // Başka bir hata aldıysak, döngüden çık
                break;
            }

            // Hata mesajlarını kullanıcı dostu hale getir
            $friendlyMessage = $this->getFriendlyErrorMessage($response, $service);

            return [
                'status' => 'error',
                'message' => $friendlyMessage,
                'original_error' => $response
            ];
        } catch (\Exception $e) {
            Log::error('SMS-Activate getNumber error: ' . $e->getMessage());
            return [
                'status' => 'error',
                'message' => 'Numara alınırken bir hata oluştu. Lütfen daha sonra tekrar deneyin.',
                'original_error' => $e->getMessage()
            ];
        }
    }

    /**
     * Kullanıcı dostu hata mesajları döndürür
     *
     * @param string $errorCode API hata kodu
     * @param string $service Servis kodu
     * @return string
     */
    protected function getFriendlyErrorMessage($errorCode, $service)
    {
        $serviceName = $this->getServiceName($service);

        switch ($errorCode) {
            case 'NO_NUMBERS':
                return "Şu anda {$serviceName} servisi için numara bulunmuyor. Lütfen daha sonra tekrar deneyin.";
            case 'NO_BALANCE':
                return "API hesabınızda yeterli bakiye bulunmuyor. Lütfen yönetici ile iletişime geçin.";
            case 'BAD_KEY':
                return "API anahtarı geçersiz. Lütfen yönetici ile iletişime geçin.";
            case 'BAD_ACTION':
                return "Geçersiz API isteği. Lütfen yönetici ile iletişime geçin.";
            case 'BAD_SERVICE':
                return "Geçersiz servis kodu. Lütfen başka bir servis seçin.";
            case 'API_KEY_NOT_VALID':
                return "API anahtarı geçersiz. Lütfen yönetici ile iletişime geçin.";
            case 'ERROR_SQL':
                return "SMS-Activate servisinde teknik bir sorun oluştu. Lütfen daha sonra tekrar deneyin.";
            default:
                return "Numara alınırken bir hata oluştu. Lütfen daha sonra tekrar deneyin.";
        }
    }

    /**
     * Servis adını almak için helper fonksiyon
     *
     * @param string $serviceCode
     * @return string
     */
    protected function getServiceName($serviceCode)
    {
        $services = [
            'tg' => 'Telegram',
            'wa' => 'WhatsApp',
            'ig' => 'Instagram',
            'fb' => 'Facebook',
            'go' => 'Google',
            'tw' => 'Twitter',
            'vk' => 'VK',
            'ok' => 'OK',
            'vb' => 'Viber',
            'zy' => 'NTTGame',
            'ot' => 'Diğer',
        ];

        return $services[$serviceCode] ?? $serviceCode;
    }

    /**
     * Set activation status
     *
     * @param int $id Phone ID
     * @param int $status Status code (1=ready, 3=request another SMS, 6=confirm, 8=cancel)
     * @return bool|string
     */
    public function setStatus($id, $status)
    {
        try {
            $response = $this->makeRequest('setStatus', [
                'id' => $id,
                'status' => $status,
            ]);

            // Possible responses: ACCESS_READY, ACCESS_RETRY_GET, ACCESS_ACTIVATION, ACCESS_CANCEL
            if (in_array($response, ['ACCESS_READY', 'ACCESS_RETRY_GET', 'ACCESS_ACTIVATION', 'ACCESS_CANCEL'])) {
                return $response;
            }

            Log::warning('SMS-Activate setStatus error: ' . $response);
            return $response;
        } catch (\Exception $e) {
            Log::error('SMS-Activate setStatus error: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Request another SMS (mark as status 3)
     *
     * @param int $id Phone ID
     * @return bool|string
     */
    public function requestAnotherSms($id)
    {
        return $this->setStatus($id, 3);
    }

    /**
     * Get activation status and SMS code
     *
     * @param int $id Phone ID
     * @return array
     */
    /**
     * Get activation status and SMS code
     *
     * @param int $id Phone ID
     * @return array
     */
    /**
     * Get activation status and SMS code
     *
     * @param int $id Phone ID
     * @return array
     */
    public function getActivationStatus($id)
    {
        try {
            $response = $this->makeRequest('getStatus', [
                'id' => $id,
            ]);

            // Response format for successful SMS receive: STATUS_OK:CODE
            if (strpos($response, 'STATUS_OK') !== false) {
                $parts = explode(':', $response, 2); // Sadece ilk ":" karakterinden böl
                $fullMessage = $parts[1]; // Tam mesaj metni

                return [
                    'status' => 'success',
                    'code' => $fullMessage, // Tam SMS mesajını gönder
                ];
            } else if ($response === 'STATUS_WAIT_CODE') {
                return [
                    'status' => 'waiting',
                    'message' => 'SMS bekleniyor...'
                ];
            } else if ($response === 'STATUS_CANCEL') {
                return [
                    'status' => 'canceled',
                    'message' => 'Aktivasyon iptal edildi.'
                ];
            } else {
                return [
                    'status' => 'error',
                    'message' => $response
                ];
            }
        } catch (\Exception $e) {
            Log::error('SMS-Activate getActivationStatus error: ' . $e->getMessage());
            return [
                'status' => 'error',
                'message' => $e->getMessage()
            ];
        }
    }

    /**
     * Cancel the activation and return funds
     *
     * @param int $id Phone ID
     * @return bool|string
     */
    public function cancelActivation($id)
    {
        try {
            $response = $this->makeRequest('setStatus', [
                'id' => $id,
                'status' => 8, // 8 is cancel status
            ]);

            return $response;
        } catch (\Exception $e) {
            Log::error('SMS-Activate cancelActivation error: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Get available services
     *
     * @return array
     */
    public function getServices()
    {
        try {
            $response = $this->makeRequest('getServices');

            if (is_string($response) && json_decode($response)) {
                return json_decode($response, true);
            }

            return [];
        } catch (\Exception $e) {
            Log::error('SMS-Activate getServices error: ' . $e->getMessage());
            return [];
        }
    }

    /**
     * Get available countries
     *
     * @return array
     */
    public function getCountries()
    {
        try {
            $response = $this->makeRequest('getCountries');

            if (is_string($response) && json_decode($response)) {
                return json_decode($response, true);
            }

            return [];
        } catch (\Exception $e) {
            Log::error('SMS-Activate getCountries error: ' . $e->getMessage());
            return [];
        }
    }

    /**
     * Get all SMS messages received for a specific activation
     *
     * @param int $id Activation ID
     * @return array
     */
    public function getAllSmsMessages($id)
    {
        try {
            $response = $this->makeRequest('getRentStatus', [
                'id' => $id,
            ]);

            if (is_string($response) && json_decode($response)) {
                $data = json_decode($response, true);
                if (isset($data['values']) && isset($data['values']['sms'])) {
                    return $data['values']['sms'];
                }
            }

            return [];
        } catch (\Exception $e) {
            Log::error('SMS-Activate getAllSmsMessages error: ' . $e->getMessage());
            return [];
        }
    }

    /**
     * Check if activation can be canceled (less than 2 minutes)
     *
     * @param Carbon $createdAt
     * @return bool
     */
    public function canBeCanceledByTime($createdAt)
    {
        // 2 dakika süre kontrolü
        $minutesPassed = Carbon::now()->diffInMinutes($createdAt);
        return $minutesPassed >= 2;
    }

    /**
     * Make API request
     *
     * @param string $action API action
     * @param array $params Additional parameters
     * @return string
     */
    protected function makeRequest($action, array $params = [])
    {
        $params = array_merge([
            'api_key' => $this->apiKey,
            'action' => $action,
        ], $params);

        $response = $this->client->get($this->baseUrl, [
            'query' => $params,
        ]);

        return (string) $response->getBody();
    }
}