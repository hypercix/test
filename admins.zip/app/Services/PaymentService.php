<?php

namespace App\Services;

use App\Models\Payment;
use App\Models\User;
use Stripe\Stripe;
use Stripe\PaymentIntent;
use Stripe\Exception\ApiErrorException;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;

class PaymentService
{
    public function __construct()
    {
        // Stripe API anahtarını ayarla
        Stripe::setApiKey(config('services.stripe.secret'));
    }

    /**
     * Bir ödeme niyeti (payment intent) oluştur
     *
     * @param User $user
     * @param float $amount
     * @param string $description
     * @return array
     */
    public function createPaymentIntent(User $user, float $amount, string $description = '')
    {
        try {
            // Amount'u kuruş cinsinden hesapla (1 TL = 100 kuruş)
            $amountInKurus = (int)($amount * 100);

            // Stripe Payment Intent oluştur
            $paymentIntent = PaymentIntent::create([
                'amount' => $amountInKurus,
                'currency' => 'try',
                'description' => $description,
                'metadata' => [
                    'user_id' => $user->id,
                    'user_email' => $user->email,
                ],
                'receipt_email' => $user->email,
            ]);

            // Veritabanına Payment kaydı oluştur (status = pending)
            $payment = Payment::create([
                'user_id' => $user->id,
                'payment_id' => $paymentIntent->id,
                'amount' => $amount,
                'fee' => 0, // Başarılı ödemede hesaplanacak
                'net_amount' => $amount, // Başarılı ödemede güncellenecek
                'currency' => 'TRY',
                'payment_method' => 'stripe',
                'status' => 'pending',
                'description' => $description,
                'metadata' => [
                    'client_secret' => $paymentIntent->client_secret,
                ],
            ]);

            return [
                'success' => true,
                'payment_intent' => $paymentIntent,
                'client_secret' => $paymentIntent->client_secret,
                'payment' => $payment,
            ];
        } catch (ApiErrorException $e) {
            Log::error('Stripe Payment Intent Error', [
                'message' => $e->getMessage(),
                'user_id' => $user->id,
                'amount' => $amount,
            ]);

            return [
                'success' => false,
                'message' => $e->getMessage(),
            ];
        }
    }

    /**
     * Ödeme durumunu güncelle
     *
     * @param string $paymentIntentId
     * @return array
     */
    public function updatePaymentStatus(string $paymentIntentId)
    {
        try {
            // Veritabanımızdaki ödeme kaydını bul
            $payment = Payment::where('payment_id', $paymentIntentId)->first();

            if (!$payment) {
                return [
                    'success' => false,
                    'message' => 'Ödeme kaydı bulunamadı',
                ];
            }

            // ÖNEMLİ: Ödeme zaten başarılı olarak işlenmişse, tekrar bakiye ekleme!
            if ($payment->status === 'succeeded') {
                Log::info('Ödeme zaten başarıyla tamamlanmış, bakiye güncellemesi atlanıyor', [
                    'payment_id' => $paymentIntentId,
                    'payment_status' => $payment->status
                ]);

                return [
                    'success' => true,
                    'status' => 'succeeded',
                    'payment' => $payment,
                    'user' => $payment->user,
                    'message' => 'Ödeme zaten başarıyla tamamlanmış.'
                ];
            }

            // Payment Intent'i Stripe'dan al
            $paymentIntent = PaymentIntent::retrieve($paymentIntentId);

            // Payment Intent durumuna göre ödememizi güncelle
            if ($paymentIntent->status === 'succeeded') {
                // Transaction başlat - bakiye güncelleme ve ödeme durumu güncelleme atomik olsun
                DB::beginTransaction();

                try {
                    // Ödeme başarılı ise, kullanıcının bakiyesini arttır
                    $user = $payment->user;

                    // Stripe işlem ücretini hesapla (örnek: %2.9 + 0.30TL)
                    $amountPaid = $payment->amount;
                    $stripeFee = ($amountPaid * 0.029) + 0.30; // Örnek Stripe ücreti
                    $netAmount = $amountPaid - $stripeFee;

                    // Ödeme bilgilerini güncelle
                    $payment->update([
                        'status' => 'succeeded',
                        'fee' => $stripeFee,
                        'net_amount' => $netAmount,
                        'paid_at' => now(),
                    ]);

                    // Kullanıcı bakiyesini güncelle
                    $user->balance += $amountPaid;
                    $user->save();

                    // İşlemi kaydet
                    DB::commit();

                    Log::info('Ödeme başarıyla tamamlandı ve bakiye güncellendi', [
                        'payment_id' => $paymentIntentId,
                        'user_id' => $user->id,
                        'amount' => $amountPaid,
                        'new_balance' => $user->balance
                    ]);

                    return [
                        'success' => true,
                        'status' => 'succeeded',
                        'payment' => $payment,
                        'user' => $user,
                    ];
                } catch (\Exception $e) {
                    // Hata durumunda rollback
                    DB::rollBack();
                    throw $e;
                }
            } elseif ($paymentIntent->status === 'canceled') {
                // Ödeme iptal edildi
                $payment->update([
                    'status' => 'failed',
                ]);

                Log::info('Ödeme iptal edildi', [
                    'payment_id' => $paymentIntentId
                ]);

                return [
                    'success' => true,
                    'status' => 'failed',
                    'payment' => $payment,
                ];
            } else {
                // Diğer durumlar (processing, requires_action, vb.)
                $payment->update([
                    'status' => 'pending',
                    'metadata' => array_merge($payment->metadata ?? [], [
                        'stripe_status' => $paymentIntent->status,
                    ]),
                ]);

                Log::info('Ödeme durumu güncellendi', [
                    'payment_id' => $paymentIntentId,
                    'stripe_status' => $paymentIntent->status
                ]);

                return [
                    'success' => true,
                    'status' => 'pending',
                    'payment' => $payment,
                ];
            }
        } catch (ApiErrorException $e) {
            Log::error('Stripe Payment Status Update Error', [
                'message' => $e->getMessage(),
                'payment_intent_id' => $paymentIntentId,
            ]);

            return [
                'success' => false,
                'message' => $e->getMessage(),
            ];
        } catch (\Exception $e) {
            Log::error('Ödeme durumu güncellenirken beklenmeyen hata', [
                'message' => $e->getMessage(),
                'payment_intent_id' => $paymentIntentId,
            ]);

            return [
                'success' => false,
                'message' => 'İşlem sırasında beklenmeyen bir hata oluştu: ' . $e->getMessage(),
            ];
        }
    }

    /**
     * Manuel bakiye ekleme (Admin arayüzü için)
     *
     * @param User $user
     * @param float $amount
     * @param string $description
     * @return Payment
     */
    public function addManualBalance(User $user, float $amount, string $description = 'Manuel bakiye ekleme')
    {
        // Transaction başlat
        DB::beginTransaction();

        try {
            // Bakiyeyi güncelle
            $user->balance += $amount;
            $user->save();

            // Ödeme kaydı oluştur
            $payment = Payment::create([
                'user_id' => $user->id,
                'payment_id' => 'manual_' . uniqid(),
                'amount' => $amount,
                'fee' => 0,
                'net_amount' => $amount,
                'currency' => 'TRY',
                'payment_method' => 'manual',
                'status' => 'succeeded',
                'description' => $description,
                'paid_at' => now(),
            ]);

            // İşlemi kaydet
            DB::commit();

            Log::info('Manuel bakiye eklendi', [
                'user_id' => $user->id,
                'amount' => $amount,
                'new_balance' => $user->balance
            ]);

            return $payment;
        } catch (\Exception $e) {
            // Hata durumunda rollback
            DB::rollBack();

            Log::error('Manuel bakiye ekleme hatası', [
                'user_id' => $user->id,
                'amount' => $amount,
                'error' => $e->getMessage()
            ]);

            throw $e;
        }
    }
}