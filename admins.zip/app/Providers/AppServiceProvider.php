<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;
use App\Models\Order;
use App\Observers\OrderObserver;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register(): void
    {
        $this->app->singleton(SmsActivateService::class, function ($app) {
            return new SmsActivateService();
        });
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        Schema::defaultStringLength(191);

        // Laravel tarafında timezone'ı manuel olarak ayarla
        DB::statement("SET time_zone = '+03:00'");

        // ✅ Sipariş oluştuğunda observer çalışsın
        Order::observe(OrderObserver::class);

    }
}
