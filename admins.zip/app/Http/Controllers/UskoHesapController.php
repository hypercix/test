<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Cache;
use Illuminate\Http\Request;
use App\Models\Product;

class UskoHesapController extends Controller
{
    public function index()
    {
        // Tüm ürünleri çekelim
        $allProducts = Product::all();

        // View'a hem ürün koleksiyonunu hem de title'a göre indekslenmiş ürünleri gönderelim
        $products = $allProducts->keyBy('title');

        return view('sys.usko-hesap', compact('products', 'allProducts'));
    }
}