<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Services\SmsActivateService;
use App\Models\SmsActivation;
use App\Models\SmsMessage;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;
use Carbon\Carbon;

class SmsActivationController extends Controller
{
    protected $smsActivateService;

    // Numara alma maliyeti (TL)
    protected $activationPrice = 20;

    // Aktivasyon süresi (dakika)
    protected $activationDuration = 20;

    // Servis fiyatları
    protected $servicePrices = [
        'zy' => 20.00,  // NTT Game - 1. sırada
        'go' => 5.00,  // Google - 2. sırada
        'wa' => 50.00,  // WhatsApp - 3. sırada
        'tg' => 50.00,  // Telegram - 4. sırada
        'ig' => 25.00,  // Instagram - 5. sırada
        'fb' => 25.00,  // Facebook - 6. sırada
        'tw' => 22.00,  // Twitter - 7. sırada
    ];

    public function __construct(SmsActivateService $smsActivateService)
    {
        $this->smsActivateService = $smsActivateService;
    }

    /**
     * SMS Aktivasyon sayfasını göster
     */
    public function index()
    {
        // İstenen sırayla servisler
        $services = [
            'zy' => 'NTT Game',       // 1. sırada
            'go' => 'Google',         // 2. sırada
            'wa' => 'WhatsApp',       // 3. sırada
            'tg' => 'Telegram',       // 4. sırada
            'ig' => 'Instagram',      // 5. sırada
            'fb' => 'Facebook',       // 6. sırada
            'tw' => 'Twitter',        // 7. sırada
        ];

        // İstenen sırayla ülkeler
        $countries = [
            62 => 'Türkiye',          // 1. sırada
            16 => 'United Kingdom',   // 2. sırada
            0 => 'Rusya',             // 3. sırada
            187 => 'USA',             // 4. sırada
            73 => 'Brazil',           // 5. sırada
            4 => 'Philippines',       // 6. sırada
            151 => 'Chile',           // 7. sırada
            48 => 'Netherlands',      // 8. sırada
            43 => 'Germany',          // 9. sırada
            56 => 'Spain',            // 10. sırada
            15 => 'Poland',           // 11. sırada
        ];

        // Kullanıcının aktif ve arşiv aktivasyonlarını al
        $activeActivations = SmsActivation::where('user_id', Auth::id())
            ->where(function ($query) {
                $query->where('status', 'waiting')
                    ->orWhere('status', 'waiting_with_message')
                    ->orWhere(function ($q) {
                        $q->where('status', 'completed')
                            ->where('expires_at', '>', now());
                    });
            })
            ->orderBy('created_at', 'desc')
            ->get();

        $archiveActivations = SmsActivation::where('user_id', Auth::id())
            ->where(function ($query) {
                $query->where('status', 'expired')
                    ->orWhere('status', 'canceled')
                    ->orWhere(function ($q) {
                        $q->where('status', 'completed')
                            ->where('expires_at', '<=', now());
                    });
            })
            ->orderBy('created_at', 'desc')
            ->paginate(10); // Sayfa başına 10 kayıt göster

        // Servis fiyatlarını görünüme gönder
        $servicePrices = $this->servicePrices;

        return view('sms-activation.index', compact('services', 'countries', 'activeActivations', 'archiveActivations', 'servicePrices'));
    }

    /**
     * Yeni numara alma işlemi
     */
    public function getNumber(Request $request)
    {
        try {
            $request->validate([
                'service' => 'required|string',
                'country' => 'required|integer',
            ]);

            $user = Auth::user();
            $serviceCode = $request->service;

            // Servis için tanımlı fiyatı kullan
            $price = $this->servicePrices[$serviceCode] ?? $this->activationPrice;

            // Bakiye kontrolü
            if ($user->balance < $price) {
                return response()->json([
                    'status' => 'error',
                    'message' => 'Yetersiz bakiye. En az ' . $price . ' TL bakiyeniz olmalıdır.'
                ]);
            }

            // Numarayı almaya başlıyoruz, önce işlemi kaydet
            $processStarted = [
                'status' => 'processing',
                'message' => 'Numara alınıyor, lütfen bekleyin. Bu işlem biraz zaman alabilir...',
                'service_name' => SmsActivation::getServiceName($request->service),
            ];

            // SMS-Activate API'den numara al
            $result = $this->smsActivateService->getNumber($request->service, $request->country);

            if ($result['status'] === 'success') {
                // Kullanıcının bakiyesinden düş
                $user->balance -= $price;
                $user->save();

                // Aktivasyonu veritabanına kaydet
                $activation = SmsActivation::create([
                    'user_id' => $user->id,
                    'service' => $request->service,
                    'country' => $request->country,
                    'phone_id' => $result['phone_id'],
                    'phone_number' => $result['phone_number'],
                    'status' => 'waiting',
                    'price' => $price,  // Servis için belirlenen fiyat
                    'expires_at' => now()->addMinutes($this->activationDuration),
                ]);

                return response()->json([
                    'status' => 'success',
                    'activation' => $activation,
                    'service_name' => SmsActivation::getServiceName($request->service),
                    'message' => 'Numara başarıyla alındı.',
                    'reload' => true  // Sayfayı yenilemek için flag
                ]);
            }

            // Hata durumu
            return response()->json([
                'status' => 'error',
                'message' => $result['message'] ?? 'Numara alınamadı.',
                'original_error' => $result['original_error'] ?? null
            ]);
        } catch (\Exception $e) {
            Log::error('Numara alma hatası', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);

            return response()->json([
                'status' => 'error',
                'message' => 'Beklenmeyen bir hata oluştu. Lütfen daha sonra tekrar deneyin.'
            ]);
        }
    }

    /**
     * SMS durumunu kontrol et
     */
    public function checkStatus($id)
    {
        $activation = SmsActivation::where('user_id', Auth::id())->findOrFail($id);

        // Eğer süre dolmuşsa, duruma göre işlem yap
        if ($activation->isExpired()) {
            // Eğer zaten expired veya canceled ise, sadece durum bilgisi döndür
            if ($activation->status === 'expired' || $activation->status === 'canceled') {
                return response()->json([
                    'status' => 'error',
                    'message' => $activation->status === 'expired' ? 'Bu aktivasyonun süresi dolmuş.' : 'Bu aktivasyon iptal edilmiş.',
                    'activation' => $activation,
                    'auto_check' => false
                ]);
            }

            // Tamamlanmış aktivasyonları kontrol et
            if ($activation->status === 'completed') {
                return response()->json([
                    'status' => 'success',
                    'code' => $activation->code,
                    'activation' => $activation,
                    'auto_check' => false
                ]);
            }

            // waiting veya waiting_with_message durumundaki aktivasyonları işle

            // 1. Önce mesaj gelmiş mi kontrol et
            $hasMessages = $activation->messages()->exists() || !empty($activation->code);
            $isWaitingWithMessage = $activation->status === 'waiting_with_message';

            if ($hasMessages || $isWaitingWithMessage) {
                // Mesaj gelmiş, tamamlandı olarak işaretle
                $activation->status = 'completed';
                $activation->save();

                Log::info('Süresi dolmuş aktivasyon tamamlandı olarak işaretlendi', [
                    'activation_id' => $activation->id,
                    'phone_number' => $activation->phone_number,
                    'has_messages' => $hasMessages,
                    'is_waiting_with_message' => $isWaitingWithMessage
                ]);

                return response()->json([
                    'status' => 'success',
                    'code' => $activation->code,
                    'activation' => $activation,
                    'auto_check' => false,
                    'message' => 'Aktivasyon tamamlandı.'
                ]);
            } else {
                // Hiç mesaj gelmemiş, iptal et ve bakiye iade et
                $oldStatus = $activation->status;
                $activation->status = 'canceled';
                $activation->save();

                // Bakiye iadesi
                $user = Auth::user();
                $oldBalance = $user->balance;
                $user->balance += $activation->price;
                $user->save();

                Log::info('Süresi dolmuş aktivasyon iptal edildi ve bakiye iade edildi', [
                    'activation_id' => $activation->id,
                    'phone_number' => $activation->phone_number,
                    'old_status' => $oldStatus,
                    'price' => $activation->price,
                    'old_balance' => $oldBalance,
                    'new_balance' => $user->balance
                ]);

                return response()->json([
                    'status' => 'error',
                    'message' => 'Bu aktivasyonun süresi dolmuş ve mesaj gelmediği için iptal edildi. Bakiyenize ' . $activation->price . ' TL iade edildi.',
                    'activation' => $activation,
                    'auto_check' => false
                ]);
            }
        }

        // İptal edilmiş aktivasyon için işlem yapma
        if ($activation->status === 'canceled') {
            return response()->json([
                'status' => 'error',
                'message' => 'Bu aktivasyon iptal edilmiş.',
                'activation' => $activation,
                'auto_check' => false
            ]);
        }

        // Eğer aktivasyon durumu 'waiting' veya 'waiting_with_message' ise, API'den durumu kontrol et
        if ($activation->status === 'waiting' || $activation->status === 'waiting_with_message') {
            $result = $this->smsActivateService->getActivationStatus($activation->phone_id);

            if ($result['status'] === 'success') {
                // SMS kodu alındı, SMS içeriğini işle ve sadece gerekli kısımları al
                $originalCode = $result['code'];
                $formattedCode = $originalCode;

                // NTTGame mesajlarını parse et
                if (strpos($originalCode, 'NTTGame') !== false) {
                    // OTP ID ve Auth Code'u bul
                    preg_match('/OTP ID:(.*?)Auth Code:(\d+)/s', $originalCode, $matches);
                    if (count($matches) >= 3) {
                        $otpId = trim($matches[1]);
                        $authCode = trim($matches[2]);
                        $formattedCode = "OTP ID:" . $otpId . " Auth Code:" . $authCode;
                    }
                }

                // Aktivasyonu güncelle
                $activation->status = 'completed';
                $activation->code = $formattedCode; // Formatlı mesajı kaydet
                $activation->save();

                // SMS mesajını kaydet - formatlanmış mesajı kaydediyoruz
                SmsMessage::create([
                    'activation_id' => $activation->id,
                    'text' => $formattedCode, // Formatlanmış mesaj kaydediliyor
                    'received_at' => now(),
                ]);

                // Otomatik olarak yeni SMS isteği gönder (Status 3)
                $newSmsResult = $this->smsActivateService->requestAnotherSms($activation->phone_id);
                $autoSmsRequested = false;

                if ($newSmsResult === 'ACCESS_RETRY_GET') {
                    // Başarılı ise daha sonraki kontroller için 'waiting' statusa geçilecek
                    // Ancak son mesajı (code) koruyoruz ve özel bir status ekliyoruz
                    $activation->status = 'waiting_with_message';
                    $activation->save();
                    $autoSmsRequested = true;

                    // Log'a kaydet
                    Log::info('Otomatik SMS isteği gönderildi', [
                        'activation_id' => $activation->id,
                        'phone_id' => $activation->phone_id,
                        'last_code' => $activation->code
                    ]);
                }

                return response()->json([
                    'status' => 'success',
                    'code' => $result['code'],
                    'activation' => $activation,
                    'remaining_minutes' => $activation->getRemainingMinutes(),
                    'can_request_another_sms' => true,
                    'auto_sms_requested' => $autoSmsRequested,
                    'auto_check' => true // Otomatik kontrol için eklenen flag
                ]);
            } else if ($result['status'] === 'waiting') {
                // Eğer 'waiting_with_message' statusa sahipse ve bir kod varsa, onu da gönder
                if ($activation->status === 'waiting_with_message' && !empty($activation->code)) {
                    return response()->json([
                        'status' => 'waiting',
                        'message' => 'Yeni SMS bekleniyor...',
                        'last_code' => $activation->code, // Son alınan mesajı gönder
                        'has_previous_message' => true,
                        'remaining_time' => $activation->expires_at->diffInSeconds(now()),
                        'can_be_canceled' => $activation->canBeCanceledByTime(),
                        'minutes_since_creation' => $activation->getMinutesSinceCreation(),
                        'auto_check' => true // Otomatik kontrol için eklenen flag
                    ]);
                }

                return response()->json([
                    'status' => 'waiting',
                    'message' => 'SMS bekleniyor...',
                    'remaining_time' => $activation->expires_at->diffInSeconds(now()),
                    'can_be_canceled' => $activation->canBeCanceledByTime(),
                    'minutes_since_creation' => $activation->getMinutesSinceCreation(),
                    'auto_check' => true // Otomatik kontrol için eklenen flag
                ]);
            } else if ($result['status'] === 'canceled') {
                $activation->status = 'canceled';
                $activation->save();

                return response()->json([
                    'status' => 'error',
                    'message' => 'Aktivasyon iptal edildi.',
                    'activation' => $activation,
                    'auto_check' => false // İptal edildiği için otomatik kontrol yapma
                ]);
            }
        } else if ($activation->status === 'completed') {
            // Aktivasyon zaten tamamlanmış, ancak yeni SMS isteği gelmiş olabilir
            // getAllSmsMessages ile tüm mesajları kontrol edelim
            $apiMessages = $this->smsActivateService->getAllSmsMessages($activation->phone_id);
            $newMessages = false;

            if (!empty($apiMessages)) {
                foreach ($apiMessages as $message) {
                    // Bu mesaj daha önce kaydedilmiş mi kontrol et
                    $exists = $activation->messages()->where('text', $message['text'])->exists();

                    if (!$exists) {
                        // Yeni mesajı kaydet
                        SmsMessage::create([
                            'activation_id' => $activation->id,
                            'phone_from' => $message['phoneFrom'] ?? null,
                            'text' => $message['text'],
                            'received_at' => Carbon::parse($message['date']),
                        ]);
                        $newMessages = true;
                    }
                }
            }

            // Aktivasyonu kontrol etmeye devam et flag
            $check_again = !$activation->isExpired(); // Süresi dolmadıysa kontrol etmeye devam et

            return response()->json([
                'status' => 'success',
                'code' => $activation->code,
                'activation' => $activation,
                'remaining_minutes' => $activation->getRemainingMinutes(),
                'can_request_another_sms' => true,
                'check_again' => $check_again,
                'new_messages' => $newMessages,
                'auto_check' => $check_again // Süresi dolmadıysa otomatik kontrol
            ]);
        }

        // Son response
        // Eğer 'waiting_with_message' statusa sahipse ve bir kod varsa, onu da gönder
        if ($activation->status === 'waiting_with_message' && !empty($activation->code)) {
            return response()->json([
                'status' => 'waiting',
                'message' => 'Yeni SMS bekleniyor...',
                'last_code' => $activation->code, // Son alınan mesajı gönder
                'has_previous_message' => true,
                'remaining_time' => $activation->expires_at->diffInSeconds(now()),
                'can_be_canceled' => $activation->canBeCanceledByTime(),
                'minutes_since_creation' => $activation->getMinutesSinceCreation(),
                'auto_check' => !$activation->isExpired() // Süresi dolmadıysa otomatik kontrol
            ]);
        }

        return response()->json([
            'status' => 'waiting',
            'message' => 'SMS bekleniyor...',
            'remaining_time' => $activation->expires_at->diffInSeconds(now()),
            'can_be_canceled' => $activation->canBeCanceledByTime(),
            'minutes_since_creation' => $activation->getMinutesSinceCreation(),
            'auto_check' => !$activation->isExpired() // Süresi dolmadıysa otomatik kontrol
        ]);
    }

    /**
     * Geçmişteki tüm SMS mesajlarını getir
     */
    public function getMessages($id)
    {
        $activation = SmsActivation::where('user_id', Auth::id())->findOrFail($id);

        // Veritabanındaki mesajları al
        $messages = $activation->messages()->orderBy('received_at', 'desc')->get();

        // Aktivasyon süresi dolmadıysa ve iptal edilmediyse
        // API'den en son mesajları her zaman kontrol et
        if (!$activation->isExpired() && $activation->status !== 'canceled') {
            $apiMessages = $this->smsActivateService->getAllSmsMessages($activation->phone_id);

            if (!empty($apiMessages)) {
                foreach ($apiMessages as $message) {
                    // Bu mesaj daha önce kaydedilmiş mi kontrol et
                    $exists = $messages->contains(function ($value) use ($message) {
                        return $value->text === $message['text'] &&
                            $value->received_at->format('Y-m-d H:i:s') === Carbon::parse($message['date'])->format('Y-m-d H:i:s');
                    });

                    if (!$exists) {
                        // Yeni mesajı kaydet
                        $newMessage = SmsMessage::create([
                            'activation_id' => $activation->id,
                            'phone_from' => $message['phoneFrom'] ?? null,
                            'text' => $message['text'],
                            'received_at' => Carbon::parse($message['date']),
                        ]);

                        $messages->push($newMessage);
                    }
                }
            }
        }

        return response()->json([
            'status' => 'success',
            'messages' => $messages,
        ]);
    }

    /**
     * Yeni SMS isteği gönder
     */
    public function requestNewSms($id)
    {
        $activation = SmsActivation::where('user_id', Auth::id())->findOrFail($id);

        // Aktivasyon süresi doldu mu kontrol et
        if ($activation->isExpired()) {
            return response()->json([
                'status' => 'error',
                'message' => 'Bu aktivasyonun süresi dolmuş, yeni SMS isteği gönderemezsiniz.'
            ]);
        }

        // Yeni SMS isteği gönder (Status 3)
        $result = $this->smsActivateService->requestAnotherSms($activation->phone_id);

        if ($result === 'ACCESS_RETRY_GET') {
            // Kullanıcının arayüzünde yeni SMS'leri görebilmesi için statusu waiting yapıyoruz
            // böylece sistem SMS kontrolüne devam edecek
            $activation->status = 'waiting';
            $activation->save();

            return response()->json([
                'status' => 'success',
                'message' => 'Yeni SMS isteği gönderildi. Lütfen bekleyin.'
            ]);
        }

        return response()->json([
            'status' => 'error',
            'message' => 'Yeni SMS isteği gönderilirken bir hata oluştu: ' . $result
        ]);
    }

    /**
     * Aktivasyonu iptal et
     */
    public function cancelActivation($id)
    {
        $activation = SmsActivation::where('user_id', Auth::id())->findOrFail($id);

        // İlk 2 dakika kontrol et
        if (!$activation->canBeCanceledByTime()) {
            return response()->json([
                'status' => 'error',
                'message' => 'İlk 2 dakika içinde aktivasyon iptal edilemez. Lütfen daha sonra tekrar deneyin.'
            ]);
        }

        // Aktivasyon iptal edilebilir mi kontrol et
        if (!$activation->canBeCanceled()) {
            return response()->json([
                'status' => 'error',
                'message' => 'Bu aktivasyon iptal edilemez. SMS alınmış veya süresi dolmuş olabilir.'
            ]);
        }

        // SMS-Activate API üzerinden iptal et
        $result = $this->smsActivateService->cancelActivation($activation->phone_id);

        if ($result === 'ACCESS_CANCEL') {
            // Aktivasyonu iptal olarak işaretle
            $activation->status = 'canceled';
            $activation->save();

            // Kullanıcıya bakiyesini geri ver
            $user = Auth::user();
            $user->balance += $activation->price;
            $user->save();

            return response()->json([
                'status' => 'success',
                'message' => 'Aktivasyon başarıyla iptal edildi ve ' . $activation->price . ' TL bakiyenize iade edildi.'
            ]);
        }

        return response()->json([
            'status' => 'error',
            'message' => 'Aktivasyon iptal edilirken bir hata oluştu: ' . $result
        ]);
    }
}