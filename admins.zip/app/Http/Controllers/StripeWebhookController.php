<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Services\PaymentService;
use App\Models\Payment;
use Stripe\Webhook;
use Stripe\Exception\SignatureVerificationException;
use Illuminate\Support\Facades\Log;

class StripeWebhookController extends Controller
{
    protected $paymentService;

    public function __construct(PaymentService $paymentService)
    {
        $this->paymentService = $paymentService;
    }

    public function handleWebhook(Request $request)
    {
        $payload = $request->getContent();
        $sig_header = $request->header('Stripe-Signature');
        $endpoint_secret = config('services.stripe.webhook_secret');

        try {
            $event = Webhook::constructEvent(
                $payload, $sig_header, $endpoint_secret
            );
        } catch (SignatureVerificationException $e) {
            // Invalid signature
            Log::error('Stripe Webhook Signature Verification Failed', [
                'error' => $e->getMessage(),
            ]);
            return response()->json(['error' => 'Invalid signature'], 400);
        }

        // Handle the event
        switch ($event->type) {
            case 'payment_intent.succeeded':
                $paymentIntent = $event->data->object;
                $this->handleSuccessfulPayment($paymentIntent);
                break;
                
            case 'payment_intent.payment_failed':
                $paymentIntent = $event->data->object;
                $this->handleFailedPayment($paymentIntent);
                break;
                
            default:
                Log::info('Unhandled Stripe Event', ['type' => $event->type]);
        }

        return response()->json(['status' => 'success']);
    }

    private function handleSuccessfulPayment($paymentIntent)
    {
        $paymentId = $paymentIntent->id;
        Log::info('Stripe Payment Succeeded', ['payment_id' => $paymentId]);
        
        $result = $this->paymentService->updatePaymentStatus($paymentId);
        
        if (!$result['success']) {
            Log::error('Failed to handle successful payment', [
                'payment_id' => $paymentId,
                'error' => $result['message'] ?? 'Unknown error',
            ]);
        }
    }

    private function handleFailedPayment($paymentIntent)
    {
        $paymentId = $paymentIntent->id;
        Log::info('Stripe Payment Failed', ['payment_id' => $paymentId]);
        
        $payment = Payment::where('payment_id', $paymentId)->first();
        
        if ($payment) {
            $payment->update([
                'status' => 'failed',
                'metadata' => array_merge($payment->metadata ?? [], [
                    'stripe_error' => $paymentIntent->last_payment_error->message ?? 'Unknown error',
                ]),
            ]);
        }
    }
}
