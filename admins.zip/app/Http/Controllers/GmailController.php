<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;
use App\Models\Order;
use App\Models\Stock;
use Illuminate\Support\Facades\Auth;

class GmailController extends Controller
{
    /**
     * Gmail hesapları satış sayfasını göster
     */
    public function index()
    {
        // Tüm Gmail ürünlerini getir
        $allProducts = Product::where('title', 'like', 'Gmail%')->get();

        // Arayüzdeki Product modelini view'a iletmek için ürünleri hazırla
        $products = [];
        foreach ($allProducts as $product) {
            $products[$product->title] = $product;
        }

        // Eksik ürünler için varsayılan değerler atayan kontrol mekanizması
        $categories = ['Gmail Accounts', 'Gmail Bulk', 'Gmail Mobile'];
        $types = ['Standart', 'Premium'];

        foreach ($categories as $category) {
            foreach ($types as $type) {
                $title = "$category ($type)";
                if (!isset($products[$title])) {
                    // Gerçek ürün olmadığında gösterilecek geçici nesne
                    $products[$title] = (object)[
                        'id' => '',
                        'title' => $title,
                        'price' => $type == 'Premium' ? 70 : 35,
                        'stocks' => (object)[
                            'count' => function() { return 0; }
                        ]
                    ];
                }
            }
        }

        return view('gmail.index', compact('allProducts', 'products'));
    }

    /**
     * Gmail hesabı satın alma işlemi
     */
    public function purchase(Request $request)
    {
        if (!Auth::check()) {
            return response()->json(['error' => 'Lütfen giriş yapın.'], 401);
        }

        $request->validate([
            'product_id' => 'required|exists:products,id',
            'quantity' => 'required|integer|min:1'
        ]);

        $product = Product::findOrFail($request->product_id);
        $user = Auth::user();
        $quantity = $request->quantity;
        $totalPrice = $product->price * $quantity;

        // Bakiye kontrolü
        if ($user->balance < $totalPrice) {
            return response()->json(['error' => 'Yetersiz bakiye.'], 400);
        }

        // Stok kontrolü
        $availableStocks = Stock::where('product_id', $product->id)
            ->where('status', 0)
            ->take($quantity)
            ->get();

        if (count($availableStocks) < $quantity) {
            return response()->json(['error' => 'Yeterli stok bulunmamaktadır.'], 400);
        }

        // Veritabanı işlemi başlat
        try {
            \DB::beginTransaction();

            // Sipariş oluştur
            $order = Order::create([
                'user_id' => $user->id,
                'product_id' => $product->id,
                'quantity' => $quantity,
                'price' => $totalPrice,
                'status' => 1 // Teslim edildi
            ]);

            // Stokları güncelle
            foreach ($availableStocks as $stock) {
                $stock->update([
                    'status' => 1, // Satıldı
                    'order_id' => $order->id
                ]);
            }

            // Kullanıcı bakiyesini güncelle
            $user->balance -= $totalPrice;
            $user->save();

            \DB::commit();

            return response()->json([
                'success' => true,
                'order_id' => $order->id,
                'message' => 'Gmail hesabı başarıyla satın alındı.'
            ]);
        } catch (\Exception $e) {
            \DB::rollBack();
            return response()->json(['error' => 'İşlem sırasında bir hata oluştu: ' . $e->getMessage()], 500);
        }
    }
}