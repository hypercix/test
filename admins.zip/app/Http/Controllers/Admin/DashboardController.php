<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Product;
use App\Models\Order;
use App\Models\Stock;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{
    public function index()
    {
        // Genel İstatistikler
        $stats = [
            'users' => User::count(),
            'products' => Product::count(),
            'orders' => Order::count(),
            'stocks' => Stock::where('status', 0)->count(), // Satılmamış stok sayısı
        ];

        // Bugünün satış istatistikleri
        $today = Carbon::today();
        $todaySales = Order::whereDate('created_at', $today)
            ->select([
                DB::raw('COUNT(*) as count'),
                DB::raw('SUM(price) as total'),
                DB::raw('SUM(quantity) as quantity')
            ])
            ->first();

        // Bu haftanın satış istatistikleri
        $weekStart = Carbon::now()->startOfWeek();
        $weekSales = Order::whereBetween('created_at', [$weekStart, Carbon::now()])
            ->select([
                DB::raw('COUNT(*) as count'),
                DB::raw('SUM(price) as total'),
                DB::raw('SUM(quantity) as quantity')
            ])
            ->first();

        // Bu ayın satış istatistikleri
        $monthStart = Carbon::now()->startOfMonth();
        $monthSales = Order::whereBetween('created_at', [$monthStart, Carbon::now()])
            ->select([
                DB::raw('COUNT(*) as count'),
                DB::raw('SUM(price) as total'),
                DB::raw('SUM(quantity) as quantity')
            ])
            ->first();

        // Son 5 sipariş
        $recentOrders = Order::with(['user', 'product'])->latest()->take(5)->get();

        // Son 5 kullanıcı
        $recentUsers = User::latest()->take(5)->get();

        // Ürün Stok Raporu
        $productStocks = Product::withCount(['stocks as available_stock' => function ($query) {
            $query->where('status', 0);
        }])
            ->withCount(['stocks as sold_stock' => function ($query) {
                $query->where('status', 1);
            }])
            ->orderBy('available_stock', 'desc')
            ->take(5)
            ->get();

        // Bekleyen Proxy Siparişleri (EKLENEN)
        $pendingProxyOrders = Order::whereHas('product', function($q) {
            $q->where('type', 'proxy');
        })
            ->where('status', Order::STATUS_PENDING) // veya 0, status sabitinize bağlı
            ->with(['user', 'product'])
            ->orderBy('created_at', 'asc')
            ->take(5)
            ->get();

        return view('admin.dashboard', compact(
            'stats',
            'todaySales',
            'weekSales',
            'monthSales',
            'recentOrders',
            'recentUsers',
            'productStocks',
            'pendingProxyOrders' // EKLENEN
        ));
    }
}