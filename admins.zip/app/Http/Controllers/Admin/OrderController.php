<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Order;
use App\Models\Product;
use App\Models\Stock;
use App\Models\User;

class OrderController extends Controller
{
    public function index(Request $request)
    {
        $query = Order::with(['user', 'product']);

        // Filtreler
        if ($request->has('status') && $request->status !== '') {
            $query->where('status', $request->status);
        }

        if ($request->has('search')) {
            $search = $request->search;
            $query->where(function($q) use ($search) {
                $q->whereHas('user', function($userQuery) use ($search) {
                    $userQuery->where('email', 'like', "%{$search}%")
                        ->orWhere('name', 'like', "%{$search}%");
                })
                    ->orWhereHas('product', function($productQuery) use ($search) {
                        $productQuery->where('title', 'like', "%{$search}%");
                    });
            });
        }

        // Tarih filtresi
        if ($request->has('date_from') && $request->date_from) {
            $query->whereDate('created_at', '>=', $request->date_from);
        }

        if ($request->has('date_to') && $request->date_to) {
            $query->whereDate('created_at', '<=', $request->date_to);
        }

        // Sıralama
        $query->orderBy('created_at', 'desc');

        $orders = $query->paginate(15);

        // Status değerleri
        $statuses = [
            '0' => 'Bekliyor',
            '1' => 'Teslim Edildi'
        ];

        return view('admin.orders.index', compact('orders', 'statuses'));
    }

    public function show(Order $order)
    {
        $order->load(['user', 'product', 'stocks']);

        return view('admin.orders.show', compact('order'));
    }
}