<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Product;
use App\Models\Order;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

class ProxyController extends Controller
{
    // Eski fonksiyonlar burada kalacak, sadece yeni fonksiyonlar ekliyoruz veya güncelliyoruz

    /**
     * Proxy siparişlerini listele
     */
    public function orders(Request $request)
    {
        $query = Order::whereHas('product', function($q) {
            $q->where('type', 'proxy');
        })->with(['user', 'product']);

        // Filtreler
        if ($request->has('status') && $request->status !== '') {
            $query->where('status', $request->status);
        }

        if ($request->has('search')) {
            $search = $request->search;
            $query->where(function($q) use ($search) {
                $q->whereHas('user', function($userQuery) use ($search) {
                    $userQuery->where('email', 'like', "%{$search}%")
                        ->orWhere('name', 'like', "%{$search}%");
                })
                ->orWhere('id', 'like', "%{$search}%");
            });
        }

        // Sıralama
        $query->orderBy('created_at', 'desc');

        $orders = $query->paginate(15);

        return view('admin.proxy.orders', compact('orders'));
    }

    /**
     * Proxy siparişi detayını göster
     */
    public function orderDetail($id)
    {
        $order = Order::with(['user', 'product'])
            ->whereHas('product', function($q) {
                $q->where('type', 'proxy');
            })
            ->findOrFail($id);

        return view('admin.proxy.order-detail', compact('order'));
    }

    /**
     * Proxy siparişini tamamla
     */
    public function completeOrder(Request $request, $id)
    {
        $request->validate([
            'delivery_content' => 'required|string'
        ]);

        $order = Order::whereHas('product', function($q) {
                $q->where('type', 'proxy');
            })
            ->findOrFail($id);

        if ($order->status != Order::STATUS_PENDING) {
            return redirect()->back()->with('error', 'Bu sipariş zaten tamamlanmış veya iptal edilmiş.');
        }

        $order->update([
            'status' => Order::STATUS_COMPLETED,
            'delivery_content' => $request->delivery_content,
            'completed_at' => Carbon::now(),
            'notes' => $request->notes ?? $order->notes
        ]);

        return redirect()->route('admin.proxy.orders')->with('success', 'Sipariş başarıyla tamamlandı.');
    }

    /**
     * Proxy siparişini iptal et
     */
    public function cancelOrder(Request $request, $id)
    {
        $order = Order::whereHas('product', function($q) {
                $q->where('type', 'proxy');
            })
            ->findOrFail($id);

        if ($order->status != Order::STATUS_PENDING) {
            return redirect()->back()->with('error', 'Bu sipariş zaten tamamlanmış veya iptal edilmiş.');
        }

        // Transaction başlat
        DB::beginTransaction();

        try {
            // Siparişi iptal et
            $order->update([
                'status' => Order::STATUS_CANCELLED,
                'notes' => $request->notes ? $order->notes . "\n" . $request->notes : $order->notes
            ]);

            // Kullanıcıya ücret iadesi yap
            $order->user->update([
                'balance' => $order->user->balance + $order->price
            ]);

            DB::commit();

            return redirect()->route('admin.proxy.orders')->with('success', 'Sipariş iptal edildi ve ücret iade edildi.');

        } catch (\Exception $e) {
            DB::rollBack();
            return redirect()->back()->with('error', 'İşlem sırasında bir hata oluştu: ' . $e->getMessage());
        }
    }

    /**
     * Bekleyen proxy siparişlerini göster (dashboard widget için)
     */
    public function pendingOrders()
    {
        $pendingOrders = Order::whereHas('product', function($q) {
                $q->where('type', 'proxy');
            })
            ->where('status', Order::STATUS_PENDING)
            ->with(['user', 'product'])
            ->orderBy('created_at', 'asc')
            ->take(5)
            ->get();

        return $pendingOrders;
    }
}