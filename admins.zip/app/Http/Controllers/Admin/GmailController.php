<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Product;
use App\Models\Stock;
use App\Models\Order;
use Illuminate\Support\Facades\DB;

class GmailController extends Controller
{
    /**
     * Gmail ürünleri listesi
     */
    public function index()
    {
        $gmailProducts = Product::where('title', 'like', 'Gmail%')
            ->withCount(['stocks as available_stock' => function ($query) {
                $query->where('status', 0); // Satılmamış stoklar
            }])
            ->withCount(['stocks as sold_stock' => function ($query) {
                $query->where('status', 1); // Satılmış stoklar
            }])
            ->latest()
            ->paginate(15);

        // İstatistikler
        $stats = [
            'total_products' => $gmailProducts->total(),
            'total_available_stock' => $gmailProducts->sum('available_stock'),
            'total_sold_stock' => $gmailProducts->sum('sold_stock'),
            'total_sales' => Order::whereHas('product', function ($query) {
                $query->where('title', 'like', 'Gmail%');
            })->sum('price'),
        ];

        return view('admin.gmail.index', compact('gmailProducts', 'stats'));
    }

    /**
     * Yeni Gmail ürünü oluşturma formu
     */
    public function create()
    {
        return view('admin.gmail.create');
    }

    /**
     * Yeni Gmail ürünü oluşturma
     */
    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'price' => 'required|numeric|min:0',
            'delivery_format' => 'nullable|string',
            'description' => 'nullable|string'
        ]);

        // Ürün oluşturma
        $product = Product::create([
            'title' => $request->title,
            'type' => 'gmail',
            'price' => $request->price,
            'delivery_format' => $request->delivery_format,
            'description' => $request->description
        ]);

        return redirect()->route('admin.gmail.index')
            ->with('success', 'Gmail ürünü başarıyla oluşturuldu.');
    }

    /**
     * Gmail ürünü düzenleme formu
     */
    public function edit(Product $product)
    {
        // Ürünün Gmail ürünü olup olmadığını kontrol et
        if (strpos($product->title, 'Gmail') === false) {
            return redirect()->route('admin.gmail.index')
                ->with('error', 'Bu ürün Gmail ürünü değil.');
        }

        return view('admin.gmail.edit', compact('product'));
    }

    /**
     * Gmail ürünü güncelleme
     */
    public function update(Request $request, Product $product)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'price' => 'required|numeric|min:0',
            'delivery_format' => 'nullable|string',
            'description' => 'nullable|string'
        ]);

        $product->update([
            'title' => $request->title,
            'price' => $request->price,
            'delivery_format' => $request->delivery_format,
            'description' => $request->description
        ]);

        return redirect()->route('admin.gmail.index')
            ->with('success', 'Gmail ürünü başarıyla güncellendi.');
    }

    /**
     * Gmail ürününü silme
     */
    public function destroy(Product $product)
    {
        // Ürünle ilişkili siparişleri kontrol et
        $hasOrders = Order::where('product_id', $product->id)->exists();

        if ($hasOrders) {
            return redirect()->route('admin.gmail.index')
                ->with('error', 'Bu ürünle ilişkili siparişler olduğu için silinemez.');
        }

        // Ürünle ilişkili stokları sil
        Stock::where('product_id', $product->id)->delete();

        // Ürünü sil
        $product->delete();

        return redirect()->route('admin.gmail.index')
            ->with('success', 'Gmail ürünü ve ilişkili stoklar başarıyla silindi.');
    }

    /**
     * Gmail ürününe stok ekleme
     */
    public function importStocks(Request $request, Product $product)
    {
        $request->validate([
            'stock_content' => 'required|string'
        ]);

        $stockLines = explode("\n", trim($request->stock_content));
        $addedCount = 0;

        foreach ($stockLines as $line) {
            $line = trim($line);
            if (!empty($line)) {
                Stock::create([
                    'product_id' => $product->id,
                    'content' => $line,
                    'status' => 0 // Satılmamış
                ]);
                $addedCount++;
            }
        }

        return redirect()->route('admin.gmail.edit', $product)
            ->with('success', "Toplam {$addedCount} adet Gmail hesabı stok olarak eklendi.");
    }

    /**
     * Gmail ürününün stoklarını görüntüleme
     */
    public function stocks(Product $product)
    {
        $stocks = Stock::where('product_id', $product->id)
            ->orderBy('status')
            ->orderBy('created_at', 'desc')
            ->paginate(50);

        return view('admin.gmail.stocks', compact('product', 'stocks'));
    }

    /**
     * Gmail satış raporları
     */
    public function reports(Request $request)
    {
        // Tarih aralığı filtreleme
        $dateStart = $request->date_start ? $request->date_start : now()->subDays(30)->format('Y-m-d');
        $dateEnd = $request->date_end ? $request->date_end : now()->format('Y-m-d');

        // Günlük satış istatistikleri
        $dailySales = Order::whereHas('product', function ($query) {
            $query->where('title', 'like', 'Gmail%');
        })
            ->whereBetween(DB::raw('DATE(created_at)'), [$dateStart, $dateEnd])
            ->selectRaw('DATE(created_at) as date, COUNT(*) as count, SUM(price) as total, SUM(quantity) as quantity')
            ->groupBy(DB::raw('DATE(created_at)'))
            ->orderBy('date')
            ->get();

        // Ürün kategorilerine göre satış istatistikleri
        $categorySales = Order::whereHas('product', function ($query) {
            $query->where('title', 'like', 'Gmail%');
        })
            ->whereBetween(DB::raw('DATE(created_at)'), [$dateStart, $dateEnd])
            ->join('products', 'orders.product_id', '=', 'products.id')
            ->selectRaw('SUBSTRING_INDEX(products.title, "(", 1) as category, COUNT(*) as count, SUM(orders.price) as total, SUM(orders.quantity) as quantity')
            ->groupBy('category')
            ->orderBy('total', 'desc')
            ->get();

        return view('admin.gmail.reports', compact('dailySales', 'categorySales', 'dateStart', 'dateEnd'));
    }
}