<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\SmsService;

class SmsServiceController extends Controller
{
    public function index()
    {
        $smsServices = SmsService::orderBy('name')->get();
        return view('admin.sms_services.index', compact('smsServices'));
    }

    public function create()
    {
        return view('admin.sms_services.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'code' => 'required|string|unique:sms_services,code|max:50',
            'description' => 'nullable|string',
            'base_price' => 'required|numeric|min:0',
            'profit_type' => 'required|in:fixed,percentage',
            'fixed_profit' => 'nullable|required_if:profit_type,fixed|numeric|min:0',
            'percentage_profit' => 'nullable|required_if:profit_type,percentage|numeric|min:0',
            'is_active' => 'boolean',
        ]);

        SmsService::create($request->all());

        return redirect()->route('admin.sms-services.index')
                         ->with('success', 'SMS servisi başarıyla oluşturuldu.');
    }

    public function edit(SmsService $smsService)
    {
        return view('admin.sms_services.edit', compact('smsService'));
    }

    public function update(Request $request, SmsService $smsService)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'code' => 'required|string|max:50|unique:sms_services,code,' . $smsService->id,
            'description' => 'nullable|string',
            'base_price' => 'required|numeric|min:0',
            'profit_type' => 'required|in:fixed,percentage',
            'fixed_profit' => 'nullable|required_if:profit_type,fixed|numeric|min:0',
            'percentage_profit' => 'nullable|required_if:profit_type,percentage|numeric|min:0',
            'is_active' => 'boolean',
        ]);

        $smsService->update($request->all());

        return redirect()->route('admin.sms-services.index')
                         ->with('success', 'SMS servisi başarıyla güncellendi.');
    }

    public function destroy(SmsService $smsService)
    {
        $smsService->delete();

        return redirect()->route('admin.sms-services.index')
                         ->with('success', 'SMS servisi başarıyla silindi.');
    }
}
