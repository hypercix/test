<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Product;
use App\Models\Stock;

class ProductController extends Controller
{
    public function index()
    {
        $products = Product::withCount(['stocks' => function($query) {
            $query->where('status', 0); // Satılmamış stoklar
        }])->latest()->paginate(15);

        return view('admin.products.index', compact('products'));
    }

    public function edit(Product $product)
    {
        return view('admin.products.edit', compact('product'));
    }

    public function update(Request $request, Product $product)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'type' => 'nullable|string|max:255',
            'price' => 'required|numeric|min:0',
            'delivery_format' => 'nullable|string',
            'description' => 'nullable|string'
        ]);

        $product->update([
            'title' => $request->title,
            'type' => $request->type,
            'price' => $request->price,
            'delivery_format' => $request->delivery_format,
            'description' => $request->description
        ]);

        return redirect()->route('admin.products.index')->with('success', 'Ürün başarıyla güncellendi.');
    }

    public function create()
    {
        return view('admin.products.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'type' => 'nullable|string|max:255',
            'price' => 'required|numeric|min:0',
            'delivery_format' => 'nullable|string',
            'description' => 'nullable|string'
        ]);

        Product::create([
            'title' => $request->title,
            'type' => $request->type,
            'price' => $request->price,
            'delivery_format' => $request->delivery_format,
            'description' => $request->description
        ]);

        return redirect()->route('admin.products.index')->with('success', 'Ürün başarıyla oluşturuldu.');
    }

    public function destroy(Product $product)
    {
        // Ürünün stokları ve ilgili siparişleri kontrol edilebilir

        $product->delete();

        return redirect()->route('admin.products.index')->with('success', 'Ürün başarıyla silindi.');
    }

    public function importStocks(Request $request, Product $product)
    {
        $request->validate([
            'stock_content' => 'required|string'
        ]);

        $stockLines = explode("\n", trim($request->stock_content));
        $addedCount = 0;

        foreach ($stockLines as $line) {
            $line = trim($line);
            if (!empty($line)) {
                Stock::create([
                    'product_id' => $product->id,
                    'content' => $line,
                    'status' => 0 // Satılmamış
                ]);
                $addedCount++;
            }
        }

        return redirect()->route('admin.products.edit', $product)
            ->with('success', "Toplam {$addedCount} adet stok başarıyla eklendi.");
    }
}