<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\SmsActivation;
use App\Models\SmsMessage;
use App\Models\User;
use Carbon\Carbon;

class SmsMonitoringController extends Controller
{
    public function index(Request $request)
    {
        // Filtreleme için parametreleri al
        $search = $request->get('search');
        $status = $request->get('status');
        $service = $request->get('service');
        $dateFrom = $request->get('date_from');
        $dateTo = $request->get('date_to');
        $userId = $request->get('user_id');

        // Aktivasyonları sorgulamaya başla
        $query = SmsActivation::with(['user', 'messages']);

        // Filtreler
        if ($search) {
            $query->where(function($q) use ($search) {
                $q->where('phone_number', 'like', "%{$search}%")
                  ->orWhere('code', 'like', "%{$search}%")
                  ->orWhereHas('user', function($query) use ($search) {
                      $query->where('email', 'like', "%{$search}%")
                            ->orWhere('name', 'like', "%{$search}%");
                  });
            });
        }

        if ($status) {
            $query->where('status', $status);
        }

        if ($service) {
            $query->where('service', $service);
        }

        if ($dateFrom) {
            $query->whereDate('created_at', '>=', $dateFrom);
        }

        if ($dateTo) {
            $query->whereDate('created_at', '<=', $dateTo);
        }

        if ($userId) {
            $query->where('user_id', $userId);
        }

        // Aktivasyonları tarih sıralamasıyla getir
        $activations = $query->latest()->paginate(15);

        // Filtreleme için ek verileri hazırla
        $users = User::orderBy('name')->get(['id', 'name', 'email']);
        
        // Sistemdeki SMS servislerini al (benzersiz)
        $services = SmsActivation::select('service')
            ->distinct()
            ->pluck('service')
            ->mapWithKeys(function ($code) {
                return [$code => SmsActivation::getServiceName($code)];
            })
            ->toArray();

        // Durum seçenekleri
        $statuses = [
            'waiting' => 'Bekliyor',
            'waiting_with_message' => 'Mesaj Aldı, Bekliyor',
            'completed' => 'Tamamlandı',
            'canceled' => 'İptal Edildi',
            'expired' => 'Süresi Doldu'
        ];

        // İstatistikler
        $stats = [
            'total' => SmsActivation::count(),
            'today' => SmsActivation::whereDate('created_at', Carbon::today())->count(),

            // Başarılı aktivasyonlar (completed olanlar)
            'completed_total' => SmsActivation::where('status', 'completed')->count(),
            'completed_today' => SmsActivation::where('status', 'completed')
                ->whereDate('created_at', Carbon::today())
                ->count(),

            // Başarısız aktivasyonlar (canceled veya expired olanlar)
            'failed_total' => SmsActivation::whereIn('status', ['canceled', 'expired'])->count(),
            'failed_today' => SmsActivation::whereIn('status', ['canceled', 'expired'])
                ->whereDate('created_at', Carbon::today())
                ->count(),
        ];
// Sistem servis adlarını view'a gönderelim
        $serviceNames = [];
        foreach($services as $code => $name) {
            $serviceNames[$code] = $name;
        }
        // View'a döndür
        return view('admin.sms_monitoring.index', compact(
            'activations',
            'users',
            'services',
            'statuses',
            'stats',
            'serviceNames'  // Bu değişkeni ekledik
        ));
    }

    public function show($id)
    {
        $activation = SmsActivation::with(['user', 'messages'])->findOrFail($id);

        // Servis adını alalım
        $serviceName = SmsActivation::getServiceName($activation->service);

        return view('admin.sms_monitoring.show', compact('activation', 'serviceName'));
    }

    public function export(Request $request)
    {
        // Burada Excel/CSV export işlemleri yapılabilir
        // İhtiyaç olursa bu kısım geliştirilebilir
    }
}
