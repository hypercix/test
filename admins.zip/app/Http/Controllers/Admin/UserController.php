<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rule;

class UserController extends Controller
{
    public function index()
    {
        $users = User::latest()->paginate(15);
        return view('admin.users.index', compact('users'));
    }

    public function create()
    {
        return view('admin.users.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users',
            'password' => 'required|string|min:8',
            'balance' => 'nullable|numeric|min:0',
            'is_admin' => 'boolean',
        ]);

        User::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'balance' => $request->balance ?? 0,
            'is_admin' => $request->is_admin ?? 0,
        ]);

        return redirect()->route('admin.users.index')->with('success', 'Kullanıcı başarıyla oluşturuldu.');
    }

    public function edit(User $user)
    {
        return view('admin.users.edit', compact('user'));
    }

    public function update(Request $request, User $user)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => ['required', 'string', 'email', 'max:255', Rule::unique('users')->ignore($user->id)],
            'password' => 'nullable|string|min:8',
            'balance' => 'nullable|numeric|min:0',
            'is_admin' => 'boolean',
        ]);

        $userData = [
            'name' => $request->name,
            'email' => $request->email,
            'balance' => $request->balance ?? $user->balance,
            'is_admin' => $request->is_admin ?? 0,
        ];

        if ($request->filled('password')) {
            $userData['password'] = Hash::make($request->password);
        }

        $user->update($userData);

        return redirect()->route('admin.users.index')->with('success', 'Kullanıcı başarıyla güncellendi.');
    }

    public function destroy(User $user)
    {
        // Kullanıcının siparişleri ve diğer ilişkili verileriyle ilgili ek kontroller yapılabilir
        $user->delete();
        return redirect()->route('admin.users.index')->with('success', 'Kullanıcı başarıyla silindi.');
    }

    public function addBalance(Request $request, User $user)
    {
        $request->validate([
            'amount' => 'required|numeric|min:1',
            'note' => 'nullable|string',
        ]);

        // Bakiyeyi güncelle
        $user->balance += $request->amount;
        $user->save();

        // Bakiye işlemini logla
        \App\Models\BalanceTransaction::create([
            'user_id' => $user->id,
            'amount' => $request->amount,
            'note' => $request->note,
        ]);

        return redirect()->route('admin.users.edit', $user)->with('success', 'Bakiye başarıyla eklendi.');
    }

    public function ban(User $user)
    {
        $user->is_banned = !$user->is_banned;
        $user->save();

        $status = $user->is_banned ? 'yasaklandı' : 'yasağı kaldırıldı';
        return redirect()->route('admin.users.index')->with('success', "Kullanıcının {$status}.");
    }
}