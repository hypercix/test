<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Payment;
use App\Models\User;
use App\Services\PaymentService;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class PaymentController extends Controller
{
    protected $paymentService;

    public function __construct(PaymentService $paymentService)
    {
        $this->paymentService = $paymentService;
    }

    /**
     * Ödeme listesi
     */
    public function index(Request $request)
    {
        // Filtreleme parametreleri
        $status = $request->get('status');
        $method = $request->get('method');
        $dateFrom = $request->get('date_from');
        $dateTo = $request->get('date_to');
        $search = $request->get('search');
        $userId = $request->get('user_id');

        // Temel sorguyu hazırla
        $query = Payment::with('user');

        // Filtreleri uygula
        if ($status) {
            $query->where('status', $status);
        }

        if ($method) {
            $query->where('payment_method', $method);
        }

        if ($dateFrom) {
            $query->whereDate('created_at', '>=', $dateFrom);
        }

        if ($dateTo) {
            $query->whereDate('created_at', '<=', $dateTo);
        }

        if ($search) {
            $query->where(function ($q) use ($search) {
                $q->where('payment_id', 'like', "%{$search}%")
                    ->orWhere('description', 'like', "%{$search}%")
                    ->orWhereHas('user', function ($query) use ($search) {
                        $query->where('email', 'like', "%{$search}%")
                            ->orWhere('name', 'like', "%{$search}%");
                    });
            });
        }

        if ($userId) {
            $query->where('user_id', $userId);
        }

        // Ödemeleri listele
        $payments = $query->latest()->paginate(15);

        // İstatistikler
        $stats = [
            'total_count' => Payment::count(),
            'total_succeeded' => Payment::where('status', 'succeeded')->count(),
            'total_amount' => Payment::where('status', 'succeeded')->sum('amount'),
            'today_amount' => Payment::where('status', 'succeeded')
                ->whereDate('created_at', Carbon::today())
                ->sum('amount'),
        ];

        // Filtreleme seçenekleri
        $users = User::orderBy('name')->get(['id', 'name', 'email']);

        $statuses = [
            'succeeded' => 'Başarılı',
            'pending' => 'Beklemede',
            'failed' => 'Başarısız',
            'refunded' => 'İade Edildi',
        ];

        $methods = [
            'stripe' => 'Stripe',
            'manual' => 'Manuel',
        ];

        return view('admin.payments.index', compact(
            'payments',
            'stats',
            'users',
            'statuses',
            'methods'
        ));
    }

    /**
     * Ödeme detay sayfası
     */
    public function show(Payment $payment)
    {
        $payment->load('user');
        return view('admin.payments.show', compact('payment'));
    }

    /**
     * Manuel bakiye ekleme sayfası
     */
    public function addBalanceForm()
    {
        $users = User::orderBy('name')->get(['id', 'name', 'email', 'balance']); // balance alanını ekledik
        return view('admin.payments.add-balance', compact('users'));
    }

    /**
     * Manuel bakiye ekleme işlemi
     */
    public function addBalance(Request $request)
    {
        $request->validate([
            'user_id' => 'required|exists:users,id',
            'amount' => 'required|numeric|min:1',
            'description' => 'nullable|string|max:255',
        ]);

        $user = User::findOrFail($request->user_id);
        $amount = $request->amount;
        $description = $request->description ?: 'Manuel bakiye ekleme';

        $payment = $this->paymentService->addManualBalance($user, $amount, $description);

        return redirect()->route('admin.payments.show', $payment)
            ->with('success', "{$user->name} kullanıcısına {$amount} TL bakiye eklendi.");
    }

    /**
     * Özet raporu
     */
    public function report(Request $request)
    {
        // Tarih aralığı seçimi
        $period = $request->get('period', 'month');

        // Başlangıç ve bitiş tarihlerini belirle
        $now = Carbon::now();

        if ($period === 'week') {
            $startDate = $now->copy()->startOfWeek();
            $endDate = $now->copy()->endOfWeek();
            $groupFormat = 'Y-m-d'; // Her gün için
        } elseif ($period === 'month') {
            $startDate = $now->copy()->startOfMonth();
            $endDate = $now->copy()->endOfMonth();
            $groupFormat = 'Y-m-d'; // Her gün için
        } elseif ($period === 'year') {
            $startDate = $now->copy()->startOfYear();
            $endDate = $now->copy()->endOfYear();
            $groupFormat = 'Y-m'; // Her ay için
        } else {
            // Özel aralık
            $startDate = $request->get('start_date') ? Carbon::parse($request->get('start_date')) : $now->copy()->subMonth();
            $endDate = $request->get('end_date') ? Carbon::parse($request->get('end_date')) : $now;
            $groupFormat = 'Y-m-d'; // Her gün için
        }

        // Tarih aralığındaki ödemeleri getir
        $payments = Payment::where('status', 'succeeded')
            ->whereBetween('created_at', [$startDate, $endDate])
            ->get();

        // Başarılı ödeme sayısı ve tutarı
        $successPaymentCount = $payments->count();
        $totalAmount = $payments->sum('amount');
        $totalFee = $payments->sum('fee');
        $netAmount = $payments->sum('net_amount');

        // Ödeme yöntemine göre grupla
        $methodStats = $payments->groupBy('payment_method')
            ->map(function ($items) {
                return [
                    'count' => $items->count(),
                    'amount' => $items->sum('amount'),
                ];
            });

        // Günlük/aylık bazda grupla
        $dateStats = $payments->groupBy(function ($item) use ($groupFormat) {
            return $item->created_at->format($groupFormat);
        })
            ->map(function ($items) {
                return [
                    'count' => $items->count(),
                    'amount' => $items->sum('amount'),
                ];
            });

        // Kullanıcı başına toplam yükleme
        $userStats = $payments->groupBy('user_id')
            ->map(function ($items) {
                $user = $items->first()->user;
                return [
                    'user' => $user ? $user->name : 'Unknown',
                    'count' => $items->count(),
                    'amount' => $items->sum('amount'),
                ];
            })
            ->sortByDesc(function ($stat) {
                return $stat['amount'];
            })
            ->take(10);

        return view('admin.payments.report', compact(
            'payments',
            'period',
            'startDate',
            'endDate',
            'successPaymentCount',
            'totalAmount',
            'totalFee',
            'netAmount',
            'methodStats',
            'dateStats',
            'userStats'
        ));
    }
}