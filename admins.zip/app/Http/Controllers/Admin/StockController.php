<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Stock;
use App\Models\Product;

class StockController extends Controller
{
    public function index(Request $request)
    {
        $query = Stock::with('product');

        // Ürün filtreleme
        if ($request->has('product_id') && !empty($request->product_id)) {
            $query->where('product_id', $request->product_id);
        }

        // Satış durumu filtreleme
        if ($request->has('status')) {
            $query->where('status', $request->status);
        }

        $stocks = $query->latest()->paginate(20);
        $products = Product::all(); // Filtreleme için ürün listesi

        return view('admin.stocks.index', compact('stocks', 'products'));
    }

    public function edit(Stock $stock)
    {
        $products = Product::all();
        return view('admin.stocks.edit', compact('stock', 'products'));
    }

    public function update(Request $request, Stock $stock)
    {
        $request->validate([
            'product_id' => 'required|exists:products,id',
            'content' => 'required|string',
            'status' => 'required|boolean'
        ]);

        $stock->update([
            'product_id' => $request->product_id,
            'content' => $request->content,
            'status' => $request->status
        ]);

        return redirect()->route('admin.stocks.index')->with('success', 'Stok başarıyla güncellendi.');
    }

    public function destroy(Stock $stock)
    {
        // Siparişlere bağlı stoklar için ek kontroller yapılabilir

        $stock->delete();

        return redirect()->route('admin.stocks.index')->with('success', 'Stok başarıyla silindi.');
    }
}