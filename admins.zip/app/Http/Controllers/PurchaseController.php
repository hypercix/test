<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use App\Models\Order;
use App\Models\Product;
use App\Models\Stock;

class PurchaseController extends Controller
{
    public function store(Request $request)
    {
        $request->validate([
            'product_id' => 'required|exists:products,id',
            'quantity'   => 'required|integer|min:1',
        ]);

        $user     = Auth::user();
        $product  = Product::findOrFail($request->product_id);
        $quantity = $request->quantity;
        $total    = $product->price * $quantity;

        // Bakiye kontrolü
        if ($user->balance < $total) {
            return response()->json(['error' => 'Yetersiz bakiye.'], 422);
        }

        DB::beginTransaction();

        try {
            // Stokları önceden çek ve kilitle
            $stocks = Stock::where('product_id', $product->id)
                ->where('status', 0)
                ->limit($quantity)
                ->lockForUpdate()
                ->get();

            // Stok yeterli değilse iptal et
            if ($stocks->count() < $quantity) {
                DB::rollBack();
                return response()->json(['error' => 'Yeterli stok yok.'], 422);
            }

            // Sipariş oluştur
            $order = Order::create([
                'user_id'    => $user->id,
                'product_id' => $product->id,
                'price'      => $total,
                'quantity'   => $quantity,
                'status'     => 1,
                'created_at' => now(),
            ]);

            // Bakiye düş
            $user->balance -= $total;
            $user->save();

            // Stokları siparişe ata
            foreach ($stocks as $stock) {
                $stock->update([
                    'order_id' => $order->id,
                    'status'   => 1,
                ]);
            }

            DB::commit();
            return response()->json([
                'success' => true,
                'order_id' => $order->id
            ]);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json(['error' => 'İşlem sırasında bir hata oluştu.'], 500);
        }
    }
}
