<?php

namespace App\Http\Controllers;

use App\Models\Account;
use Illuminate\Http\Request;

class AccountController extends Controller
{
    /**
     * Tüm hesapları listele.
     */
    public function index()
    {
        $accounts = Account::orderByDesc('id')->paginate(20);
        return view('admin.accounts.index', compact('accounts'));
    }

    /**
     * Yeni bir hesap kaydı oluştur.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'server' => 'required|string|max:100',
            'type' => 'required|in:auth,copy',
            'content' => 'required|string',
            'price' => 'required|numeric|min:0',
        ]);

        Account::create([
            'server' => $validated['server'],
            'type' => $validated['type'],
            'content' => $validated['content'],
            'price' => $validated['price'],
            'status' => 0 // yeni eklenen hesaplar "kullanılmamış"
        ]);

        return redirect()->back()->with('success', 'Hesap başarıyla eklendi.');
    }
}
