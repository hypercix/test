<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;
use App\Models\Order;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class ProxyController extends Controller
{
    /**
     * Knight Online Proxy satış sayfasını göster
     */
    public function index()
    {
        // Sistemde kayıtlı tüm proxy ürünlerini getir
        $products = Product::where('title', 'like', '%Knight Online Proxy%')
            ->where('type', 'proxy')
            ->get();

        // Ürün ID'lerini ve başlıklarını alarak bir koleksiyon hazırla
        $productCollection = [];
        foreach ($products as $product) {
            $productCollection[$product->title] = $product;
        }

        return view('proxy.index', [
            'products' => $productCollection
        ]);
    }

    /**
     * Proxy satın alma işlemi - Stoksuz çalışan versiyon
     */
    public function purchase(Request $request)
    {
        // Giriş kontrolü
        if (!Auth::check()) {
            return response()->json([
                'success' => false,
                'error' => 'Satın alma işlemi yapabilmek için giriş yapmalısınız.'
            ], 401);
        }

        // Validation
        $request->validate([
            'product_id' => 'required|exists:products,id',
            'quantity' => 'required|integer|min:1'
        ]);

        $product = Product::findOrFail($request->product_id);
        $user = Auth::user();
        $quantity = $request->quantity;
        $totalPrice = $product->price;

        // Bakiye kontrolü
        if ($user->balance < $totalPrice) {
            return response()->json([
                'success' => false,
                'error' => 'Yetersiz bakiye. Lütfen bakiyenizi yükleyin.'
            ], 400);
        }

        // Transaction başlat
        DB::beginTransaction();

        try {
            // Sipariş oluştur - Beklemede durumunda
            $order = Order::create([
                'user_id' => $user->id,
                'product_id' => $product->id,
                'quantity' => $quantity,
                'price' => $totalPrice,
                'status' => Order::STATUS_PENDING, // Beklemede statüsü
                'notes' => 'Knight Online Proxy siparişi'
            ]);

            // Kullanıcı bakiyesini güncelle
            $user->update([
                'balance' => $user->balance - $totalPrice
            ]);

            // Transaction'ı tamamla
            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'Proxy siparişiniz alındı. En kısa sürede teslim edilecektir.',
                'order_id' => $order->id
            ]);

        } catch (\Exception $e) {
            // Hata durumunda rollback
            DB::rollBack();

            return response()->json([
                'success' => false,
                'error' => 'İşlem sırasında bir hata oluştu: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Kullanıcının siparişlerini gösterme
     */
    public function orders()
    {
        $orders = Order::where('user_id', Auth::id())
            ->whereHas('product', function($query) {
                $query->where('type', 'proxy');
            })
            ->orderBy('created_at', 'desc')
            ->paginate(10);

        return view('proxy.orders', compact('orders'));
    }

    /**
     * Sipariş detayını gösterme
     */
    public function orderDetail($id)
    {
        $order = Order::where('user_id', Auth::id())
            ->where('id', $id)
            ->whereHas('product', function($query) {
                $query->where('type', 'proxy');
            })
            ->firstOrFail();

        return view('proxy.order-detail', compact('order'));
    }
}