<?php

namespace App\Http\Controllers;

use App\Models\SmsRequest;
use App\Models\SmsMessage;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Http;

class SmsRequestController extends Controller
{
    public function index()
    {
        $user = Auth::user();

        $requests = SmsRequest::with('messages')
            ->where('user_id', $user->id)
            ->whereIn('status', ['waiting', 'received'])
            ->orderByDesc('created_at')
            ->get();

        return view('sms.index', compact('requests'));
    }

    public function create(Request $request)
    {
        $validated = $request->validate([
            'service' => 'required|string',
            'country' => 'nullable|string',
        ]);

        $user = Auth::user();
        $country = $validated['country'] ?? '6';
        $service = $validated['service'];
        $apiKey = config('services.smsactivate.api_key');

        $response = Http::get("https://sms-activate.org/stubs/handler_api.php", [
            'api_key' => $apiKey,
            'action' => 'getNumber',
            'service' => $service,
            'country' => $country,
        ]);

        if (strpos($response->body(), 'ACCESS_NUMBER') === 0) {
            $parts = explode(':', $response->body());
            $smsId = $parts[1] ?? null;
            $number = $parts[2] ?? null;

            $cost = 20.00;
            if ($user->balance < $cost) {
                return response()->json(['success' => false, 'message' => 'Yetersiz bakiye.'], 400);
            }

            $user->balance -= $cost;
            $user->save();

            $smsRequest = SmsRequest::create([
                'user_id' => $user->id,
                'service' => $service,
                'country' => $country,
                'number' => $number,
                'sms_id' => $smsId,
                'status' => 'waiting',
                'cost' => $cost,
            ]);

            return response()->json([
                'success' => true,
                'message' => 'Numara başarıyla alındı.',
                'data' => $smsRequest,
            ]);
        }

        return response()->json([
            'success' => false,
            'message' => 'Numara alınamadı: ' . $response->body(),
        ], 500);
    }

    public function checkSms(Request $request, $id)
    {
        $smsRequest = SmsRequest::with('messages')->findOrFail($id);

        if ($smsRequest->status !== 'waiting') {
            return response()->json([
                'success' => false,
                'message' => 'SMS zaten alındı, süresi doldu ya da iptal edildi.',
            ]);
        }

        $apiKey = config('services.smsactivate.api_key');

        $response = Http::get("https://sms-activate.org/stubs/handler_api.php", [
            'api_key' => $apiKey,
            'action' => 'getStatus',
            'id' => $smsRequest->sms_id,
        ]);

        \Log::info("SMS CHECK response: " . $response->body());

        if (strpos($response->body(), 'STATUS_OK') === 0) {
            $smsText = explode(':', $response->body(), 2)[1];

            $smsRequest->update([
                'status' => 'received',
                'received_sms' => $smsText,
            ]);

            // ✅ SmsMessage kaydı
            $smsRequest->messages()->create([
                'sms_request_id' => $smsRequest->id,
                'message' => $smsText,
                'received_at' => now(),
            ]);

            return response()->json([
                'success' => true,
                'message' => 'SMS alındı.',
                'sms' => $smsText,
            ]);
        } elseif (trim($response->body()) === 'STATUS_WAIT_CODE') {
            return response()->json([
                'success' => false,
                'message' => 'SMS henüz gelmedi.',
            ]);
        } elseif (trim($response->body()) === 'STATUS_CANCEL') {
            $smsRequest->update(['status' => 'cancelled']);
            return response()->json([
                'success' => false,
                'message' => 'SMS isteği iptal edilmiş.',
            ]);
        }

        return response()->json([
            'success' => false,
            'message' => 'Durum alınamadı: ' . $response->body(),
        ], 500);
    }

    public function getAnotherSms(Request $request, $id)
    {
        $smsRequest = SmsRequest::with('messages')->findOrFail($id);

        if ($smsRequest->status !== 'received') {
            return response()->json([
                'success' => false,
                'message' => 'Yeni SMS sadece ilk SMS geldikten sonra alınabilir.',
            ]);
        }

        $apiKey = config('services.smsactivate.api_key');

        $response = Http::get('https://sms-activate.org/stubs/handler_api.php', [
            'api_key' => $apiKey,
            'action' => 'setStatus',
            'status' => 3,
            'id' => $smsRequest->sms_id,
        ]);

        $body = trim($response->body());

        if (in_array($body, ['ACCESS_READY', 'ACCESS_RETRY_GET'])) {
            $smsRequest->update(['status' => 'waiting']);

            return response()->json([
                'success' => true,
                'message' => 'Yeni SMS için tekrar bekleme başlatıldı.',
            ]);
        }

        \Log::error("TEKRAR SMS HATASI: " . $body);

        return response()->json([
            'success' => false,
            'message' => 'Yeni SMS alma başarısız: ' . $body,
        ]);
    }


    public function cancelSms(Request $request, $id)
    {
        $smsRequest = SmsRequest::with('messages')->findOrFail($id);

        $createdAt = \Carbon\Carbon::parse($smsRequest->created_at);
        $now = now();
        $hasSms = $smsRequest->messages()->count() > 0;

        if ($createdAt->addMinutes(2)->isFuture()) {
            return response()->json([
                'success' => false,
                'message' => 'Numarayı iptal etmek için en az 2 dakika beklemelisiniz.',
            ]);
        }

        if ($hasSms) {
            return response()->json([
                'success' => false,
                'message' => 'SMS alındıktan sonra iptal edemezsiniz.',
            ]);
        }

        $apiKey = config('services.smsactivate.api_key');

        $response = Http::get('https://sms-activate.org/stubs/handler_api.php', [
            'api_key' => $apiKey,
            'action' => 'setStatus',
            'status' => 8,
            'id' => $smsRequest->sms_id,
        ]);

        if (strpos($response->body(), 'ACCESS_CANCEL') === 0) {
            $smsRequest->update(['status' => 'cancelled']);

            $user = $smsRequest->user;
            $user->balance += $smsRequest->cost;
            $user->save();

            return response()->json([
                'success' => true,
                'message' => 'Numara iptal edildi ve bakiye iade edildi.',
            ]);
        }

        return response()->json([
            'success' => false,
            'message' => 'İptal işlemi başarısız: ' . $response->body(),
        ]);
    }
}
