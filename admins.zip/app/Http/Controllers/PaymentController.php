<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Services\PaymentService;
use App\Models\Payment;
use Illuminate\Support\Facades\Auth;

class PaymentController extends Controller
{
    protected $paymentService;

    public function __construct(PaymentService $paymentService)
    {
        $this->paymentService = $paymentService;
    }

    /**
     * Bakiye yükleme sayfasını göster
     */
    public function index()
    {
        $user = Auth::user();
        $recentPayments = $user->payments()->latest()->take(5)->get();

        // Önceden tanımlanmış bakiye yükleme tutarları
        $predefinedAmounts = [50, 100, 200, 500, 1000];

        return view('payments.index', compact('user', 'recentPayments', 'predefinedAmounts'));
    }

    /**
     * Bakiye yükleme işlemi başlat
     */
    public function checkout(Request $request)
    {
        $request->validate([
            'amount' => 'required|numeric|min:10|max:10000',
        ]);

        $user = Auth::user();
        $amount = $request->amount;
        $description = "Bakiye Yükleme: {$amount} TL";

        $result = $this->paymentService->createPaymentIntent($user, $amount, $description);

        if (!$result['success']) {
            return redirect()->back()->with('error', 'Ödeme başlatılırken bir hata oluştu: ' . $result['message']);
        }

        // Ödeme sayfasına yönlendir
        return view('payments.checkout', [
            'clientSecret' => $result['client_secret'],
            'amount' => $amount,
            'paymentId' => $result['payment']->id,
            'stripeKey' => config('services.stripe.key'),
        ]);
    }

    /**
     * Ödeme sonucu
     */
    public function result(Request $request)
    {
        $paymentIntentId = $request->payment_intent;
        $result = $this->paymentService->updatePaymentStatus($paymentIntentId);

        if ($result['success'] && $result['status'] === 'succeeded') {
            return view('payments.success', [
                'payment' => $result['payment'],
                'user' => $result['user'],
            ]);
        } else {
            return view('payments.failed', [
                'message' => $result['message'] ?? 'Ödeme işlemi başarısız oldu.',
            ]);
        }
    }

    /**
     * Ödeme geçmişi
     */
    public function history()
    {
        $user = Auth::user();
        $payments = $user->payments()->latest()->paginate(10);

        return view('payments.history', compact('payments'));
    }
}