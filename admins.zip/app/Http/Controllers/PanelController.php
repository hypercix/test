<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use App\Models\Order;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Str;

class PanelController extends Controller
{
    public function orders()
    {
        $user = Auth::user();

        // Sayfalanmış siparişleri al
        $orders = Order::with('product')
            ->where('user_id', $user->id)
            ->latest()
            ->paginate(10);

        // Tüm siparişlerin toplamını ayrı bir sorgu ile al
        $allStats = Order::where('user_id', $user->id)
            ->selectRaw('SUM(quantity) as total_quantity, SUM(price) as total_spent')
            ->first();

        $totalQuantity = $allStats->total_quantity ?? 0;
        $totalSpent = $allStats->total_spent ?? 0;

        return view('panel.orders', compact('orders', 'totalQuantity', 'totalSpent'));
    }
    public function orderDetail($id)
    {
        $user = Auth::user();

        $order = $user->orders()
            ->with('product', 'stocks')
            ->where('id', $id)
            ->firstOrFail();

        return view('panel.order-detail', compact('order'));
    }
    public function downloadOrder(Order $order)
    {
        $user = auth()->user();
        if ($order->user_id !== $user->id) {
            abort(403, 'Bu siparişe erişim izniniz yok.');
        }

        $productTitle = Str::slug($order->product->title, '_');
        $date = now()->format('d_m_Y');
        $filename = "ACCZ_{$date}_{$order->quantity}_adet_{$productTitle}.txt";

        $lines = $order->stocks->pluck('content')->toArray();
        $fileContent = implode("\n", $lines);

        return Response::make($fileContent, 200, [
            'Content-Type' => 'text/plain',
            'Content-Disposition' => "attachment; filename=\"$filename\""
        ]);
    }
}
