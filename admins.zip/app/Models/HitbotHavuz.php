<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class HitbotHavuz extends Model
{
    use HasFactory;

    protected $table = 'hitbot_havuz';

    protected $fillable = [
        'user_id',
        'islem_sayisi',
        'fingerprint_api',
        'domain',
        'sayfa_arama',
        'bekleme_suresi_min',
        'bekleme_suresi_max',
        'demografi',
        'durum',
    ];
}
