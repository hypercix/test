<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class SmsMessage extends Model
{
    use HasFactory;

    protected $fillable = [
        'activation_id',
        'phone_from',
        'text',
        'received_at',
    ];

    protected $casts = [
        'received_at' => 'datetime',
    ];

    /**
     * Activation relationship
     */
    public function activation()
    {
        return $this->belongsTo(SmsActivation::class, 'activation_id');
    }
}