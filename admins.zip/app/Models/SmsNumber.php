<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class SmsNumber extends Model
{
    use HasFactory;

    protected $table = 'sms_numbers';

    protected $fillable = [
        'user_id',
        'service',
        'country',
        'phone',
        'cost',
        'status',
        'expires_at',
    ];

    public function messages()
    {
        return $this->hasMany(SmsMessage::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
