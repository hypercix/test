<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Carbon\Carbon;

class SmsActivation extends Model
{
    use HasFactory;

    // Sabitleri doğrudan string değerler olarak kullanalım
    // Statuses
    public const STATUS_WAITING = 'waiting';
    public const STATUS_COMPLETED = 'completed';
    public const STATUS_CANCELED = 'canceled';
    public const STATUS_EXPIRED = 'expired';

    protected $fillable = [
        'user_id',
        'service',
        'country',
        'phone_id',
        'phone_number',
        'status',
        'code',
        'price',
        'expires_at',
    ];

    protected $casts = [
        'expires_at' => 'datetime',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];

    /**
     * User relationship
     */
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    /**
     * SMS messages relationship
     */
    public function messages()
    {
        return $this->hasMany(SmsMessage::class, 'activation_id');
    }

    /**
     * Check if activation has expired
     */
    public function isExpired()
    {
        return $this->expires_at && now()->greaterThan($this->expires_at);
    }

    /**
     * Check if activation can be canceled by time (2 minutes rule)
     */
    public function canBeCanceledByTime()
    {
        // 2 dakika geçtiyse iptal edilebilir
        return $this->created_at->diffInMinutes(now()) >= 2;
    }

    /**
     * Check if activation can be canceled
     */
    public function canBeCanceled()
    {
        return $this->status === 'waiting' &&
            $this->canBeCanceledByTime() &&
            $this->messages()->count() === 0 &&
            !$this->isExpired();
    }

    /**
     * Get minutes since creation
     */
    public function getMinutesSinceCreation()
    {
        return $this->created_at->diffInMinutes(now());
    }

    /**
     * Get the remaining minutes until the activation expires
     */
    public function getRemainingMinutes()
    {
        if ($this->isExpired()) {
            return 0;
        }

        return now()->diffInMinutes($this->expires_at);
    }

    /**
     * Custom service name mapping - with your custom service names
     */
    public static function getServiceName($serviceCode)
    {
        $services = [
            'tg' => 'Telegram',
            'wa' => 'WhatsApp',
            'ig' => 'Instagram',
            'fb' => 'Facebook',
            'go' => 'Google',
            'tw' => 'Twitter',
            'vk' => 'VK',
            'ok' => 'OK',
            'vb' => 'Viber',
            'zy' => 'NTTGame',  // Özel servis adı tanımlaması
            'ot' => 'Diğer',
        ];

        return $services[$serviceCode] ?? $serviceCode;
    }
}