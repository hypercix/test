<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class SmsRequest extends Model
{
    use HasFactory;

    protected $table = 'sms_requests';

    protected $fillable = [
        'user_id',
        'service',
        'country',
        'number',
        'sms_id',
        'status',
        'received_sms',
        'cost', // 👈 yeni eklendi
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function messages()
    {
        return $this->hasMany(SmsMessage::class, 'sms_request_id');
    }
    
}
