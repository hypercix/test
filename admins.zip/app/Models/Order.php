<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    protected $fillable = [
        'user_id',
        'product_id',
        'quantity',
        'price',
        'status',
        'delivery_content', // Eklenen - Teslim edilecek içerik (proxy bilgileri)
        'notes',            // Eklenen - Admin notları
        'completed_at'      // Eklenen - Tamamlanma tarihi
    ];

    // Status sabitleri
    const STATUS_PENDING = 0;    // Beklemede
    const STATUS_COMPLETED = 1;  // Tamamlandı
    const STATUS_CANCELLED = 2;  // İptal Edildi

    // İlişkiler
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function product()
    {
        return $this->belongsTo(Product::class);
    }

    public function stocks()
    {
        return $this->hasMany(Stock::class);
    }

    // Durum Kontrolleri
    public function isPending()
    {
        return $this->status === self::STATUS_PENDING;
    }

    public function isCompleted()
    {
        return $this->status === self::STATUS_COMPLETED;
    }

    public function isCancelled()
    {
        return $this->status === self::STATUS_CANCELLED;
    }
}