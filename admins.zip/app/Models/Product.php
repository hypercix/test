<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    protected $fillable = [
        'title',
        'type',
        'price',
        'description',
        'delivery_format',
        'image',
    ];

    public function stocks()
    {
        return $this->hasMany(Stock::class);
    }
    public function __toString()
    {
        return $this->title;
    }
}
