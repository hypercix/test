<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SmsService extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'code',
        'description',
        'base_price',
        'fixed_profit',
        'percentage_profit',
        'profit_type',
        'is_active'
    ];

    // Satış fiyatını hesaplama metodu
    public function calculateSellingPrice()
    {
        if ($this->profit_type === 'fixed' && $this->fixed_profit !== null) {
            return $this->base_price + $this->fixed_profit;
        } elseif ($this->profit_type === 'percentage' && $this->percentage_profit !== null) {
            return $this->base_price * (1 + ($this->percentage_profit / 100));
        }
        
        return $this->base_price;
    }
}
