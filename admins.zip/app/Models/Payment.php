<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Payment extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'payment_id',
        'amount',
        'fee',
        'net_amount',
        'currency',
        'payment_method',
        'status',
        'description',
        'metadata',
        'paid_at'
    ];

    protected $casts = [
        'amount' => 'decimal:2',
        'fee' => 'decimal:2',
        'net_amount' => 'decimal:2',
        'metadata' => 'array',
        'paid_at' => 'datetime',
    ];

    // İlişkiler
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    // Status Getter
    public function getStatusNameAttribute()
    {
        return [
            'succeeded' => 'Başarılı',
            'pending' => 'Beklemede',
            'failed' => 'Başarısız',
            'refunded' => 'İade Edildi'
        ][$this->status] ?? $this->status;
    }

    // Ödemenin durumunu kontrol etmek için yardımcı fonksiyonlar
    public function isSuccessful()
    {
        return $this->status === 'succeeded';
    }

    public function isPending()
    {
        return $this->status === 'pending';
    }

    public function isFailed()
    {
        return $this->status === 'failed';
    }

    public function isRefunded()
    {
        return $this->status === 'refunded';
    }
}
